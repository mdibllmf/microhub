<?php
/**
 * Admin import page for bulk importing papers from JSON
 * Enhanced to handle ALL enriched data: protocols, repositories, RRIDs, microscopes
 */

// Add import submenu
add_action('admin_menu', 'microhub_add_import_menu');

function microhub_add_import_menu() {
    add_submenu_page(
        'microhub-settings',
        __('Import Papers', 'microhub'),
        __('Import Papers', 'microhub'),
        'manage_options',
        'microhub-import',
        'microhub_import_page'
    );
}

/**
 * Import page content
 */
function microhub_import_page() {
    // Handle import
    if (isset($_POST['microhub_import']) && check_admin_referer('microhub_import_nonce')) {
        microhub_process_import();
    }
    ?>

    <div class="wrap">
        <h1><?php _e('Import Papers', 'microhub'); ?></h1>

        <p><?php _e('Upload one or more JSON files containing papers to import. Select multiple files at once to batch import.', 'microhub'); ?></p>

        <form method="post" action="" enctype="multipart/form-data" id="microhub-import-form">
            <?php wp_nonce_field('microhub_import_nonce'); ?>

            <table class="form-table">
                <tr>
                    <th scope="row"><label for="json_files"><?php _e('JSON Files', 'microhub'); ?></label></th>
                    <td>
                        <input type="file" name="json_files[]" id="json_files" accept=".json" multiple required />
                        <p class="description"><?php _e('Select multiple JSON files (Ctrl/Cmd+click or Shift+click). Each file is processed sequentially.', 'microhub'); ?></p>
                        <div id="mh-file-count" style="margin-top:8px;font-weight:600;display:none;"></div>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><?php _e('Import Options', 'microhub'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="skip_existing" value="1" checked />
                            <?php _e('Skip papers that already exist (based on DOI)', 'microhub'); ?>
                        </label>
                        <br />
                        <label>
                            <input type="checkbox" name="update_existing" value="1" />
                            <?php _e('Update existing papers with new enrichment data', 'microhub'); ?>
                        </label>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <input type="submit" name="microhub_import" class="button button-primary" value="<?php _e('Import Papers', 'microhub'); ?>" />
                <span class="microhub-import-progress" style="display:none;margin-left:12px;vertical-align:middle;">
                    <span class="spinner is-active" style="float:none;margin:0 8px 0 0;"></span>
                    <?php _e('Importing files... This may take a while for large batches. Do not close this page.', 'microhub'); ?>
                </span>
            </p>
        </form>

        <script>
        document.getElementById('json_files').addEventListener('change', function() {
            var count = this.files.length;
            var el = document.getElementById('mh-file-count');
            if (count > 0) {
                var totalSize = 0;
                for (var i = 0; i < this.files.length; i++) totalSize += this.files[i].size;
                var sizeMB = (totalSize / 1024 / 1024).toFixed(1);
                el.textContent = count + ' file' + (count > 1 ? 's' : '') + ' selected (' + sizeMB + ' MB total)';
                el.style.display = 'block';
            } else {
                el.style.display = 'none';
            }
        });
        document.getElementById('microhub-import-form').addEventListener('submit', function() {
            document.querySelector('.microhub-import-progress').style.display = 'inline';
        });
        </script>

        <hr />

        <h2><?php _e('Import Instructions', 'microhub'); ?></h2>

        <ol>
            <li><?php _e('Run the MicroHub scraper: <code>python microhub_scraper.py --email your@email.com</code>', 'microhub'); ?></li>
            <li><?php _e('Export to JSON: <code>python microhub_scraper.py --export papers.json</code>', 'microhub'); ?></li>
            <li><?php _e('Select one or more JSON files using the file picker (Ctrl+click or Shift+click to select multiple)', 'microhub'); ?></li>
            <li><?php _e('Click "Import Papers" and wait — files are processed sequentially with per-file progress', 'microhub'); ?></li>
        </ol>

        <p class="description"><strong><?php _e('Tip:', 'microhub'); ?></strong>
        <?php _e('If uploading many files, your server\'s <code>max_file_uploads</code> PHP setting controls the limit (default: 20). Ask your host to increase it if needed. <code>post_max_size</code> must also be large enough for the combined file sizes.', 'microhub'); ?></p>

        <h3><?php _e('Supported Tag Categories', 'microhub'); ?></h3>
        <ul>
            <li><strong>Techniques:</strong> Confocal, STED, PALM, STORM, Light-Sheet, Cryo-EM, SIM, TIRF, FRAP, FRET, etc.</li>
            <li><strong>Microscope Brands:</strong> Zeiss, Leica, Nikon, Olympus, Evident, Thermo Fisher, JEOL, etc.</li>
            <li><strong>Software:</strong> Fiji, ImageJ, CellProfiler, Imaris, napari, RELION, U-Net, etc.</li>
            <li><strong>Fluorophores:</strong> GFP, EGFP, mCherry, tdTomato, Alexa Fluor series, DAPI, Hoechst, etc.</li>
            <li><strong>Organisms:</strong> Mouse, Human, Zebrafish, Drosophila, C. elegans, Yeast, etc.</li>
            <li><strong>Cell Lines:</strong> HeLa, HEK293, U2OS, COS-7, CHO, iPSC, etc.</li>
            <li><strong>Sample Prep:</strong> PFA fixation, Immunostaining, Tissue clearing, CLARITY, Expansion, etc.</li>
            <li><strong>Protocols:</strong> protocols.io, Bio-protocol, JoVE, Nature Protocols, STAR Protocols</li>
            <li><strong>Repositories:</strong> IDR, Zenodo, GitHub, Figshare, EMPIAR, BioImage Archive</li>
            <li><strong>RRIDs:</strong> Antibodies (AB_), Software (SCR_), Cell Lines (CVCL_), Plasmids (Addgene_)</li>
        </ul>

        <h3><?php _e('Expected JSON Format (v5 Scraper)', 'microhub'); ?></h3>
        <pre style="background:#1e1e1e;color:#d4d4d4;padding:16px;border-radius:8px;overflow-x:auto;font-size:12px;"><code>[
  {
    "title": "Paper Title",
    "doi": "10.1234/example",
    "pmid": "12345678",
    "pmcid": "PMC1234567",
    "authors": "Smith J, Doe J",
    "journal": "Nature Methods",
    "year": 2023,
    "citation_count": 150,
    "abstract": "Paper abstract...",
    "methods": "Methods section text...",
    
    <span style="color:#6a9955">// Note: full_text is no longer stored to save space. Tags are extracted from it during cleanup.</span>
    
    <span style="color:#6a9955">// Tag Arrays (v5 format)</span>
    "microscopy_techniques": ["Confocal", "STED", "Super-Resolution"],
    "microscope_brands": ["Zeiss", "Leica"],
    "microscope_models": ["LSM 880", "SP8"],
    "image_analysis_software": ["Fiji", "ImageJ", "CellProfiler"],
    "fluorophores": ["GFP", "mCherry", "Alexa Fluor 488"],
    "organisms": ["Mouse", "Human"],
    "cell_lines": ["HeLa", "U2OS"],
    "sample_preparation": ["PFA fixation", "Immunostaining"],
    
    <span style="color:#6a9955">// Enrichment Data</span>
    "protocols": [
      {"name": "protocols.io", "url": "https://protocols.io/view/..."}
    ],
    "repositories": [
      {"name": "Zenodo", "url": "https://zenodo.org/...", "accession_id": "10.5281/..."}
    ],
    "rrids": [
      {"id": "RRID:AB_123456", "type": "antibody", "url": "https://..."}
    ],
    "antibodies": [
      {"id": "ab12345", "vendor": "Abcam", "url": "https://..."}
    ],
    "figures": [
      {"id": "fig1", "caption": "Figure 1 caption..."}
    ],
    "references": [
      {"num": 1, "text": "Reference text...", "doi": "10.1234/ref"}
    ]
  }
]</code></pre>
        <p><em><?php _e('Note: Both v3/v4/v5 scraper formats are supported. Legacy fields like "tags" and "microscope.brand" also work. v5.1+ includes github_tools with enriched repository metrics.', 'microhub'); ?></em></p>
    </div>

    <?php
}

/**
 * Process the import - optimized for 300K+ papers
 * Uses streaming JSON parsing and batch database operations
 */
function microhub_process_import() {
    // Check file upload - now supports multiple files
    if (!isset($_FILES['json_files']) || !is_array($_FILES['json_files']['name'])) {
        echo '<div class="notice notice-error"><p>' . __('Error uploading files.', 'microhub') . '</p></div>';
        return;
    }

    // Increase memory and time limits for large imports
    @ini_set('memory_limit', '512M');
    set_time_limit(0);

    $skip_existing = isset($_POST['skip_existing']);
    $update_existing = isset($_POST['update_existing']);

    // Reorganize $_FILES array for easier iteration
    $files = array();
    $file_count = count($_FILES['json_files']['name']);
    for ($i = 0; $i < $file_count; $i++) {
        if ($_FILES['json_files']['error'][$i] === UPLOAD_ERR_OK) {
            $files[] = array(
                'name' => $_FILES['json_files']['name'][$i],
                'tmp_name' => $_FILES['json_files']['tmp_name'][$i],
                'size' => $_FILES['json_files']['size'][$i],
            );
        }
    }

    if (empty($files)) {
        echo '<div class="notice notice-error"><p>' . __('No valid files were uploaded. Check your PHP upload limits (upload_max_filesize, post_max_size, max_file_uploads).', 'microhub') . '</p></div>';
        return;
    }

    // Sort files by name for predictable processing order
    usort($files, function($a, $b) { return strnatcasecmp($a['name'], $b['name']); });

    $total_files = count($files);
    echo '<div class="notice notice-info"><p>' . sprintf(__('Starting batch import of <strong>%d files</strong>...', 'microhub'), $total_files) . '</p></div>';
    flush(); ob_flush();

    // Grand totals
    $grand_imported = 0;
    $grand_skipped = 0;
    $grand_updated = 0;
    $grand_errors = 0;
    $grand_enrichment = array(
        'protocols' => 0, 'protocol_papers' => 0, 'repositories' => 0,
        'rrids' => 0, 'rors' => 0, 'microscopes' => 0, 'github' => 0,
        'github_tools' => 0, 'github_tools_papers' => 0, 'facilities' => 0,
        'affiliations' => 0,
    );

    foreach ($files as $file_index => $file) {
        $file_num = $file_index + 1;
        $file_name = esc_html($file['name']);
        $file_path = $file['tmp_name'];
        $file_size = $file['size'];

        echo '<hr style="margin:16px 0;border-color:#ddd;">';
        echo '<p><strong>' . sprintf(__('File %d/%d: %s', 'microhub'), $file_num, $total_files, $file_name) . '</strong> ';
        echo '(' . size_format($file_size) . ')</p>';
        flush(); ob_flush();

        $imported = 0;
        $skipped = 0;
        $updated = 0;
        $errors = 0;
        $batch_size = 100;

        $enrichment_stats = array(
            'protocols' => 0, 'protocol_papers' => 0, 'repositories' => 0,
            'rrids' => 0, 'rors' => 0, 'microscopes' => 0, 'github' => 0,
            'github_tools' => 0, 'github_tools_papers' => 0, 'facilities' => 0,
            'affiliations' => 0,
        );

        // For large files (>50MB), use streaming parser
        if ($file_size > 50 * 1024 * 1024) {
            $result = microhub_stream_import($file_path, $skip_existing, $update_existing, $enrichment_stats);
            $imported = $result['imported'];
            $skipped = $result['skipped'];
            $updated = $result['updated'];
            $errors = $result['errors'];
        } else {
            $json_content = file_get_contents($file_path);
            $papers = json_decode($json_content, true);

            if (!$papers || !is_array($papers)) {
                echo '<div class="notice notice-error"><p>' . sprintf(__('Skipping %s — invalid JSON format.', 'microhub'), $file_name) . '</p></div>';
                flush(); ob_flush();
                $grand_errors++;
                continue;
            }

            unset($json_content);

            $total = count($papers);
            $batches = array_chunk($papers, $batch_size);
            unset($papers);

            echo '<p>' . sprintf(__('Processing %d papers...', 'microhub'), $total) . '</p>';
            flush(); ob_flush();

            foreach ($batches as $batch_index => $batch) {
                global $wpdb;
                $wpdb->query('START TRANSACTION');

                foreach ($batch as $paper) {
                    try {
                        $result = microhub_import_paper($paper, $skip_existing, $update_existing, $enrichment_stats);

                        if ($result === 'imported') {
                            $imported++;
                        } elseif ($result === 'skipped') {
                            $skipped++;
                        } elseif ($result === 'updated') {
                            $updated++;
                        }
                    } catch (Exception $e) {
                        $errors++;
                        error_log('MicroHub import error (' . $file['name'] . '): ' . $e->getMessage());
                    }
                }

                $wpdb->query('COMMIT');

                // Progress update every 10 batches
                if ($batch_index % 10 === 0) {
                    $progress = min(100, round((($batch_index + 1) * $batch_size / $total) * 100));
                    echo '<script>console.log("File ' . $file_num . '/' . $total_files . ' progress: ' . $progress . '%");</script>';
                    flush(); ob_flush();
                    set_time_limit(300);
                }

                unset($batch);
            }
        }

        // Per-file summary
        echo '<p style="color:#006d00;">&#10003; ' . sprintf(
            __('Done — Imported: %d, Updated: %d, Skipped: %d, Errors: %d', 'microhub'),
            $imported, $updated, $skipped, $errors
        ) . '</p>';
        flush(); ob_flush();

        // Accumulate grand totals
        $grand_imported += $imported;
        $grand_skipped += $skipped;
        $grand_updated += $updated;
        $grand_errors += $errors;
        foreach ($grand_enrichment as $key => &$val) {
            $val += $enrichment_stats[$key] ?? 0;
        }
        unset($val);
    }

    // Clear caches once at the end
    delete_transient('mh_filter_options');
    wp_cache_flush();

    // Grand total summary
    echo '<hr style="margin:16px 0;border:2px solid #006d00;">';
    echo '<div class="notice notice-success"><p>';
    echo '<strong>' . sprintf(__('All %d files imported!', 'microhub'), $total_files) . '</strong><br>';
    echo sprintf(__('Total — Imported: %d, Updated: %d, Skipped: %d, Errors: %d', 'microhub'),
        $grand_imported, $grand_updated, $grand_skipped, $grand_errors);
    echo '</p>';
    echo '<p><strong>' . __('Enrichment Data Imported:', 'microhub') . '</strong><br>';
    echo sprintf(__('Protocol URLs: %d, Protocol Papers: %d, Repositories: %d, GitHub: %d, GitHub Tools: %d (across %d papers), Facilities: %d, Affiliations: %d, RRIDs: %d, RORs: %d, Microscopes: %d', 'microhub'),
        $grand_enrichment['protocols'], $grand_enrichment['protocol_papers'], $grand_enrichment['repositories'],
        $grand_enrichment['github'], $grand_enrichment['github_tools'], $grand_enrichment['github_tools_papers'],
        $grand_enrichment['facilities'], $grand_enrichment['affiliations'],
        $grand_enrichment['rrids'], $grand_enrichment['rors'], $grand_enrichment['microscopes']);
    echo '</p></div>';
}

/**
 * Stream import for very large files (>50MB)
 * Parses JSON line by line to avoid memory issues
 */
function microhub_stream_import($file_path, $skip_existing, $update_existing, &$enrichment_stats) {
    $imported = 0;
    $skipped = 0;
    $updated = 0;
    $errors = 0;

    global $wpdb;

    // Open file for streaming
    $handle = fopen($file_path, 'r');
    if (!$handle) {
        return array('imported' => 0, 'skipped' => 0, 'updated' => 0, 'errors' => 1);
    }

    $buffer = '';
    $in_array = false;
    $depth = 0;
    $batch = array();
    $batch_size = 50;

    while (!feof($handle)) {
        $chunk = fread($handle, 8192);
        $buffer .= $chunk;

        // Process complete JSON objects from buffer
        while (true) {
            // Skip leading whitespace and commas
            $buffer = ltrim($buffer, " \t\n\r,");

            // Check for array start
            if (!$in_array && substr($buffer, 0, 1) === '[') {
                $in_array = true;
                $buffer = substr($buffer, 1);
                continue;
            }

            // Check for array end
            if ($in_array && substr($buffer, 0, 1) === ']') {
                break 2; // End of file
            }

            // Find complete JSON object
            if (substr($buffer, 0, 1) !== '{') {
                break;
            }

            // Count braces to find complete object
            $depth = 0;
            $end = -1;
            $in_string = false;
            $escape = false;

            for ($i = 0; $i < strlen($buffer); $i++) {
                $char = $buffer[$i];

                if ($escape) {
                    $escape = false;
                    continue;
                }

                if ($char === '\\') {
                    $escape = true;
                    continue;
                }

                if ($char === '"') {
                    $in_string = !$in_string;
                    continue;
                }

                if (!$in_string) {
                    if ($char === '{') $depth++;
                    if ($char === '}') $depth--;

                    if ($depth === 0) {
                        $end = $i;
                        break;
                    }
                }
            }

            if ($end === -1) {
                break; // Need more data
            }

            // Extract and parse JSON object
            $json_str = substr($buffer, 0, $end + 1);
            $buffer = substr($buffer, $end + 1);

            $paper = json_decode($json_str, true);
            if ($paper) {
                $batch[] = $paper;

                // Process batch
                if (count($batch) >= $batch_size) {
                    $wpdb->query('START TRANSACTION');

                    foreach ($batch as $p) {
                        try {
                            $result = microhub_import_paper($p, $skip_existing, $update_existing, $enrichment_stats);
                            if ($result === 'imported') $imported++;
                            elseif ($result === 'skipped') $skipped++;
                            elseif ($result === 'updated') $updated++;
                        } catch (Exception $e) {
                            $errors++;
                        }
                    }

                    $wpdb->query('COMMIT');
                    $batch = array();

                    // Reset time limit
                    set_time_limit(300);

                    // Progress update
                    $processed = $imported + $skipped + $updated + $errors;
                    if ($processed % 1000 === 0) {
                        echo '<script>console.log("Processed: ' . $processed . ' papers");</script>';
                        flush();
                        ob_flush();
                    }
                }
            } else {
                $errors++;
            }
        }
    }

    // Process remaining batch
    if (!empty($batch)) {
        $wpdb->query('START TRANSACTION');
        foreach ($batch as $p) {
            try {
                $result = microhub_import_paper($p, $skip_existing, $update_existing, $enrichment_stats);
                if ($result === 'imported') $imported++;
                elseif ($result === 'skipped') $skipped++;
                elseif ($result === 'updated') $updated++;
            } catch (Exception $e) {
                $errors++;
            }
        }
        $wpdb->query('COMMIT');
    }

    fclose($handle);

    return array(
        'imported' => $imported,
        'skipped' => $skipped,
        'updated' => $updated,
        'errors' => $errors
    );
}

/**
 * Normalize DOI for consistent comparison
 * Removes common prefixes and standardizes format
 */
function microhub_normalize_doi($doi) {
    if (empty($doi)) {
        return '';
    }

    $doi = trim($doi);

    // Remove common URL prefixes
    $prefixes = array(
        'https://doi.org/',
        'http://doi.org/',
        'https://dx.doi.org/',
        'http://dx.doi.org/',
        'doi.org/',
        'dx.doi.org/',
        'doi:',
        'DOI:',
        'doi: ',
        'DOI: ',
    );

    foreach ($prefixes as $prefix) {
        if (stripos($doi, $prefix) === 0) {
            $doi = substr($doi, strlen($prefix));
            break;
        }
    }

    // Remove any remaining whitespace
    $doi = trim($doi);

    // Convert to lowercase for consistent comparison
    // Note: DOIs are case-insensitive per the DOI specification
    $doi = strtolower($doi);

    return $doi;
}

/**
 * Import a single paper with ALL enrichment data
 */
function microhub_import_paper($data, $skip_existing, $update_existing, &$enrichment_stats) {
    // Normalize DOI - remove prefixes like 'doi:', 'DOI:', 'https://doi.org/', etc.
    $doi = isset($data['doi']) ? sanitize_text_field($data['doi']) : '';
    $doi = microhub_normalize_doi($doi);

    // Get PMID for fallback check
    $pmid = isset($data['pmid']) ? sanitize_text_field($data['pmid']) : '';

    // Get title for last-resort check
    $title = isset($data['title']) ? sanitize_text_field($data['title']) : '';

    $existing = null;
    $is_update = false;
    $post_id = null;

    // Check if paper already exists - try DOI first, then PMID, then title
    if (!empty($doi)) {
        $existing = get_posts(array(
            'post_type' => array('mh_paper', 'mh_protocol'),
            'meta_key' => '_mh_doi',
            'meta_value' => $doi,
            'posts_per_page' => 1,
            'post_status' => 'any',
        ));
    }

    // Fallback to PMID if DOI not found or empty
    if (empty($existing) && !empty($pmid)) {
        $existing = get_posts(array(
            'post_type' => array('mh_paper', 'mh_protocol'),
            'meta_key' => '_mh_pubmed_id',
            'meta_value' => $pmid,
            'posts_per_page' => 1,
            'post_status' => 'any',
        ));
    }

    // Last resort: check by exact title match (only if both DOI and PMID are empty)
    if (empty($existing) && empty($doi) && empty($pmid) && !empty($title)) {
        $existing = get_posts(array(
            'post_type' => array('mh_paper', 'mh_protocol'),
            'title' => $title,
            'posts_per_page' => 1,
            'post_status' => 'any',
        ));
    }

    if (!empty($existing)) {
        if ($skip_existing && !$update_existing) {
            return 'skipped';
        }
        $post_id = $existing[0]->ID;
        $is_update = true;
    }

    // ============================================
    // DETERMINE POST TYPE FROM JSON DATA
    // The Python cleanup script sets post_type and protocol_type
    // ============================================
    $post_type = 'mh_paper'; // Default
    $protocol_type = null;
    
    // Check if JSON specifies post_type (from Python cleanup script)
    if (!empty($data['post_type']) && $data['post_type'] === 'mh_protocol') {
        $post_type = 'mh_protocol';
        $protocol_type = !empty($data['protocol_type']) ? sanitize_text_field($data['protocol_type']) : null;
    }
    // Also check is_protocol flag
    elseif (!empty($data['is_protocol'])) {
        $post_type = 'mh_paper'; // Keep as paper but will tag with protocol_type
        $protocol_type = !empty($data['protocol_type']) ? sanitize_text_field($data['protocol_type']) : null;
    }
    
    // Fallback: detect protocol journals by name if not already set
    if (!$protocol_type) {
        $journal = isset($data['journal']) ? strtolower($data['journal']) : '';
        $protocol_journal_map = array(
            'jove' => 'JoVE',
            'journal of visualized experiments' => 'JoVE',
            'j. vis. exp' => 'JoVE',
            'nature protocols' => 'Nature Protocols',
            'nat protoc' => 'Nature Protocols',
            'nat. protoc' => 'Nature Protocols',
            'bio-protocol' => 'Bio-protocol',
            'bio protocol' => 'Bio-protocol',
            'bioprotocol' => 'Bio-protocol',
            'star protocols' => 'STAR Protocols',
            'current protocols' => 'Current Protocols',
            'curr protoc' => 'Current Protocols',
            'cold spring harbor protocols' => 'Cold Spring Harbor Protocols',
            'cold spring harb protoc' => 'Cold Spring Harbor Protocols',
            'csh protocols' => 'Cold Spring Harbor Protocols',
            'methods in molecular biology' => 'Methods in Molecular Biology',
            'methods mol biol' => 'Methods in Molecular Biology',
            'methods in enzymology' => 'Methods in Enzymology',
            'meth enzymol' => 'Methods in Enzymology',
            'methodsx' => 'MethodsX',
            'methods x' => 'MethodsX',
            'protocol exchange' => 'Protocol Exchange',
            'biotechniques' => 'Biotechniques',
        );
        
        foreach ($protocol_journal_map as $pattern => $type) {
            if (stripos($journal, $pattern) !== false) {
                $protocol_type = $type;
                break;
            }
        }
    }

    // Create or update post
    $post_data = array(
        'post_type' => $post_type,
        'post_title' => sanitize_text_field($data['title']),
        'post_status' => 'publish',
        'post_content' => '',
    );

    if ($is_update) {
        $post_data['ID'] = $post_id;
        wp_update_post($post_data);
    } else {
        $post_id = wp_insert_post($post_data);
    }

    if (is_wp_error($post_id)) {
        throw new Exception('Failed to create post');
    }

    // Save core metadata
    update_post_meta($post_id, '_mh_doi', $doi);
    update_post_meta($post_id, '_mh_pubmed_id', isset($data['pmid']) ? sanitize_text_field($data['pmid']) : '');
    update_post_meta($post_id, '_mh_authors', isset($data['authors']) ? sanitize_text_field($data['authors']) : '');
    update_post_meta($post_id, '_mh_journal', isset($data['journal']) ? sanitize_text_field($data['journal']) : '');
    update_post_meta($post_id, '_mh_publication_year', isset($data['year']) ? intval($data['year']) : 0);
    
    // Handle citation count - check both field names
    $citation_count = 0;
    if (isset($data['citations'])) {
        $citation_count = intval($data['citations']);
    } elseif (isset($data['citation_count'])) {
        $citation_count = intval($data['citation_count']);
    }
    update_post_meta($post_id, '_mh_citation_count', $citation_count);
    
    update_post_meta($post_id, '_mh_abstract', isset($data['abstract']) ? sanitize_textarea_field($data['abstract']) : '');
    update_post_meta($post_id, '_mh_pdf_url', isset($data['pdf_url']) ? esc_url_raw($data['pdf_url']) : '');
    update_post_meta($post_id, '_mh_paper_url', isset($data['paper_url']) ? esc_url_raw($data['paper_url']) : '');

    // Save microscope info
    if (!empty($data['microscope']) && is_array($data['microscope'])) {
        update_post_meta($post_id, '_mh_microscope', sanitize_text_field($data['microscope']['name']));
        update_post_meta($post_id, '_mh_microscope_brand', sanitize_text_field($data['microscope']['brand']));
        update_post_meta($post_id, '_mh_microscope_model', sanitize_text_field($data['microscope']['model']));
        $enrichment_stats['microscopes']++;
    }

    // Save protocols (JSON array)
    if (!empty($data['protocols']) && is_array($data['protocols'])) {
        $protocols = array_map(function($p) {
            // Get URL - handle case where URL might be in name field
            $url = isset($p['url']) ? trim($p['url']) : '';
            $name = isset($p['name']) ? trim($p['name']) : '';
            
            // If URL is empty but name looks like a URL, swap them
            if (empty($url) && $name && (strpos($name, 'http') === 0 || strpos($name, 'protocols.io') !== false || strpos($name, '.com') !== false || strpos($name, '.org') !== false)) {
                $url = $name;
                $name = 'Protocol';
            }
            
            // Ensure URL has scheme
            if ($url && strpos($url, 'http') !== 0) {
                $url = 'https://' . ltrim($url, '/');
            }
            
            return array(
                'name' => sanitize_text_field($name ?: 'Protocol'),
                'url' => esc_url_raw($url),
                'source' => isset($p['source']) ? sanitize_text_field($p['source']) : 'fulltext',
            );
        }, $data['protocols']);
        
        // Filter out protocols with neither a URL nor a name
        $protocols = array_filter($protocols, function($p) {
            return !empty($p['url']) || !empty($p['name']);
        });
        
        if (!empty($protocols)) {
            update_post_meta($post_id, '_mh_protocols', wp_json_encode(array_values($protocols)));
            update_post_meta($post_id, '_mh_has_protocols', '1');
            $enrichment_stats['protocols'] += count($protocols);
        }
    }
    
    // Also check has_protocols flag from JSON data
    if (!empty($data['has_protocols'])) {
        update_post_meta($post_id, '_mh_has_protocols', '1');
    }

    // Save repositories (JSON array) - check both field names
    $repos_data = null;
    if (!empty($data['repositories']) && is_array($data['repositories'])) {
        $repos_data = $data['repositories'];
    } elseif (!empty($data['image_repositories']) && is_array($data['image_repositories'])) {
        $repos_data = $data['image_repositories'];
    }
    if ($repos_data) {
        $repositories = array_map(function($r) {
            // Get URL
            $url = isset($r['url']) ? trim($r['url']) : '';
            
            // Get name - check both 'name' and 'type' fields (scraper uses 'type')
            $name = '';
            if (isset($r['name']) && !empty(trim($r['name']))) {
                $name = trim($r['name']);
            } elseif (isset($r['type']) && !empty(trim($r['type']))) {
                $name = trim($r['type']);
            }
            
            // Get accession ID - check both 'accession_id' and 'identifier' fields
            $accession_id = '';
            if (isset($r['accession_id']) && !empty(trim($r['accession_id']))) {
                $accession_id = trim($r['accession_id']);
            } elseif (isset($r['identifier']) && !empty(trim($r['identifier']))) {
                $accession_id = trim($r['identifier']);
            }
            
            // If URL is empty but name looks like a URL, swap them
            if (empty($url) && $name && (strpos($name, 'http') === 0 || strpos($name, 'zenodo') !== false || strpos($name, 'figshare') !== false)) {
                $url = $name;
                $name = 'Repository';
            }
            
            // If still no name, try to detect from URL
            if (empty($name) && $url) {
                if (strpos($url, 'zenodo') !== false) {
                    $name = 'Zenodo';
                } elseif (strpos($url, 'figshare') !== false) {
                    $name = 'Figshare';
                } elseif (strpos($url, 'github') !== false) {
                    $name = 'GitHub';
                } elseif (strpos($url, 'dryad') !== false) {
                    $name = 'Dryad';
                } elseif (strpos($url, 'osf.io') !== false) {
                    $name = 'OSF';
                } elseif (strpos($url, 'dataverse') !== false) {
                    $name = 'Dataverse';
                } elseif (strpos($url, 'mendeley') !== false) {
                    $name = 'Mendeley Data';
                } elseif (strpos($url, 'synapse') !== false) {
                    $name = 'Synapse';
                } elseif (strpos($url, 'ebi.ac.uk') !== false || strpos($url, 'empiar') !== false) {
                    $name = 'EMPIAR';
                } else {
                    $name = 'Data Repository';
                }
            }
            
            // Ensure URL has scheme
            if ($url && strpos($url, 'http') !== 0) {
                $url = 'https://' . ltrim($url, '/');
            }
            
            return array(
                'name' => sanitize_text_field($name),
                'url' => esc_url_raw($url),
                'accession_id' => sanitize_text_field($accession_id),
            );
        }, $repos_data);
        
        // Filter out repos with neither a URL nor a name
        $repositories = array_filter($repositories, function($r) {
            return !empty($r['url']) || !empty($r['name']);
        });

        // Deduplicate repositories by URL
        $seen_urls = array();
        $repositories = array_filter($repositories, function($r) use (&$seen_urls) {
            $url = strtolower(trim($r['url']));
            // Normalize URL (remove trailing slashes, www, etc.)
            $url = rtrim($url, '/');
            $url = preg_replace('/^https?:\/\/(www\.)?/', '', $url);
            if (isset($seen_urls[$url])) {
                return false;
            }
            $seen_urls[$url] = true;
            return true;
        });

        if (!empty($repositories)) {
            update_post_meta($post_id, '_mh_repositories', wp_json_encode(array_values($repositories)));
            update_post_meta($post_id, '_mh_has_data', '1');
            $enrichment_stats['repositories'] += count($repositories);
        }
    }
    // Also check has_data flag from JSON data
    if (!empty($data['has_data'])) {
        update_post_meta($post_id, '_mh_has_data', '1');
    }

    // Save RRIDs (JSON array)
    if (!empty($data['rrids']) && is_array($data['rrids'])) {
        $rrids = array_map(function($r) {
            return array(
                'id' => sanitize_text_field($r['id']),
                'type' => sanitize_text_field($r['type']),
                'url' => isset($r['url']) ? esc_url_raw($r['url']) : 'https://scicrunch.org/resolver/' . $r['id'],
            );
        }, $data['rrids']);
        update_post_meta($post_id, '_mh_rrids', wp_json_encode($rrids));
        update_post_meta($post_id, '_mh_has_rrids', '1');
        $enrichment_stats['rrids'] += count($rrids);
    }
    // Also check has_rrids flag from JSON data
    if (!empty($data['has_rrids'])) {
        update_post_meta($post_id, '_mh_has_rrids', '1');
    }

    // Save RORs - Research Organization Registry identifiers (JSON array)
    if (!empty($data['rors']) && is_array($data['rors'])) {
        $rors = array_map(function($r) {
            // Handle both object format and simple string format
            if (is_array($r)) {
                // Normalize: extract bare ROR ID from full URL if needed
                $raw_id = sanitize_text_field($r['id'] ?? '');
                $raw_id = preg_replace('#^https?://ror\.org/#', '', $raw_id);
                return array(
                    'id' => $raw_id,
                    'name' => sanitize_text_field($r['name'] ?? ''),
                    'url' => isset($r['url']) ? esc_url_raw($r['url']) : 'https://ror.org/' . $raw_id,
                    'source' => sanitize_text_field($r['source'] ?? 'unknown'),
                );
            } else {
                // Simple string format (just the ID or URL)
                $ror_id = sanitize_text_field($r);
                $ror_id = preg_replace('#^https?://ror\.org/#', '', $ror_id);
                return array(
                    'id' => $ror_id,
                    'name' => '',
                    'url' => 'https://ror.org/' . $ror_id,
                    'source' => 'unknown',
                );
            }
        }, $data['rors']);
        // Filter out empty entries
        $rors = array_filter($rors, function($r) { return !empty($r['id']); });
        // Deduplicate by normalized ROR ID
        $seen_ids = array();
        $deduped = array();
        foreach ($rors as $ror) {
            $norm = strtolower(trim($ror['id']));
            if (!isset($seen_ids[$norm])) {
                $seen_ids[$norm] = true;
                $deduped[] = $ror;
            }
        }
        $rors = $deduped;
        if (!empty($rors)) {
            update_post_meta($post_id, '_mh_rors', wp_json_encode(array_values($rors)));
            update_post_meta($post_id, '_mh_has_rors', '1');
            $enrichment_stats['rors'] = ($enrichment_stats['rors'] ?? 0) + count($rors);
        }
    }
    // Also check has_rors flag from JSON data
    if (!empty($data['has_rors'])) {
        update_post_meta($post_id, '_mh_has_rors', '1');
    }

    // Save antibody sources (species used for antibodies, not model organisms)
    if (!empty($data['antibody_sources']) && is_array($data['antibody_sources'])) {
        $antibody_sources = array_map('sanitize_text_field', $data['antibody_sources']);
        wp_set_object_terms($post_id, $antibody_sources, 'mh_antibody_source');
        update_post_meta($post_id, '_mh_antibody_sources', wp_json_encode($antibody_sources));
    }

    // Save antibodies (JSON array of antibody identifiers)
    if (!empty($data['antibodies']) && is_array($data['antibodies'])) {
        $antibodies = array_map(function($ab) {
            // Handle both object format and simple string format
            if (is_array($ab)) {
                return array(
                    'id' => sanitize_text_field($ab['id'] ?? ''),
                    'source' => sanitize_text_field($ab['source'] ?? 'unknown'),
                    'url' => isset($ab['url']) ? esc_url_raw($ab['url']) : '',
                );
            } else {
                return array(
                    'id' => sanitize_text_field($ab),
                    'source' => 'unknown',
                    'url' => '',
                );
            }
        }, $data['antibodies']);
        // Filter out empty entries
        $antibodies = array_filter($antibodies, function($ab) { return !empty($ab['id']); });
        if (!empty($antibodies)) {
            update_post_meta($post_id, '_mh_antibodies', wp_json_encode(array_values($antibodies)));
            $enrichment_stats['antibodies'] = ($enrichment_stats['antibodies'] ?? 0) + count($antibodies);
        }
    }

    // Save tag extraction source (methods vs title_abstract)
    if (!empty($data['tag_source'])) {
        update_post_meta($post_id, '_mh_tag_source', sanitize_text_field($data['tag_source']));
    }

    // Save GitHub URL (check multiple possible field names)
    $github_url = '';
    if (!empty($data['github_url'])) {
        $github_url = $data['github_url'];
    } elseif (!empty($data['github'])) {
        $github_url = $data['github'];
    } elseif (!empty($data['code_repository'])) {
        $github_url = $data['code_repository'];
    } elseif (!empty($data['meta_data']['github'])) {
        $github_url = $data['meta_data']['github'];
    }
    if ($github_url) {
        update_post_meta($post_id, '_mh_github_url', esc_url_raw($github_url));
        update_post_meta($post_id, '_mh_has_github', '1');
        $enrichment_stats['github'] = ($enrichment_stats['github'] ?? 0) + 1;
    }
    // Also check has_github flag from JSON data
    if (!empty($data['has_github'])) {
        update_post_meta($post_id, '_mh_has_github', '1');
    }

    // Save GitHub tools data (detailed repo info from scraper v5.1+)
    if (!empty($data['github_tools']) && is_array($data['github_tools'])) {
        $github_tools = array_map(function($tool) {
            return array(
                'full_name'        => sanitize_text_field($tool['full_name'] ?? ''),
                'url'              => esc_url_raw($tool['url'] ?? ''),
                'description'      => sanitize_text_field($tool['description'] ?? ''),
                'stars'            => intval($tool['stars'] ?? 0),
                'forks'            => intval($tool['forks'] ?? 0),
                'open_issues'      => intval($tool['open_issues'] ?? 0),
                'last_commit_date' => sanitize_text_field($tool['last_commit_date'] ?? ''),
                'last_release'     => sanitize_text_field($tool['last_release'] ?? ''),
                'health_score'     => intval($tool['health_score'] ?? 0),
                'is_archived'      => !empty($tool['is_archived']),
                'language'         => sanitize_text_field($tool['language'] ?? ''),
                'license'          => sanitize_text_field($tool['license'] ?? ''),
                'topics'           => is_array($tool['topics'] ?? null) ? array_map('sanitize_text_field', $tool['topics']) : array(),
                'paper_count'      => intval($tool['paper_count'] ?? 0),
                'citing_paper_count' => intval($tool['citing_paper_count'] ?? 0),
                'relationship'     => sanitize_text_field($tool['relationship'] ?? 'uses'),
            );
        }, $data['github_tools']);

        // Filter out entries with no full_name
        $github_tools = array_filter($github_tools, function($t) {
            return !empty($t['full_name']);
        });

        if (!empty($github_tools)) {
            update_post_meta($post_id, '_mh_github_tools', wp_json_encode(array_values($github_tools)));
            update_post_meta($post_id, '_mh_has_github_tools', '1');
            $enrichment_stats['github_tools'] = ($enrichment_stats['github_tools'] ?? 0) + count($github_tools);
            $enrichment_stats['github_tools_papers'] = ($enrichment_stats['github_tools_papers'] ?? 0) + 1;

            // Auto-populate github_url from tools if it wasn't already set
            if (empty($github_url)) {
                // Prefer 'introduces' relationship (paper's own tool)
                $introduced = array_filter($github_tools, function($t) { return $t['relationship'] === 'introduces'; });
                $best_tool = !empty($introduced) ? reset($introduced) : reset($github_tools);
                if (!empty($best_tool['url'])) {
                    update_post_meta($post_id, '_mh_github_url', esc_url_raw($best_tool['url']));
                    update_post_meta($post_id, '_mh_has_github', '1');
                    $enrichment_stats['github'] = ($enrichment_stats['github'] ?? 0) + 1;
                }
            }
        }
    }
    // Also check has_github_tools flag from JSON data
    if (!empty($data['has_github_tools'])) {
        update_post_meta($post_id, '_mh_has_github_tools', '1');
    }

    // Save raw affiliations from scraper v5 (author affiliation strings from PubMed)
    if (!empty($data['affiliations']) && is_array($data['affiliations'])) {
        $affiliations = array_map('sanitize_text_field', $data['affiliations']);
        update_post_meta($post_id, '_mh_affiliations', wp_json_encode($affiliations));
        if (!isset($enrichment_stats['affiliations'])) {
            $enrichment_stats['affiliations'] = 0;
        }
        $enrichment_stats['affiliations']++;
    }

    // Save facility/institution info and set as taxonomy
    $facility = '';
    $facilities = array();
    $facility_url = '';
    
    // NEW: Check for institutions field first (v3 cleanup script)
    if (!empty($data['institutions']) && is_array($data['institutions'])) {
        $facilities = $data['institutions'];
        $facility = $facilities[0] ?? '';
    }
    // Check for affiliations and extract institution names if no institutions field
    elseif (!empty($data['affiliations']) && is_array($data['affiliations'])) {
        // Use affiliations as facilities for display
        $facilities = array_map('sanitize_text_field', $data['affiliations']);
        $facility = $facilities[0] ?? '';
    }
    // Fall back to facilities field
    elseif (!empty($data['facilities']) && is_array($data['facilities'])) {
        $facilities = $data['facilities'];
        $facility = $facilities[0] ?? '';
    }
    // Fall back to single facility field
    elseif (!empty($data['facility'])) {
        $facility = $data['facility'];
        $facilities = array($facility);
    } elseif (!empty($data['imaging_facility'])) {
        $facility = $data['imaging_facility'];
        $facilities = array($facility);
    } elseif (!empty($data['meta_data']['facility'])) {
        $facility = $data['meta_data']['facility'];
        $facilities = array($facility);
    }
    
    // Get facility URL/website if present
    if (!empty($data['facility_url'])) {
        $facility_url = $data['facility_url'];
    } elseif (!empty($data['facility_website'])) {
        $facility_url = $data['facility_website'];
    }
    
    if ($facility) {
        update_post_meta($post_id, '_mh_facility', sanitize_text_field($facility));
        $enrichment_stats['facilities'] = ($enrichment_stats['facilities'] ?? 0) + 1;
    }
    
    // Save all institutions/facilities as JSON and set taxonomy
    if (!empty($facilities)) {
        update_post_meta($post_id, '_mh_institutions', wp_json_encode($facilities));
        update_post_meta($post_id, '_mh_facilities', wp_json_encode($facilities)); // Backward compatibility
        // Set facility taxonomy for searchability
        wp_set_object_terms($post_id, $facilities, 'mh_facility');
    }
    
    // Save facility URL
    if ($facility_url) {
        update_post_meta($post_id, '_mh_facility_url', esc_url_raw($facility_url));
    }

    // Save figure URLs (for thumbnails)
    if (!empty($data['figure_urls']) && is_array($data['figure_urls'])) {
        $figure_urls = array_map('esc_url_raw', $data['figure_urls']);
        update_post_meta($post_id, '_mh_figure_urls', wp_json_encode($figure_urls));
        // Use first figure as thumbnail URL
        if (!empty($figure_urls[0])) {
            update_post_meta($post_id, '_mh_thumbnail_url', esc_url_raw($figure_urls[0]));
        }
    }

    // Save link validation status (JSON object)
    if (!empty($data['link_status']) && is_array($data['link_status'])) {
        update_post_meta($post_id, '_mh_link_status', wp_json_encode($data['link_status']));
    }

    // Save additional metadata
    if (!empty($data['meta_data']) && is_array($data['meta_data'])) {
        if (!empty($data['meta_data']['primary_technique'])) {
            update_post_meta($post_id, '_mh_primary_technique', sanitize_text_field($data['meta_data']['primary_technique']));
        }
        if (!empty($data['meta_data']['animal_model'])) {
            update_post_meta($post_id, '_mh_animal_model', sanitize_text_field($data['meta_data']['animal_model']));
        }
        if (!empty($data['meta_data']['last_author'])) {
            update_post_meta($post_id, '_mh_last_author', sanitize_text_field($data['meta_data']['last_author']));
        }
    }

    // Also check top-level fields (export script puts these at top level)
    if (!empty($data['primary_technique'])) {
        update_post_meta($post_id, '_mh_primary_technique', sanitize_text_field($data['primary_technique']));
    }
    if (!empty($data['animal_model'])) {
        update_post_meta($post_id, '_mh_animal_model', sanitize_text_field($data['animal_model']));
    }
    if (!empty($data['last_author'])) {
        update_post_meta($post_id, '_mh_last_author', sanitize_text_field($data['last_author']));
    }
    if (!empty($data['pmc_id'])) {
        update_post_meta($post_id, '_mh_pmc_id', sanitize_text_field($data['pmc_id']));
    }

    // Set comprehensive tags (all extracted categories) as WordPress post_tag
    // Individual categories are imported separately into their own taxonomies below
    if (!empty($data['tags']) && is_array($data['tags'])) {
        wp_set_object_terms($post_id, $data['tags'], 'post_tag');
    }

    // Set organism taxonomy - check both locations
    $animal = '';
    if (!empty($data['animal_model'])) {
        $animal = $data['animal_model'];
    } elseif (!empty($data['meta_data']['animal_model'])) {
        $animal = $data['meta_data']['animal_model'];
    }
    if ($animal) {
        wp_set_object_terms($post_id, array($animal), 'mh_organism');
    }

    // Set microscope taxonomy (models, not brands)
    if (!empty($data['microscope']['model'])) {
        wp_set_object_terms($post_id, array($data['microscope']['model']), 'mh_microscope');
    }

    // Set software taxonomy
    if (!empty($data['software']) && is_array($data['software'])) {
        wp_set_object_terms($post_id, $data['software'], 'mh_software');
    }

    // Also handle organisms array if present
    if (!empty($data['organisms']) && is_array($data['organisms'])) {
        wp_set_object_terms($post_id, $data['organisms'], 'mh_organism');
        // Also save as JSON meta for theme compatibility
        update_post_meta($post_id, '_mh_organisms', wp_json_encode($data['organisms']));
    }

    // Also handle techniques array if present (in addition to tags)
    if (!empty($data['techniques']) && is_array($data['techniques'])) {
        wp_set_object_terms($post_id, $data['techniques'], 'mh_technique', true); // true = append
    }

    // v3 scraper fields - microscopy techniques
    if (!empty($data['microscopy_techniques']) && is_array($data['microscopy_techniques'])) {
        wp_set_object_terms($post_id, $data['microscopy_techniques'], 'mh_technique', true);
        // Also save as JSON meta for theme compatibility
        update_post_meta($post_id, '_mh_microscopy_techniques', wp_json_encode($data['microscopy_techniques']));
    }

    // v3 scraper fields - microscope brands (save as meta only, not into mh_microscope taxonomy)
    if (!empty($data['microscope_brands']) && is_array($data['microscope_brands'])) {
        // Also save as JSON meta for theme compatibility
        update_post_meta($post_id, '_mh_microscope_brands', wp_json_encode($data['microscope_brands']));
    }

    // v3 scraper fields - microscope models → mh_microscope taxonomy (primary) + mh_microscope_model
    if (!empty($data['microscope_models']) && is_array($data['microscope_models'])) {
        wp_set_object_terms($post_id, $data['microscope_models'], 'mh_microscope', true);
        wp_set_object_terms($post_id, $data['microscope_models'], 'mh_microscope_model');
        // Also save as JSON meta for theme compatibility
        update_post_meta($post_id, '_mh_microscope_models', wp_json_encode($data['microscope_models']));
    }

    // Image analysis software (Fiji, ImageJ, CellProfiler, etc.) — own taxonomy only
    if (!empty($data['image_analysis_software']) && is_array($data['image_analysis_software'])) {
        wp_set_object_terms($post_id, $data['image_analysis_software'], 'mh_analysis_software');
        update_post_meta($post_id, '_mh_image_analysis_software', wp_json_encode($data['image_analysis_software']));
    }

    // Image acquisition software (ZEN, LAS X, NIS-Elements, etc.) — own taxonomy only
    if (!empty($data['image_acquisition_software']) && is_array($data['image_acquisition_software'])) {
        wp_set_object_terms($post_id, $data['image_acquisition_software'], 'mh_acquisition_software');
        update_post_meta($post_id, '_mh_image_acquisition_software', wp_json_encode($data['image_acquisition_software']));
    }

    // v3 scraper fields - reagent suppliers (separated from microscope brands)
    if (!empty($data['reagent_suppliers']) && is_array($data['reagent_suppliers'])) {
        wp_set_object_terms($post_id, $data['reagent_suppliers'], 'mh_reagent_supplier');
        // Also save as JSON meta for theme compatibility
        update_post_meta($post_id, '_mh_reagent_suppliers', wp_json_encode($data['reagent_suppliers']));
    }

    // General software (MATLAB, R, Excel, etc.) — own taxonomy only
    if (!empty($data['general_software']) && is_array($data['general_software'])) {
        wp_set_object_terms($post_id, $data['general_software'], 'mh_general_software');
        update_post_meta($post_id, '_mh_general_software', wp_json_encode($data['general_software']));
    }

    // v3 scraper fields - sample preparation
    if (!empty($data['sample_preparation']) && is_array($data['sample_preparation'])) {
        wp_set_object_terms($post_id, $data['sample_preparation'], 'mh_sample_prep');
        // Also save as JSON meta for theme compatibility
        update_post_meta($post_id, '_mh_sample_preparation', wp_json_encode($data['sample_preparation']));
    }

    // v3 scraper fields - fluorophores
    if (!empty($data['fluorophores']) && is_array($data['fluorophores'])) {
        wp_set_object_terms($post_id, $data['fluorophores'], 'mh_fluorophore');
        // Also save as JSON meta for theme compatibility
        update_post_meta($post_id, '_mh_fluorophores', wp_json_encode($data['fluorophores']));
    }

    // v4 scraper fields - cell lines
    if (!empty($data['cell_lines']) && is_array($data['cell_lines'])) {
        wp_set_object_terms($post_id, $data['cell_lines'], 'mh_cell_line');
        // Also save as JSON meta for theme compatibility
        update_post_meta($post_id, '_mh_cell_lines', wp_json_encode($data['cell_lines']));
        update_post_meta($post_id, '_mh_has_cell_lines', '1');
    }
    // Also check has_cell_lines flag from JSON data
    if (!empty($data['has_cell_lines'])) {
        update_post_meta($post_id, '_mh_has_cell_lines', '1');
    }

    // ============================================
    // APPLY PROTOCOL TYPE TAXONOMY
    // Uses $protocol_type determined at post creation time
    // ============================================
    if (!empty($protocol_type)) {
        // Set the protocol type taxonomy on the post
        wp_set_object_terms($post_id, $protocol_type, 'mh_protocol_type');
        
        // Set the is_protocol flag
        update_post_meta($post_id, '_mh_is_protocol', '1');
        
        // IMPORTANT: Papers from protocol journals ARE protocols!
        // Set has_protocols so they show up in the Protocols filter
        update_post_meta($post_id, '_mh_has_protocols', '1');
        
        // Store the protocol type as meta too
        update_post_meta($post_id, '_mh_protocol_type', $protocol_type);
        
        // Track for stats
        if (!isset($enrichment_stats['protocol_papers'])) {
            $enrichment_stats['protocol_papers'] = 0;
        }
        $enrichment_stats['protocol_papers']++;
    }
    // ============================================
    // END PROTOCOL TYPE TAXONOMY
    // ============================================

    // ============================================
    // KNOWLEDGE BASE ENHANCED TAGGING
    // Use uploaded knowledge documents to suggest additional tags
    // ============================================
    if (function_exists('mh_get_tag_suggestions')) {
        $title = !empty($data['title']) ? $data['title'] : '';
        $abstract = !empty($data['abstract']) ? $data['abstract'] : '';
        
        if ($title || $abstract) {
            // Get existing tags to avoid duplicates
            $existing_techniques = wp_get_object_terms($post_id, 'mh_technique', array('fields' => 'names'));
            $existing_software = wp_get_object_terms($post_id, 'mh_software', array('fields' => 'names'));
            $existing_microscopes = wp_get_object_terms($post_id, 'mh_microscope', array('fields' => 'names'));
            $existing_all = array_merge(
                is_array($existing_techniques) ? $existing_techniques : array(),
                is_array($existing_software) ? $existing_software : array(),
                is_array($existing_microscopes) ? $existing_microscopes : array()
            );
            
            // Get suggestions from knowledge base
            $suggestions = mh_get_tag_suggestions($title, $abstract, $existing_all);
            
            // Apply suggested techniques
            if (!empty($suggestions['techniques'])) {
                wp_set_object_terms($post_id, $suggestions['techniques'], 'mh_technique', true);
                if (!isset($enrichment_stats['kb_techniques'])) {
                    $enrichment_stats['kb_techniques'] = 0;
                }
                $enrichment_stats['kb_techniques'] += count($suggestions['techniques']);
            }
            
            // Apply suggested software
            if (!empty($suggestions['software'])) {
                wp_set_object_terms($post_id, $suggestions['software'], 'mh_software', true);
                if (!isset($enrichment_stats['kb_software'])) {
                    $enrichment_stats['kb_software'] = 0;
                }
                $enrichment_stats['kb_software'] += count($suggestions['software']);
            }
            
            // Apply suggested microscopes
            if (!empty($suggestions['microscopes'])) {
                wp_set_object_terms($post_id, $suggestions['microscopes'], 'mh_microscope', true);
                if (!isset($enrichment_stats['kb_microscopes'])) {
                    $enrichment_stats['kb_microscopes'] = 0;
                }
                $enrichment_stats['kb_microscopes'] += count($suggestions['microscopes']);
            }
            
            // Apply suggested fluorophores
            if (!empty($suggestions['fluorophores'])) {
                wp_set_object_terms($post_id, $suggestions['fluorophores'], 'mh_fluorophore', true);
            }
            
            // Apply suggested organisms
            if (!empty($suggestions['organisms'])) {
                wp_set_object_terms($post_id, $suggestions['organisms'], 'mh_organism', true);
            }
        }
    }
    // ============================================
    // END KNOWLEDGE BASE ENHANCED TAGGING
    // ============================================

    // v4.1 scraper fields - figures (full objects with captions)
    if (!empty($data['figures']) && is_array($data['figures'])) {
        update_post_meta($post_id, '_mh_figures', wp_json_encode($data['figures']));
        update_post_meta($post_id, '_mh_figure_count', count($data['figures']));
    } elseif (!empty($data['figure_count'])) {
        update_post_meta($post_id, '_mh_figure_count', intval($data['figure_count']));
    }

    // v4.1 scraper fields - methods section
    if (!empty($data['methods'])) {
        update_post_meta($post_id, '_mh_methods', sanitize_textarea_field($data['methods']));
    }

    // NOTE: full_text is no longer imported to save database space
    // Tags are still extracted from full_text by the cleanup script, but the text itself is not stored
    // The website displays the abstract with tag highlighting instead
    
    // References (JSON array)
    if (!empty($data['references']) && is_array($data['references'])) {
        $references = array_map(function($ref) {
            return array(
                'num' => isset($ref['num']) ? intval($ref['num']) : null,
                'text' => isset($ref['text']) ? sanitize_textarea_field($ref['text']) : '',
                'doi' => isset($ref['doi']) ? sanitize_text_field($ref['doi']) : '',
                'pmid' => isset($ref['pmid']) ? sanitize_text_field($ref['pmid']) : '',
                'url' => isset($ref['url']) ? esc_url_raw($ref['url']) : '',
            );
        }, $data['references']);
        update_post_meta($post_id, '_mh_references', wp_json_encode($references));
    }

    // v4.1 scraper fields - additional microscopy details
    // Save as JSON meta AND set as searchable taxonomy terms
    if (!empty($data['imaging_modalities']) && is_array($data['imaging_modalities'])) {
        update_post_meta($post_id, '_mh_imaging_modalities', wp_json_encode($data['imaging_modalities']));
    }
    if (!empty($data['staining_methods']) && is_array($data['staining_methods'])) {
        update_post_meta($post_id, '_mh_staining_methods', wp_json_encode($data['staining_methods']));
    }
    if (!empty($data['lasers']) && is_array($data['lasers'])) {
        update_post_meta($post_id, '_mh_lasers', wp_json_encode($data['lasers']));
        // Extract string tag values for taxonomy
        $laser_tags = array();
        foreach ($data['lasers'] as $laser) {
            if (is_string($laser)) {
                $laser_tags[] = $laser;
            } elseif (is_array($laser)) {
                // Handle structured data: prefer canonical, then text, then build from wavelength
                if (!empty($laser['canonical'])) {
                    $laser_tags[] = $laser['canonical'];
                } elseif (!empty($laser['text'])) {
                    $laser_tags[] = $laser['text'];
                } elseif (!empty($laser['wavelength_nm'])) {
                    $laser_tags[] = $laser['wavelength_nm'] . ' nm';
                }
                if (!empty($laser['type'])) {
                    $laser_tags[] = $laser['type'];
                }
            }
        }
        $laser_tags = array_unique(array_filter(array_map('sanitize_text_field', $laser_tags)));
        if (!empty($laser_tags)) {
            wp_set_object_terms($post_id, $laser_tags, 'mh_laser');
        }
    }
    if (!empty($data['detectors']) && is_array($data['detectors'])) {
        update_post_meta($post_id, '_mh_detectors', wp_json_encode($data['detectors']));
        // Extract string tag values for taxonomy
        $detector_tags = array();
        foreach ($data['detectors'] as $det) {
            if (is_string($det)) {
                $detector_tags[] = $det;
            } elseif (is_array($det)) {
                if (!empty($det['canonical'])) {
                    $detector_tags[] = $det['canonical'];
                } elseif (!empty($det['text'])) {
                    $detector_tags[] = $det['text'];
                } elseif (!empty($det['type'])) {
                    $detector_tags[] = $det['type'];
                }
            }
        }
        $detector_tags = array_unique(array_filter(array_map('sanitize_text_field', $detector_tags)));
        if (!empty($detector_tags)) {
            wp_set_object_terms($post_id, $detector_tags, 'mh_detector');
        }
    }
    if (!empty($data['objectives']) && is_array($data['objectives'])) {
        update_post_meta($post_id, '_mh_objectives', wp_json_encode($data['objectives']));
        // Extract string tag values for taxonomy
        $objective_tags = array();
        foreach ($data['objectives'] as $obj) {
            if (is_string($obj)) {
                $objective_tags[] = $obj;
            } elseif (is_array($obj)) {
                if (!empty($obj['canonical'])) {
                    $objective_tags[] = $obj['canonical'];
                } elseif (!empty($obj['text'])) {
                    $objective_tags[] = $obj['text'];
                } else {
                    // Build from structured fields
                    $parts = array();
                    if (!empty($obj['magnification'])) $parts[] = $obj['magnification'];
                    if (!empty($obj['na'])) $parts[] = 'NA ' . $obj['na'];
                    if (!empty($obj['immersion'])) $parts[] = ucfirst($obj['immersion']);
                    if (!empty($parts)) $objective_tags[] = implode(' ', $parts);
                }
            }
        }
        $objective_tags = array_unique(array_filter(array_map('sanitize_text_field', $objective_tags)));
        if (!empty($objective_tags)) {
            wp_set_object_terms($post_id, $objective_tags, 'mh_objective');
        }
    }
    if (!empty($data['filters']) && is_array($data['filters'])) {
        update_post_meta($post_id, '_mh_filters', wp_json_encode($data['filters']));
        // Extract string tag values for taxonomy
        $filter_tags = array();
        foreach ($data['filters'] as $filt) {
            if (is_string($filt)) {
                $filter_tags[] = $filt;
            } elseif (is_array($filt)) {
                if (!empty($filt['canonical'])) {
                    $filter_tags[] = $filt['canonical'];
                } elseif (!empty($filt['text'])) {
                    $filter_tags[] = $filt['text'];
                }
            }
        }
        $filter_tags = array_unique(array_filter(array_map('sanitize_text_field', $filter_tags)));
        if (!empty($filter_tags)) {
            wp_set_object_terms($post_id, $filter_tags, 'mh_filter');
        }
    }
    if (!empty($data['embedding_methods']) && is_array($data['embedding_methods'])) {
        update_post_meta($post_id, '_mh_embedding_methods', wp_json_encode($data['embedding_methods']));
    }
    if (!empty($data['fixation_methods']) && is_array($data['fixation_methods'])) {
        update_post_meta($post_id, '_mh_fixation_methods', wp_json_encode($data['fixation_methods']));
    }
    if (!empty($data['mounting_media']) && is_array($data['mounting_media'])) {
        update_post_meta($post_id, '_mh_mounting_media', wp_json_encode($data['mounting_media']));
    }

    // v4 scraper fields - influential citation count
    if (isset($data['influential_citation_count'])) {
        update_post_meta($post_id, '_mh_influential_citations', intval($data['influential_citation_count']));
    }

    // v4 scraper fields - citation source
    if (!empty($data['citation_source'])) {
        update_post_meta($post_id, '_mh_citation_source', sanitize_text_field($data['citation_source']));
    }

    // v4 scraper fields - semantic scholar ID
    if (!empty($data['semantic_scholar_id'])) {
        update_post_meta($post_id, '_mh_semantic_scholar_id', sanitize_text_field($data['semantic_scholar_id']));
    }

    // Save supplementary materials (JSON array)
    if (!empty($data['supplementary_materials']) && is_array($data['supplementary_materials'])) {
        update_post_meta($post_id, '_mh_supplementary_materials', wp_json_encode($data['supplementary_materials']));
    }

    // Save data_availability text
    if (!empty($data['data_availability'])) {
        update_post_meta($post_id, '_mh_data_availability', sanitize_textarea_field($data['data_availability']));
    }

    // ============================================
    // BOOLEAN FLAGS FROM CLEAN.PY
    // Save all has_* flags for filtering and display
    // ============================================
    $boolean_flags = array(
        'has_fluorophores'            => '_mh_has_fluorophores',
        'has_sample_prep'             => '_mh_has_sample_prep',
        'has_antibody_sources'        => '_mh_has_antibody_sources',
        'has_antibodies'              => '_mh_has_antibodies',
        'has_reagent_suppliers'       => '_mh_has_reagent_suppliers',
        'has_general_software'        => '_mh_has_general_software',
        'has_methods'                 => '_mh_has_methods',
        'has_institutions'            => '_mh_has_institutions',
        'has_facility'                => '_mh_has_facility',
        'has_affiliations'            => '_mh_has_affiliations',
        'has_figures'                 => '_mh_has_figures',
        'has_supplementary_materials' => '_mh_has_supplementary_materials',
        'has_objectives'              => '_mh_has_objectives',
        'has_lasers'                  => '_mh_has_lasers',
        'has_detectors'               => '_mh_has_detectors',
        'has_filters'                 => '_mh_has_filters',
        'has_full_text'               => '_mh_has_full_text',
        'has_openalex'                => '_mh_has_openalex',
        'has_oa'                      => '_mh_has_oa',
        'has_fwci'                    => '_mh_has_fwci',
        'has_datasets'                => '_mh_has_datasets',
        'has_openalex_topics'         => '_mh_has_openalex_topics',
        'has_openalex_institutions'   => '_mh_has_openalex_institutions',
        'has_fields_of_study'         => '_mh_has_fields_of_study',
    );
    foreach ($boolean_flags as $json_key => $meta_key) {
        if (!empty($data[$json_key])) {
            update_post_meta($post_id, $meta_key, '1');
        }
    }

    // ============================================
    // OPENALEX ENRICHMENT DATA
    // New fields from the enrichment pipeline (clean.py)
    // ============================================
    if (!empty($data['openalex_id'])) {
        update_post_meta($post_id, '_mh_openalex_id', sanitize_text_field($data['openalex_id']));
    }
    if (!empty($data['oa_status'])) {
        update_post_meta($post_id, '_mh_oa_status', sanitize_text_field($data['oa_status']));
    }
    if (isset($data['fwci']) && $data['fwci'] !== '' && $data['fwci'] !== null) {
        update_post_meta($post_id, '_mh_fwci', floatval($data['fwci']));
    }
    if (!empty($data['is_open_access'])) {
        update_post_meta($post_id, '_mh_is_open_access', '1');
    }
    if (!empty($data['openalex_topics']) && is_array($data['openalex_topics'])) {
        update_post_meta($post_id, '_mh_openalex_topics', wp_json_encode($data['openalex_topics']));
    }
    if (!empty($data['openalex_institutions']) && is_array($data['openalex_institutions'])) {
        update_post_meta($post_id, '_mh_openalex_institutions', wp_json_encode($data['openalex_institutions']));
    }
    if (!empty($data['fields_of_study']) && is_array($data['fields_of_study'])) {
        update_post_meta($post_id, '_mh_fields_of_study', wp_json_encode($data['fields_of_study']));
    }

    // Funders (from CrossRef enrichment)
    if (!empty($data['funders']) && is_array($data['funders'])) {
        update_post_meta($post_id, '_mh_funders', wp_json_encode($data['funders']));
    }

    // Semantic Scholar metadata
    if (!empty($data['semantic_scholar_id'])) {
        update_post_meta($post_id, '_mh_semantic_scholar_id', sanitize_text_field($data['semantic_scholar_id']));
    }
    if (!empty($data['influential_citation_count'])) {
        update_post_meta($post_id, '_mh_influential_citation_count', intval($data['influential_citation_count']));
    }

    return $is_update ? 'updated' : 'imported';
}
