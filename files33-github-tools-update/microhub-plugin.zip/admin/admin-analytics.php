<?php
/**
 * MicroHub Analytics Dashboard
 *
 * Admin-only page showing visitor metrics, engagement data.
 * Storage: custom tables (mh_page_views, mh_tracking_events).
 */

if (!defined('ABSPATH')) exit;

add_action('admin_menu', 'mh_analytics_add_menu');

function mh_analytics_add_menu() {
    add_submenu_page(
        'microhub-settings',
        'Site Analytics',
        'Site Analytics',
        'manage_options',
        'microhub-analytics',
        'mh_analytics_page'
    );
}

function mh_analytics_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have permission to access this page.'));
    }

    $days = isset($_GET['days']) ? absint($_GET['days']) : 30;
    if (!in_array($days, array(7, 14, 30, 60, 90))) $days = 30;

    global $wpdb;

    // Handle table rebuild
    if (isset($_POST['mh_rebuild_tables']) && check_admin_referer('mh_rebuild_tables_nonce')) {
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}mh_page_views");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}mh_tracking_events");
        delete_transient('mh_tables_verified');
        MicroHub_Tracking::create_tables();
        echo '<div class="notice notice-success"><p>Tracking tables rebuilt. <a href="' . esc_url(admin_url('admin.php?page=microhub-analytics')) . '">Refresh page</a></p></div>';
    }

    // Handle data clear
    if (isset($_POST['mh_clear_analytics']) && check_admin_referer('mh_clear_analytics_nonce')) {
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}mh_page_views");
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}mh_tracking_events");
        echo '<div class="notice notice-success"><p>All analytics data has been cleared.</p></div>';
    }

    // Fetch all data
    $total_visitors = MicroHub_Tracking::get_visitor_count($days);
    $total_views = MicroHub_Tracking::get_pageview_count($days);
    $avg_duration = MicroHub_Tracking::get_avg_duration($days);
    $daily_data = MicroHub_Tracking::get_daily_views($days);
    $top_pages = MicroHub_Tracking::get_top_pages($days);
    $top_referrers = MicroHub_Tracking::get_top_referrers($days);
    $tag_usage = MicroHub_Tracking::get_tag_usage($days);
    $link_clicks = MicroHub_Tracking::get_link_clicks($days);
    $search_queries = MicroHub_Tracking::get_search_queries($days);
    $filter_usage = MicroHub_Tracking::get_filter_usage($days);

    $avg_mins = floor($avg_duration / 60);
    $avg_secs = round($avg_duration % 60);
    $avg_formatted = $avg_mins > 0 ? $avg_mins . 'm ' . $avg_secs . 's' : $avg_secs . 's';

    $chart_labels = array();
    $chart_views = array();
    $chart_visitors = array();
    foreach ($daily_data as $row) {
        $chart_labels[] = date('M j', strtotime($row->date));
        $chart_views[] = (int)$row->views;
        $chart_visitors[] = (int)$row->visitors;
    }

    ?>
    <div class="wrap mh-analytics-wrap">
        <h1>MicroHub Site Analytics</h1>

        <!-- Date Range Selector -->
        <div class="mh-analytics-controls" style="margin: 15px 0;">
            <?php
            $ranges = array(7 => '7 days', 14 => '14 days', 30 => '30 days', 60 => '60 days', 90 => '90 days');
            foreach ($ranges as $d => $label) :
                $url = add_query_arg('days', $d, admin_url('admin.php?page=microhub-analytics'));
                $active = ($d === $days) ? 'button-primary' : 'button-secondary';
            ?>
                <a href="<?php echo esc_url($url); ?>" class="button <?php echo $active; ?>"><?php echo $label; ?></a>
            <?php endforeach; ?>
        </div>

        <!-- Overview Cards -->
        <div class="mh-stats-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 25px;">
            <div class="mh-stat-card" style="background: #fff; border: 1px solid #c3c4c7; border-left: 4px solid #2271b1; padding: 20px; border-radius: 4px;">
                <div style="font-size: 32px; font-weight: 700; color: #1d2327;"><?php echo number_format($total_visitors); ?></div>
                <div style="color: #646970; font-size: 14px; margin-top: 5px;">Unique Visitors</div>
            </div>
            <div class="mh-stat-card" style="background: #fff; border: 1px solid #c3c4c7; border-left: 4px solid #00a32a; padding: 20px; border-radius: 4px;">
                <div style="font-size: 32px; font-weight: 700; color: #1d2327;"><?php echo number_format($total_views); ?></div>
                <div style="color: #646970; font-size: 14px; margin-top: 5px;">Page Views</div>
            </div>
            <div class="mh-stat-card" style="background: #fff; border: 1px solid #c3c4c7; border-left: 4px solid #dba617; padding: 20px; border-radius: 4px;">
                <div style="font-size: 32px; font-weight: 700; color: #1d2327;"><?php echo esc_html($avg_formatted); ?></div>
                <div style="color: #646970; font-size: 14px; margin-top: 5px;">Avg. Time on Page</div>
            </div>
        </div>

        <!-- Traffic Chart -->
        <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; margin-bottom: 25px; border-radius: 4px;">
            <h2 style="margin-top: 0;">Traffic Overview</h2>
            <canvas id="mh-traffic-chart" height="80"></canvas>
        </div>

        <!-- Two-column layout -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">

            <!-- Top Pages -->
            <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                <h2 style="margin-top: 0;">Top Pages</h2>
                <?php if (empty($top_pages)) : ?>
                    <p style="color: #646970;">No page view data yet.</p>
                <?php else : ?>
                    <table class="widefat striped" style="border: 0;">
                        <thead>
                            <tr>
                                <th>Page</th>
                                <th style="width:60px; text-align:right;">Views</th>
                                <th style="width:70px; text-align:right;">Visitors</th>
                                <th style="width:70px; text-align:right;">Avg Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_pages as $page) :
                                $d = (int)$page->avg_duration;
                                $dm = floor($d / 60);
                                $ds = $d % 60;
                                $dt = $dm > 0 ? $dm . 'm ' . $ds . 's' : $ds . 's';
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html($page->page_title ?: $page->page_url); ?></strong>
                                    <div style="color:#646970; font-size:12px;"><?php echo esc_html(substr($page->page_url, 0, 60)); ?></div>
                                </td>
                                <td style="text-align:right;"><?php echo number_format($page->views); ?></td>
                                <td style="text-align:right;"><?php echo number_format($page->visitors); ?></td>
                                <td style="text-align:right;"><?php echo esc_html($dt); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- Top Referrers -->
            <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                <h2 style="margin-top: 0;">Top Referrers</h2>
                <?php if (empty($top_referrers)) : ?>
                    <p style="color: #646970;">No referrer data yet.</p>
                <?php else : ?>
                    <table class="widefat striped" style="border: 0;">
                        <thead>
                            <tr>
                                <th>Source</th>
                                <th style="width:80px; text-align:right;">Visits</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_referrers as $ref) :
                                $domain = wp_parse_url($ref->referrer, PHP_URL_HOST) ?: $ref->referrer;
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html($domain); ?></strong>
                                    <div style="color:#646970; font-size:12px;"><?php echo esc_html(substr($ref->referrer, 0, 80)); ?></div>
                                </td>
                                <td style="text-align:right;"><?php echo number_format($ref->visits); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- Tag Usage & Link Clicks -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">

            <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                <h2 style="margin-top: 0;">Tag & Taxonomy Usage</h2>
                <p style="color: #646970; font-size: 13px;">Which tags visitors click on most</p>
                <?php if (empty($tag_usage)) : ?>
                    <p style="color: #646970;">No tag click data yet.</p>
                <?php else : ?>
                    <table class="widefat striped" style="border: 0;">
                        <thead><tr><th>Tag</th><th style="width:80px; text-align:right;">Clicks</th></tr></thead>
                        <tbody>
                            <?php foreach ($tag_usage as $tag) : ?>
                            <tr>
                                <td><code><?php echo esc_html($tag->event_value); ?></code></td>
                                <td style="text-align:right;"><?php echo number_format($tag->clicks); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                <h2 style="margin-top: 0;">Link Clicks</h2>
                <p style="color: #646970; font-size: 13px;">Internal and outbound links visitors follow</p>
                <?php if (empty($link_clicks)) : ?>
                    <p style="color: #646970;">No link click data yet.</p>
                <?php else : ?>
                    <table class="widefat striped" style="border: 0;">
                        <thead><tr><th>Link</th><th style="width:80px; text-align:right;">Clicks</th></tr></thead>
                        <tbody>
                            <?php foreach ($link_clicks as $link) : ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html($link->event_value ?: '(no text)'); ?></strong>
                                    <div style="color:#646970; font-size:12px; word-break:break-all;"><?php echo esc_html(substr($link->event_target, 0, 80)); ?></div>
                                </td>
                                <td style="text-align:right;"><?php echo number_format($link->clicks); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- Search Queries & Filter Usage -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">

            <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                <h2 style="margin-top: 0;">Search Queries</h2>
                <?php if (empty($search_queries)) : ?>
                    <p style="color: #646970;">No search data yet.</p>
                <?php else : ?>
                    <table class="widefat striped" style="border: 0;">
                        <thead><tr><th>Query</th><th style="width:80px; text-align:right;">Count</th></tr></thead>
                        <tbody>
                            <?php foreach ($search_queries as $q) : ?>
                            <tr>
                                <td><?php echo esc_html($q->event_value); ?></td>
                                <td style="text-align:right;"><?php echo number_format($q->count); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                <h2 style="margin-top: 0;">Filter & Tab Usage</h2>
                <p style="color: #646970; font-size: 13px;">Which dropdown filters and tabs visitors use most</p>
                <?php if (empty($filter_usage)) : ?>
                    <p style="color: #646970;">No filter/tab usage data yet.</p>
                <?php else : ?>
                    <table class="widefat striped" style="border: 0;">
                        <thead><tr><th>Filter/Tab</th><th>Value</th><th style="width:70px; text-align:right;">Count</th></tr></thead>
                        <tbody>
                            <?php foreach ($filter_usage as $f) : ?>
                            <tr>
                                <td><code><?php echo esc_html($f->filter_name); ?></code></td>
                                <td><?php echo esc_html($f->event_value); ?></td>
                                <td style="text-align:right;"><?php echo number_format($f->count); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- Tracking Diagnostic -->
        <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; margin-bottom: 25px; border-radius: 4px;">
            <h2 style="margin-top: 0;">Tracking Diagnostic</h2>

            <?php
            $plugin_version = defined('MICROHUB_VERSION') ? MICROHUB_VERSION : 'unknown';

            $pv_table = $wpdb->prefix . 'mh_page_views';
            $ev_table = $wpdb->prefix . 'mh_tracking_events';
            $tables_ok = $wpdb->get_var("SHOW TABLES LIKE '$pv_table'") === $pv_table;
            $events_ok = $wpdb->get_var("SHOW TABLES LIKE '$ev_table'") === $ev_table;

            // Get table stats
            $db_name = DB_NAME;
            $pv_status = $tables_ok ? $wpdb->get_row("SELECT ENGINE, TABLE_ROWS, ROUND((DATA_LENGTH + INDEX_LENGTH)/1024, 1) as size_kb FROM information_schema.TABLES WHERE TABLE_SCHEMA = '$db_name' AND TABLE_NAME = '$pv_table'") : null;
            $ev_status = $events_ok ? $wpdb->get_row("SELECT ENGINE, TABLE_ROWS, ROUND((DATA_LENGTH + INDEX_LENGTH)/1024, 1) as size_kb FROM information_schema.TABLES WHERE TABLE_SCHEMA = '$db_name' AND TABLE_NAME = '$ev_table'") : null;

            // Direct INSERT test
            $test_result = false;
            $test_error = '';
            $test_insert_id = 0;
            if ($tables_ok) {
                $test_result = $wpdb->insert($pv_table, array(
                    'session_id' => 'db_test_' . time(),
                    'page_url'   => '/diagnostic-test/',
                    'page_title' => 'DB Test',
                    'post_id'    => 0,
                    'post_type'  => '',
                    'referrer'   => '',
                    'user_agent' => 'DiagnosticTest',
                    'ip_hash'    => 'test',
                    'duration'   => 0,
                ), array('%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d'));
                $test_error = $wpdb->last_error;
                $test_insert_id = $test_result ? $wpdb->insert_id : 0;
                if ($test_insert_id) {
                    $wpdb->delete($pv_table, array('id' => $test_insert_id));
                }
            }

            $latest_view = $tables_ok ? $wpdb->get_row("SELECT created_at, page_url FROM $pv_table ORDER BY id DESC LIMIT 1") : null;
            $total_all = $tables_ok ? (int) $wpdb->get_var("SELECT COUNT(*) FROM $pv_table") : 0;

            $js_file = MICROHUB_PLUGIN_DIR . 'assets/js/tracking.js';
            $js_exists = file_exists($js_file);
            $js_content = $js_exists ? file_get_contents($js_file) : '';
            $js_current = strpos($js_content, 'v3.12') !== false;
            ?>

            <?php if ($test_error): ?>
                <div class="notice notice-error" style="margin: 0 0 15px 0;">
                    <p><strong>DATABASE INSERT FAILED:</strong> <code><?php echo esc_html($test_error); ?></code></p>
                    <p>This is why tracking shows zero page views. The database is rejecting inserts into the tracking tables.</p>
                </div>
            <?php elseif ($test_insert_id): ?>
                <div class="notice notice-success" style="margin: 0 0 15px 0;">
                    <p><strong>Database insert test PASSED!</strong> Tracking should be working. Check browser console (F12) on a frontend page for [MH] messages.</p>
                </div>
            <?php elseif (!$tables_ok): ?>
                <div class="notice notice-warning" style="margin: 0 0 15px 0;">
                    <p><strong>Tracking tables missing.</strong> Use "Rebuild Tracking Tables" below, or deactivate/reactivate the plugin.</p>
                </div>
            <?php endif; ?>

            <table class="widefat striped" style="max-width: 750px; border: 0;">
                <tbody>
                    <tr><td colspan="3" style="background:#f0f0f1;"><strong>Plugin Status</strong></td></tr>
                    <tr>
                        <td>Plugin Version</td>
                        <td><code><?php echo esc_html($plugin_version); ?></code></td>
                        <td><?php echo version_compare($plugin_version, '3.12.1', '>=') ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>
                    <tr>
                        <td>tracking.js</td>
                        <td><?php echo $js_current ? 'v3.12.1' : '&#10060; OLD FILE'; ?></td>
                        <td><?php echo $js_current ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>
                    <tr>
                        <td>Storage Method</td>
                        <td><code>Custom DB tables</code></td>
                        <td>&#9989;</td>
                    </tr>
                    <tr>
                        <td>Direct INSERT test</td>
                        <td><?php echo $test_result ? '<span style="color:#00a32a">PASSED (ID: ' . $test_insert_id . ')</span>' : '<span style="color:#d63638">FAILED: ' . esc_html($test_error ?: 'Table missing') . '</span>'; ?></td>
                        <td><?php echo $test_result ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>

                    <tr><td colspan="3" style="background:#f0f0f1;"><strong>Tracking Tables</strong></td></tr>
                    <tr>
                        <td>mh_page_views</td>
                        <td><?php echo $tables_ok ? ($pv_status ? esc_html($pv_status->ENGINE . ' / ' . $pv_status->TABLE_ROWS . ' rows / ' . $pv_status->size_kb . ' KB') : 'Exists') : '<span style="color:#d63638">MISSING</span>'; ?></td>
                        <td><?php echo $tables_ok ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>
                    <tr>
                        <td>mh_tracking_events</td>
                        <td><?php echo $events_ok ? ($ev_status ? esc_html($ev_status->ENGINE . ' / ' . $ev_status->TABLE_ROWS . ' rows / ' . $ev_status->size_kb . ' KB') : 'Exists') : '<span style="color:#d63638">MISSING</span>'; ?></td>
                        <td><?php echo $events_ok ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>

                    <tr><td colspan="3" style="background:#f0f0f1;"><strong>Page View Data</strong></td></tr>
                    <tr>
                        <td>Total page views (all time)</td>
                        <td><?php echo number_format($total_all); ?></td>
                        <td><?php echo $total_all > 0 ? '&#9989;' : '&#9888;&#65039; No data yet'; ?></td>
                    </tr>
                    <tr>
                        <td>Latest page view</td>
                        <td><?php echo $latest_view ? esc_html($latest_view->created_at . ' — ' . $latest_view->page_url) : 'None'; ?></td>
                        <td><?php echo $latest_view ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>
                </tbody>
            </table>

            <!-- Repair Tools -->
            <h3 style="margin-top:20px;">Repair Tools</h3>
            <form method="post" style="display:inline;">
                <?php wp_nonce_field('mh_rebuild_tables_nonce'); ?>
                <input type="submit" name="mh_rebuild_tables" class="button"
                       value="Rebuild Tracking Tables"
                       onclick="return confirm('This will drop and recreate the tracking tables (all existing data will be lost). Continue?');" />
            </form>

            <!-- Live Endpoint Tests -->
            <h3 style="margin-top:20px;">Live Endpoint Tests</h3>
            <p>Click both buttons. At least one MUST show green:</p>

            <div style="display:flex;gap:15px;flex-wrap:wrap;margin-bottom:15px;">
                <div>
                    <button type="button" id="mh-test-rest" class="button button-primary">Test REST API</button>
                    <div id="mh-test-rest-result" style="margin-top:8px;font-size:13px;"></div>
                </div>
                <div>
                    <button type="button" id="mh-test-ajax" class="button">Test admin-ajax.php</button>
                    <div id="mh-test-ajax-result" style="margin-top:8px;font-size:13px;"></div>
                </div>
            </div>

            <script>
            document.getElementById('mh-test-rest').addEventListener('click', function() {
                var btn = this, result = document.getElementById('mh-test-rest-result');
                btn.disabled = true;
                result.innerHTML = '<span style="color:#666">Sending...</span>';
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo esc_js(rest_url('microhub/v1/track/pageview')); ?>', true);
                xhr.setRequestHeader('Content-Type', 'application/json');
                xhr.onload = function() {
                    btn.disabled = false;
                    try {
                        var r = JSON.parse(xhr.responseText);
                        if (r.success) result.innerHTML = '<span style="color:#00a32a">&#9989; REST works! ID: ' + (r.id || '?') + '</span>';
                        else result.innerHTML = '<span style="color:#d63638">&#10060; REST failed (' + xhr.status + '): ' + JSON.stringify(r.error || r).substring(0,300) + '</span>';
                    } catch(e) { result.innerHTML = '<span style="color:#d63638">&#10060; (' + xhr.status + '): ' + xhr.responseText.substring(0,300) + '</span>'; }
                };
                xhr.onerror = function() { btn.disabled = false; result.innerHTML = '<span style="color:#d63638">&#10060; Network error</span>'; };
                xhr.send(JSON.stringify({ session_id: 'diag_rest_' + Date.now(), page_url: '/diagnostic-test/', page_title: 'Diagnostic Test', post_id: 0, post_type: '', referrer: '' }));
            });

            document.getElementById('mh-test-ajax').addEventListener('click', function() {
                var btn = this, result = document.getElementById('mh-test-ajax-result');
                btn.disabled = true;
                result.innerHTML = '<span style="color:#666">Sending...</span>';
                var fd = new FormData();
                fd.append('action', 'mh_track_pageview');
                fd.append('session_id', 'diag_ajax_' + Date.now());
                fd.append('page_url', '/diagnostic-test/');
                fd.append('page_title', 'Diagnostic Test');
                fd.append('post_id', '0'); fd.append('post_type', ''); fd.append('referrer', '');
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo esc_js(admin_url('admin-ajax.php')); ?>', true);
                xhr.onload = function() {
                    btn.disabled = false;
                    try {
                        var r = JSON.parse(xhr.responseText);
                        if (r.success) result.innerHTML = '<span style="color:#00a32a">&#9989; AJAX works! ID: ' + (r.data && r.data.id || '?') + '</span>';
                        else result.innerHTML = '<span style="color:#d63638">&#10060; (' + xhr.status + '): ' + JSON.stringify(r.data).substring(0,300) + '</span>';
                    } catch(e) { result.innerHTML = '<span style="color:#d63638">&#10060; (' + xhr.status + '): ' + xhr.responseText.substring(0,300) + '</span>'; }
                };
                xhr.onerror = function() { btn.disabled = false; result.innerHTML = '<span style="color:#d63638">&#10060; Network error</span>'; };
                xhr.send(fd);
            });
            </script>

            <h3 style="margin-top:20px;">Frontend Check</h3>
            <p>Open any MicroHub paper page, press F12, check Console for <code>[MH]</code> messages.</p>
        </div>

        <!-- Data Management -->
        <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
            <h2 style="margin-top: 0;">Data Management</h2>
            <p style="color: #646970;">Analytics data is automatically cleaned up after 90 days. You can also clear it manually.</p>

            <form method="post" action="">
                <?php wp_nonce_field('mh_clear_analytics_nonce'); ?>
                <input type="submit" name="mh_clear_analytics" class="button" style="color: #d63638; border-color: #d63638;"
                       value="Clear All Analytics Data"
                       onclick="return confirm('Are you sure? This will delete all tracking data permanently.');" />
            </form>
        </div>
    </div>

    <!-- Chart.js from CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <script>
    (function() {
        var ctx = document.getElementById('mh-traffic-chart');
        if (!ctx) return;

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo wp_json_encode($chart_labels); ?>,
                datasets: [
                    {
                        label: 'Page Views',
                        data: <?php echo wp_json_encode($chart_views); ?>,
                        borderColor: '#2271b1',
                        backgroundColor: 'rgba(34, 113, 177, 0.1)',
                        fill: true,
                        tension: 0.3,
                        borderWidth: 2,
                        pointRadius: 3
                    },
                    {
                        label: 'Unique Visitors',
                        data: <?php echo wp_json_encode($chart_visitors); ?>,
                        borderColor: '#00a32a',
                        backgroundColor: 'rgba(0, 163, 42, 0.1)',
                        fill: true,
                        tension: 0.3,
                        borderWidth: 2,
                        pointRadius: 3
                    }
                ]
            },
            options: {
                responsive: true,
                interaction: { intersect: false, mode: 'index' },
                plugins: {
                    legend: { position: 'top' }
                },
                scales: {
                    y: { beginAtZero: true, ticks: { precision: 0 } }
                }
            }
        });
    })();
    </script>

    <style>
    .mh-analytics-wrap h2 { font-size: 16px; font-weight: 600; }
    .mh-analytics-wrap .widefat td, .mh-analytics-wrap .widefat th { padding: 8px 10px; }
    @media (max-width: 960px) {
        .mh-stats-grid { grid-template-columns: repeat(2, 1fr) !important; }
    }
    </style>
    <?php
}
