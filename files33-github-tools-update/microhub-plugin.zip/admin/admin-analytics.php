<?php
/**
 * MicroHub Analytics Dashboard
 *
 * Admin-only page showing visitor metrics, engagement data, and bot protection stats.
 * Only visible to users with manage_options capability.
 */

if (!defined('ABSPATH')) exit;

// Register the analytics admin page
add_action('admin_menu', 'mh_analytics_add_menu');

function mh_analytics_add_menu() {
    add_submenu_page(
        'microhub-settings',
        'Site Analytics',
        'Site Analytics',
        'manage_options',
        'microhub-analytics',
        'mh_analytics_page'
    );
}

/**
 * Analytics dashboard page
 */
function mh_analytics_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have permission to access this page.'));
    }

    // Get date range from query param
    $days = isset($_GET['days']) ? absint($_GET['days']) : 30;
    if (!in_array($days, array(7, 14, 30, 60, 90))) $days = 30;

    // Ensure tables exist
    global $wpdb;
    $views_table = $wpdb->prefix . 'mh_page_views';
    if ($wpdb->get_var("SHOW TABLES LIKE '$views_table'") !== $views_table) {
        echo '<div class="wrap"><h1>Site Analytics</h1>';
        echo '<div class="notice notice-warning"><p>Analytics tables have not been created yet. ';
        echo 'Please deactivate and reactivate the MicroHub plugin to create them, or ';
        echo '<a href="' . esc_url(admin_url('admin.php?page=microhub-analytics&mh_create_tables=1')) . '">click here to create them now</a>.</p></div></div>';

        if (isset($_GET['mh_create_tables'])) {
            require_once MICROHUB_PLUGIN_DIR . 'includes/class-microhub-activator.php';
            MicroHub_Activator::activate();
            echo '<div class="notice notice-success"><p>Tables created successfully! <a href="' . esc_url(admin_url('admin.php?page=microhub-analytics')) . '">Refresh page</a></p></div>';
        }
        return;
    }

    // Fetch all data
    $total_visitors = MicroHub_Tracking::get_visitor_count($days);
    $total_views = MicroHub_Tracking::get_pageview_count($days);
    $avg_duration = MicroHub_Tracking::get_avg_duration($days);
    $daily_data = MicroHub_Tracking::get_daily_views($days);
    $top_pages = MicroHub_Tracking::get_top_pages($days);
    $top_referrers = MicroHub_Tracking::get_top_referrers($days);
    $tag_usage = MicroHub_Tracking::get_tag_usage($days);
    $link_clicks = MicroHub_Tracking::get_link_clicks($days);
    $search_queries = MicroHub_Tracking::get_search_queries($days);
    $filter_usage = MicroHub_Tracking::get_filter_usage($days);
    $bot_stats = MicroHub_Tracking::get_bot_stats($days);
    $total_blocks = MicroHub_Tracking::get_total_bot_blocks($days);

    // Format avg duration
    $avg_mins = floor($avg_duration / 60);
    $avg_secs = round($avg_duration % 60);
    $avg_formatted = $avg_mins > 0 ? $avg_mins . 'm ' . $avg_secs . 's' : $avg_secs . 's';

    // Prepare chart data
    $chart_labels = array();
    $chart_views = array();
    $chart_visitors = array();
    foreach ($daily_data as $row) {
        $chart_labels[] = date('M j', strtotime($row->date));
        $chart_views[] = (int)$row->views;
        $chart_visitors[] = (int)$row->visitors;
    }

    ?>
    <div class="wrap mh-analytics-wrap">
        <h1>MicroHub Site Analytics</h1>

        <!-- Date Range Selector -->
        <div class="mh-analytics-controls" style="margin: 15px 0;">
            <?php
            $ranges = array(7 => '7 days', 14 => '14 days', 30 => '30 days', 60 => '60 days', 90 => '90 days');
            foreach ($ranges as $d => $label) :
                $url = add_query_arg('days', $d, admin_url('admin.php?page=microhub-analytics'));
                $active = ($d === $days) ? 'button-primary' : 'button-secondary';
            ?>
                <a href="<?php echo esc_url($url); ?>" class="button <?php echo $active; ?>"><?php echo $label; ?></a>
            <?php endforeach; ?>
        </div>

        <!-- Overview Cards -->
        <div class="mh-stats-grid" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 25px;">
            <div class="mh-stat-card" style="background: #fff; border: 1px solid #c3c4c7; border-left: 4px solid #2271b1; padding: 20px; border-radius: 4px;">
                <div style="font-size: 32px; font-weight: 700; color: #1d2327;"><?php echo number_format($total_visitors); ?></div>
                <div style="color: #646970; font-size: 14px; margin-top: 5px;">Unique Visitors</div>
            </div>
            <div class="mh-stat-card" style="background: #fff; border: 1px solid #c3c4c7; border-left: 4px solid #00a32a; padding: 20px; border-radius: 4px;">
                <div style="font-size: 32px; font-weight: 700; color: #1d2327;"><?php echo number_format($total_views); ?></div>
                <div style="color: #646970; font-size: 14px; margin-top: 5px;">Page Views</div>
            </div>
            <div class="mh-stat-card" style="background: #fff; border: 1px solid #c3c4c7; border-left: 4px solid #dba617; padding: 20px; border-radius: 4px;">
                <div style="font-size: 32px; font-weight: 700; color: #1d2327;"><?php echo esc_html($avg_formatted); ?></div>
                <div style="color: #646970; font-size: 14px; margin-top: 5px;">Avg. Time on Page</div>
            </div>
            <div class="mh-stat-card" style="background: #fff; border: 1px solid #c3c4c7; border-left: 4px solid #d63638; padding: 20px; border-radius: 4px;">
                <div style="font-size: 32px; font-weight: 700; color: #1d2327;"><?php echo number_format($total_blocks); ?></div>
                <div style="color: #646970; font-size: 14px; margin-top: 5px;">Bots Blocked</div>
            </div>
        </div>

        <!-- Traffic Chart -->
        <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; margin-bottom: 25px; border-radius: 4px;">
            <h2 style="margin-top: 0;">Traffic Overview</h2>
            <canvas id="mh-traffic-chart" height="80"></canvas>
        </div>

        <!-- Two-column layout -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">

            <!-- Top Pages -->
            <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                <h2 style="margin-top: 0;">Top Pages</h2>
                <?php if (empty($top_pages)) : ?>
                    <p style="color: #646970;">No page view data yet.</p>
                <?php else : ?>
                    <table class="widefat striped" style="border: 0;">
                        <thead>
                            <tr>
                                <th>Page</th>
                                <th style="width:60px; text-align:right;">Views</th>
                                <th style="width:70px; text-align:right;">Visitors</th>
                                <th style="width:70px; text-align:right;">Avg Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_pages as $page) :
                                $d = (int)$page->avg_duration;
                                $dm = floor($d / 60);
                                $ds = $d % 60;
                                $dt = $dm > 0 ? $dm . 'm ' . $ds . 's' : $ds . 's';
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html($page->page_title ?: $page->page_url); ?></strong>
                                    <div style="color:#646970; font-size:12px;"><?php echo esc_html(substr($page->page_url, 0, 60)); ?></div>
                                </td>
                                <td style="text-align:right;"><?php echo number_format($page->views); ?></td>
                                <td style="text-align:right;"><?php echo number_format($page->visitors); ?></td>
                                <td style="text-align:right;"><?php echo esc_html($dt); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- Top Referrers -->
            <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                <h2 style="margin-top: 0;">Top Referrers</h2>
                <?php if (empty($top_referrers)) : ?>
                    <p style="color: #646970;">No referrer data yet.</p>
                <?php else : ?>
                    <table class="widefat striped" style="border: 0;">
                        <thead>
                            <tr>
                                <th>Source</th>
                                <th style="width:80px; text-align:right;">Visits</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_referrers as $ref) :
                                $domain = wp_parse_url($ref->referrer, PHP_URL_HOST) ?: $ref->referrer;
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html($domain); ?></strong>
                                    <div style="color:#646970; font-size:12px;"><?php echo esc_html(substr($ref->referrer, 0, 80)); ?></div>
                                </td>
                                <td style="text-align:right;"><?php echo number_format($ref->visits); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- Tag Usage & Link Clicks -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">

            <!-- Tag/Taxonomy Usage -->
            <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                <h2 style="margin-top: 0;">Tag & Taxonomy Usage</h2>
                <p style="color: #646970; font-size: 13px;">Which tags visitors click on most (techniques, microscopes, organisms, etc.)</p>
                <?php if (empty($tag_usage)) : ?>
                    <p style="color: #646970;">No tag click data yet.</p>
                <?php else : ?>
                    <table class="widefat striped" style="border: 0;">
                        <thead>
                            <tr>
                                <th>Tag</th>
                                <th style="width:80px; text-align:right;">Clicks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tag_usage as $tag) : ?>
                            <tr>
                                <td><code><?php echo esc_html($tag->event_value); ?></code></td>
                                <td style="text-align:right;"><?php echo number_format($tag->clicks); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- Link Clicks -->
            <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                <h2 style="margin-top: 0;">Link Clicks</h2>
                <p style="color: #646970; font-size: 13px;">Internal and outbound links visitors follow</p>
                <?php if (empty($link_clicks)) : ?>
                    <p style="color: #646970;">No link click data yet.</p>
                <?php else : ?>
                    <table class="widefat striped" style="border: 0;">
                        <thead>
                            <tr>
                                <th>Link</th>
                                <th style="width:80px; text-align:right;">Clicks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($link_clicks as $link) : ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html($link->event_value ?: '(no text)'); ?></strong>
                                    <div style="color:#646970; font-size:12px; word-break:break-all;"><?php echo esc_html(substr($link->event_target, 0, 80)); ?></div>
                                </td>
                                <td style="text-align:right;"><?php echo number_format($link->clicks); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- Search Queries & Filter Usage -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">

            <!-- Search Queries -->
            <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                <h2 style="margin-top: 0;">Search Queries</h2>
                <?php if (empty($search_queries)) : ?>
                    <p style="color: #646970;">No search data yet.</p>
                <?php else : ?>
                    <table class="widefat striped" style="border: 0;">
                        <thead>
                            <tr>
                                <th>Query</th>
                                <th style="width:80px; text-align:right;">Count</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($search_queries as $q) : ?>
                            <tr>
                                <td><?php echo esc_html($q->event_value); ?></td>
                                <td style="text-align:right;"><?php echo number_format($q->count); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- Filter Usage -->
            <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
                <h2 style="margin-top: 0;">Filter Usage</h2>
                <p style="color: #646970; font-size: 13px;">Which dropdown filters visitors use most</p>
                <?php if (empty($filter_usage)) : ?>
                    <p style="color: #646970;">No filter usage data yet.</p>
                <?php else : ?>
                    <table class="widefat striped" style="border: 0;">
                        <thead>
                            <tr>
                                <th>Filter</th>
                                <th>Value</th>
                                <th style="width:70px; text-align:right;">Count</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($filter_usage as $f) : ?>
                            <tr>
                                <td><code><?php echo esc_html($f->filter_name); ?></code></td>
                                <td><?php echo esc_html($f->event_value); ?></td>
                                <td style="text-align:right;"><?php echo number_format($f->count); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- Bot Protection Stats -->
        <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; margin-bottom: 25px; border-radius: 4px;">
            <h2 style="margin-top: 0;">Bot Protection</h2>
            <p style="color: #646970; font-size: 13px;">Background bot detection is active. Bad bots are blocked automatically.</p>

            <?php if (empty($bot_stats)) : ?>
                <p style="color: #646970;">No bots blocked in this period.</p>
            <?php else : ?>
                <table class="widefat striped" style="max-width: 500px; border: 0;">
                    <thead>
                        <tr>
                            <th>Block Reason</th>
                            <th style="width:100px; text-align:right;">Count</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $reason_labels = array(
                            'bad_ua'             => 'Bad User Agent (scraper/bot)',
                            'empty_ua'           => 'Empty User Agent',
                            'rate_limit'         => 'Rate Limit Exceeded',
                            'honeypot'           => 'Honeypot Triggered',
                            'suspicious_pattern' => 'Suspicious URL Pattern',
                        );
                        foreach ($bot_stats as $bs) : ?>
                        <tr>
                            <td><?php echo esc_html($reason_labels[$bs->reason] ?? $bs->reason); ?></td>
                            <td style="text-align:right;"><?php echo number_format($bs->blocks); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Tracking Diagnostic -->
        <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; margin-bottom: 25px; border-radius: 4px;">
            <h2 style="margin-top: 0;">Tracking Diagnostic</h2>

            <?php
            $plugin_version = defined('MICROHUB_VERSION') ? MICROHUB_VERSION : 'unknown';
            $pv_table = $wpdb->prefix . 'mh_page_views';
            $ev_table = $wpdb->prefix . 'mh_tracking_events';
            $bb_table = $wpdb->prefix . 'mh_bot_blocks';

            $tables_ok = $wpdb->get_var("SHOW TABLES LIKE '$pv_table'") === $pv_table;
            $events_ok = $wpdb->get_var("SHOW TABLES LIKE '$ev_table'") === $ev_table;

            // Count all tables in database
            $db_name = DB_NAME;
            $total_tables = $wpdb->get_var("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = '$db_name'");
            $db_size_mb = $wpdb->get_var("SELECT ROUND(SUM(DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) FROM information_schema.TABLES WHERE TABLE_SCHEMA = '$db_name'");

            // Get tracking table details
            $pv_status = $wpdb->get_row("SELECT ENGINE, TABLE_ROWS, ROUND((DATA_LENGTH + INDEX_LENGTH)/1024, 1) as size_kb FROM information_schema.TABLES WHERE TABLE_SCHEMA = '$db_name' AND TABLE_NAME = '$pv_table'");
            $ev_status = $wpdb->get_row("SELECT ENGINE, TABLE_ROWS, ROUND((DATA_LENGTH + INDEX_LENGTH)/1024, 1) as size_kb FROM information_schema.TABLES WHERE TABLE_SCHEMA = '$db_name' AND TABLE_NAME = '$ev_table'");

            // Try a direct test INSERT
            $test_result = $wpdb->insert($pv_table, array(
                'session_id' => 'db_test_' . time(),
                'page_url'   => '/db-test/',
                'page_title' => 'DB Test',
                'post_id'    => 0,
                'post_type'  => '',
                'referrer'   => '',
                'user_agent' => 'DiagnosticTest',
                'ip_hash'    => 'test',
                'is_bot'     => 0,
                'duration'   => 0,
            ), array('%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%d'));
            $test_error = $wpdb->last_error;
            $test_insert_id = $test_result ? $wpdb->insert_id : 0;

            // If test succeeded, clean it up
            if ($test_insert_id) {
                $wpdb->delete($pv_table, array('id' => $test_insert_id));
            }

            // Get MySQL version and user
            $mysql_version = $wpdb->get_var("SELECT VERSION()");
            $mysql_user = $wpdb->get_var("SELECT CURRENT_USER()");

            // Check grants
            $grants = $wpdb->get_results("SHOW GRANTS FOR CURRENT_USER()", ARRAY_N);
            $grants_text = '';
            if ($grants) {
                foreach ($grants as $g) {
                    $grants_text .= $g[0] . "\n";
                }
            }

            // Get table structure
            $pv_columns = $wpdb->get_results("SHOW COLUMNS FROM $pv_table", ARRAY_A);

            $latest_view = $wpdb->get_row("SELECT created_at, page_url FROM $pv_table ORDER BY id DESC LIMIT 1");
            $total_all = $wpdb->get_var("SELECT COUNT(*) FROM $pv_table");

            $js_file = MICROHUB_PLUGIN_DIR . 'assets/js/tracking.js';
            $js_exists = file_exists($js_file);
            $js_content = $js_exists ? file_get_contents($js_file) : '';
            $js_has_v310 = strpos($js_content, 'v3.10') !== false;
            ?>

            <?php if ($test_error): ?>
                <div class="notice notice-error" style="margin: 0 0 15px 0;">
                    <p><strong>DATABASE INSERT FAILED:</strong> <code><?php echo esc_html($test_error); ?></code></p>
                    <p>This is why tracking shows zero page views. The database is rejecting inserts into the tracking tables.</p>
                </div>
            <?php elseif ($test_insert_id): ?>
                <div class="notice notice-success" style="margin: 0 0 15px 0;">
                    <p><strong>Database insert test PASSED!</strong> Tracking should be working. Check browser console (F12) on a frontend page for [MH] messages.</p>
                </div>
            <?php endif; ?>

            <table class="widefat striped" style="max-width: 750px; border: 0;">
                <tbody>
                    <tr><td colspan="3" style="background:#f0f0f1;"><strong>Plugin Status</strong></td></tr>
                    <tr>
                        <td>Plugin Version</td>
                        <td><code><?php echo esc_html($plugin_version); ?></code></td>
                        <td><?php echo version_compare($plugin_version, '3.10.0', '>=') ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>
                    <tr>
                        <td>tracking.js</td>
                        <td><?php echo $js_has_v310 ? 'v3.10' : '&#10060; OLD FILE'; ?></td>
                        <td><?php echo $js_has_v310 ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>

                    <tr><td colspan="3" style="background:#f0f0f1;"><strong>Database Info</strong></td></tr>
                    <tr>
                        <td>MySQL Version</td>
                        <td><code><?php echo esc_html($mysql_version); ?></code></td>
                        <td>&#9989;</td>
                    </tr>
                    <tr>
                        <td>MySQL User</td>
                        <td><code><?php echo esc_html($mysql_user); ?></code></td>
                        <td>&#9989;</td>
                    </tr>
                    <tr>
                        <td>Total tables in DB</td>
                        <td><?php echo esc_html($total_tables); ?></td>
                        <td><?php echo $total_tables < 100 ? '&#9989;' : '&#9888;&#65039; Many tables'; ?></td>
                    </tr>
                    <tr>
                        <td>Database size</td>
                        <td><?php echo esc_html($db_size_mb); ?> MB</td>
                        <td>&#9989;</td>
                    </tr>
                    <tr>
                        <td>Direct INSERT test</td>
                        <td><?php echo $test_result ? '<span style="color:#00a32a">SUCCESS (ID: ' . $test_insert_id . ')</span>' : '<span style="color:#d63638">FAILED: ' . esc_html($test_error) . '</span>'; ?></td>
                        <td><?php echo $test_result ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>

                    <tr><td colspan="3" style="background:#f0f0f1;"><strong>Tracking Tables</strong></td></tr>
                    <tr>
                        <td>mh_page_views</td>
                        <td><?php echo $tables_ok ? ($pv_status ? esc_html($pv_status->ENGINE . ' / ' . $pv_status->TABLE_ROWS . ' rows / ' . $pv_status->size_kb . ' KB') : 'Exists') : 'MISSING'; ?></td>
                        <td><?php echo $tables_ok ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>
                    <tr>
                        <td>mh_tracking_events</td>
                        <td><?php echo $events_ok ? ($ev_status ? esc_html($ev_status->ENGINE . ' / ' . $ev_status->TABLE_ROWS . ' rows / ' . $ev_status->size_kb . ' KB') : 'Exists') : 'MISSING'; ?></td>
                        <td><?php echo $events_ok ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>

                    <tr><td colspan="3" style="background:#f0f0f1;"><strong>Page View Data</strong></td></tr>
                    <tr>
                        <td>Total page views</td>
                        <td><?php echo number_format($total_all); ?></td>
                        <td><?php echo $total_all > 0 ? '&#9989;' : '&#9888;&#65039;'; ?></td>
                    </tr>
                    <tr>
                        <td>Latest page view</td>
                        <td><?php echo $latest_view ? esc_html($latest_view->created_at . ' — ' . $latest_view->page_url) : 'None'; ?></td>
                        <td><?php echo $latest_view ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>
                </tbody>
            </table>

            <?php if ($pv_columns): ?>
            <h3 style="margin-top:15px;">Table Structure (mh_page_views)</h3>
            <table class="widefat striped" style="max-width: 750px; font-size: 12px;">
                <thead><tr><th>Column</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr></thead>
                <tbody>
                <?php foreach ($pv_columns as $col): ?>
                    <tr>
                        <td><?php echo esc_html($col['Field']); ?></td>
                        <td><?php echo esc_html($col['Type']); ?></td>
                        <td><?php echo esc_html($col['Null']); ?></td>
                        <td><?php echo esc_html($col['Key']); ?></td>
                        <td><?php echo esc_html($col['Default'] ?? 'NULL'); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>

            <?php if (!empty($grants_text)): ?>
            <h3 style="margin-top:15px;">MySQL Grants</h3>
            <pre style="background:#1d2327;color:#c3c4c7;padding:10px;font-size:11px;overflow-x:auto;max-width:750px;"><?php echo esc_html($grants_text); ?></pre>
            <?php endif; ?>

            <!-- Repair Tools -->
            <h3 style="margin-top:20px;">Repair Tools</h3>

            <?php
            // Handle table rebuild
            if (isset($_POST['mh_rebuild_tables']) && check_admin_referer('mh_rebuild_tables_nonce')) {
                // Drop and recreate
                $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}mh_page_views");
                $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}mh_tracking_events");
                $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}mh_bot_blocks");
                delete_option('mh_tracking_db_version');

                require_once MICROHUB_PLUGIN_DIR . 'includes/class-microhub-activator.php';
                MicroHub_Activator::activate();

                // Test insert after rebuild
                $rebuild_test = $wpdb->insert($pv_table, array(
                    'session_id' => 'rebuild_test_' . time(),
                    'page_url'   => '/rebuild-test/',
                    'page_title' => 'Rebuild Test',
                    'post_id'    => 0,
                    'post_type'  => '',
                    'referrer'   => '',
                    'user_agent' => 'RebuildTest',
                    'ip_hash'    => 'test',
                    'is_bot'     => 0,
                    'duration'   => 0,
                ), array('%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%d'));
                $rebuild_error = $wpdb->last_error;

                if ($rebuild_test) {
                    echo '<div class="notice notice-success"><p>Tables rebuilt and INSERT test <strong>PASSED</strong>! Tracking should work now. <a href="' . esc_url(admin_url('admin.php?page=microhub-analytics')) . '">Refresh page</a></p></div>';
                } else {
                    echo '<div class="notice notice-error"><p>Tables rebuilt but INSERT still <strong>FAILED</strong>: <code>' . esc_html($rebuild_error) . '</code></p><p>This is a database-level restriction from SiteGround. You may need to contact SiteGround support or check your hosting plan\'s database limits.</p></div>';
                }
            }
            ?>

            <form method="post" style="display:inline;">
                <?php wp_nonce_field('mh_rebuild_tables_nonce'); ?>
                <input type="submit" name="mh_rebuild_tables" class="button"
                       value="Drop &amp; Rebuild Tracking Tables"
                       onclick="return confirm('This will delete all existing tracking data and recreate the tables. Continue?');" />
            </form>

            <h3 style="margin-top:20px;">Live Endpoint Tests</h3>
            <p>Click both buttons. At least one MUST show green:</p>

            <div style="display:flex;gap:15px;flex-wrap:wrap;margin-bottom:15px;">
                <div>
                    <button type="button" id="mh-test-rest" class="button button-primary">Test REST API</button>
                    <div id="mh-test-rest-result" style="margin-top:8px;font-size:13px;"></div>
                </div>
                <div>
                    <button type="button" id="mh-test-ajax" class="button">Test admin-ajax.php</button>
                    <div id="mh-test-ajax-result" style="margin-top:8px;font-size:13px;"></div>
                </div>
            </div>

            <script>
            document.getElementById('mh-test-rest').addEventListener('click', function() {
                var btn = this, result = document.getElementById('mh-test-rest-result');
                btn.disabled = true;
                result.innerHTML = '<span style="color:#666">Sending...</span>';
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo esc_js(rest_url('microhub/v1/track/pageview')); ?>', true);
                xhr.setRequestHeader('Content-Type', 'application/json');
                xhr.onload = function() {
                    btn.disabled = false;
                    try {
                        var r = JSON.parse(xhr.responseText);
                        if (r.success) result.innerHTML = '<span style="color:#00a32a">&#9989; REST works! ID: ' + (r.data && r.data.id || '?') + '</span>';
                        else result.innerHTML = '<span style="color:#d63638">&#10060; REST failed (' + xhr.status + '): ' + JSON.stringify(r.data || r.message || r).substring(0,300) + '</span>';
                    } catch(e) { result.innerHTML = '<span style="color:#d63638">&#10060; (' + xhr.status + '): ' + xhr.responseText.substring(0,300) + '</span>'; }
                };
                xhr.onerror = function() { btn.disabled = false; result.innerHTML = '<span style="color:#d63638">&#10060; Network error</span>'; };
                xhr.send(JSON.stringify({ session_id: 'diag_rest_' + Date.now(), page_url: '/diagnostic-test/', page_title: 'Test', post_id: 0, post_type: '', referrer: '' }));
            });

            document.getElementById('mh-test-ajax').addEventListener('click', function() {
                var btn = this, result = document.getElementById('mh-test-ajax-result');
                btn.disabled = true;
                result.innerHTML = '<span style="color:#666">Sending...</span>';
                var fd = new FormData();
                fd.append('action', 'mh_track_pageview');
                fd.append('session_id', 'diag_ajax_' + Date.now());
                fd.append('page_url', '/diagnostic-test/');
                fd.append('page_title', 'Test');
                fd.append('post_id', '0'); fd.append('post_type', ''); fd.append('referrer', '');
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo esc_js(admin_url('admin-ajax.php')); ?>', true);
                xhr.onload = function() {
                    btn.disabled = false;
                    try {
                        var r = JSON.parse(xhr.responseText);
                        if (r.success) result.innerHTML = '<span style="color:#00a32a">&#9989; AJAX works! ID: ' + (r.data && r.data.id || '?') + '</span>';
                        else result.innerHTML = '<span style="color:#d63638">&#10060; (' + xhr.status + '): ' + JSON.stringify(r.data).substring(0,300) + '</span>';
                    } catch(e) { result.innerHTML = '<span style="color:#d63638">&#10060; (' + xhr.status + '): ' + xhr.responseText.substring(0,300) + '</span>'; }
                };
                xhr.onerror = function() { btn.disabled = false; result.innerHTML = '<span style="color:#d63638">&#10060; Network error</span>'; };
                xhr.send(fd);
            });
            </script>

            <h3 style="margin-top:20px;">Frontend Check</h3>
            <p>Open any page, press F12, check Console for <code>[MH]</code> messages.</p>
        </div>
<?php /* OLD DIAGNOSTIC REMOVED - keeping only the new v3.10 diagnostic above */
if (false):
            $js_content_OLD = '';
            $js_has_v310 = strpos($js_content, 'v3.10') !== false;
            $js_has_rest = strpos($js_content, 'restUrl') !== false;
            $rest_url = rest_url('microhub/v1/track/pageview');
            ?>

            <table class="widefat striped" style="max-width: 700px; border: 0;">
                <tbody>
                    <tr>
                        <td><strong>Plugin Version</strong></td>
                        <td><code><?php echo esc_html($plugin_version); ?></code></td>
                        <td><?php echo version_compare($plugin_version, '3.10.0', '>=') ? '&#9989;' : '&#10060; OLD — need 3.10.0+'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>tracking.js version</strong></td>
                        <td><?php echo $js_has_v310 ? 'v3.10 (simplified)' : 'OLD FILE — not v3.10!'; ?> (<?php echo esc_html($js_size); ?> bytes)</td>
                        <td><?php echo $js_has_v310 ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>tracking.js has REST?</strong></td>
                        <td><?php echo $js_has_rest ? 'Yes' : 'No'; ?></td>
                        <td><?php echo $js_has_rest ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>mh_page_views table</strong></td>
                        <td><?php echo $tables_ok ? 'Exists' : 'MISSING'; ?></td>
                        <td><?php echo $tables_ok ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>mh_tracking_events table</strong></td>
                        <td><?php echo $events_ok ? 'Exists' : 'MISSING'; ?></td>
                        <td><?php echo $events_ok ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Total page views</strong></td>
                        <td><?php echo number_format($total_all); ?></td>
                        <td><?php echo $total_all > 0 ? '&#9989;' : '&#9888;&#65039; Empty'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Page views today</strong></td>
                        <td><?php echo number_format($total_today); ?></td>
                        <td><?php echo $total_today > 0 ? '&#9989;' : '&#9888;&#65039; None yet'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Latest page view</strong></td>
                        <td><?php echo $latest_view ? esc_html($latest_view->created_at . ' — ' . substr($latest_view->page_url, 0, 50)) : 'No data'; ?></td>
                        <td><?php echo $latest_view ? '&#9989;' : '&#10060;'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>REST API URL</strong></td>
                        <td><code style="font-size:11px;word-break:break-all;"><?php echo esc_html($rest_url); ?></code></td>
                        <td>&#9989;</td>
                    </tr>
                    <tr>
                        <td><strong>AJAX URL</strong></td>
                        <td><code style="font-size:11px;"><?php echo esc_html(admin_url('admin-ajax.php')); ?></code></td>
                        <td>&#9989;</td>
                    </tr>
                    <tr>
                        <td><strong>Bot Guard</strong></td>
                        <td>DISABLED (removed all blocking)</td>
                        <td>&#9989;</td>
                    </tr>
                    <tr>
                        <td><strong>Token Auth</strong></td>
                        <td>DISABLED (removed — was potential failure point)</td>
                        <td>&#9989;</td>
                    </tr>
                </tbody>
            </table>

            <h3 style="margin-top:20px;">Live Endpoint Tests</h3>
            <p>Click both buttons. At least one MUST show green:</p>

            <div style="display:flex;gap:15px;flex-wrap:wrap;margin-bottom:15px;">
                <div>
                    <button type="button" id="mh-test-rest" class="button button-primary">Test REST API</button>
                    <div id="mh-test-rest-result" style="margin-top:8px;font-size:13px;"></div>
                </div>
                <div>
                    <button type="button" id="mh-test-ajax" class="button">Test admin-ajax.php</button>
                    <div id="mh-test-ajax-result" style="margin-top:8px;font-size:13px;"></div>
                </div>
            </div>

            <script>
            document.getElementById('mh-test-rest').addEventListener('click', function() {
                var btn = this, result = document.getElementById('mh-test-rest-result');
                btn.disabled = true;
                result.innerHTML = '<span style="color:#666">Sending...</span>';
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo esc_js($rest_url); ?>', true);
                xhr.setRequestHeader('Content-Type', 'application/json');
                xhr.onload = function() {
                    btn.disabled = false;
                    try {
                        var r = JSON.parse(xhr.responseText);
                        if (r.success) result.innerHTML = '<span style="color:#00a32a">&#9989; REST works! (HTTP ' + xhr.status + ') ID: ' + (r.data && r.data.id || '?') + '</span>';
                        else result.innerHTML = '<span style="color:#d63638">&#10060; REST failed (' + xhr.status + '): ' + JSON.stringify(r.data || r.message || r).substring(0,200) + '</span>';
                    } catch(e) { result.innerHTML = '<span style="color:#d63638">&#10060; REST error (' + xhr.status + '): ' + xhr.responseText.substring(0,200) + '</span>'; }
                };
                xhr.onerror = function() { btn.disabled = false; result.innerHTML = '<span style="color:#d63638">&#10060; Network error</span>'; };
                xhr.send(JSON.stringify({ session_id: 'diag_rest_' + Date.now(), page_url: '/diagnostic-test-rest/', page_title: 'REST Test', post_id: 0, post_type: '', referrer: '' }));
            });

            document.getElementById('mh-test-ajax').addEventListener('click', function() {
                var btn = this, result = document.getElementById('mh-test-ajax-result');
                btn.disabled = true;
                result.innerHTML = '<span style="color:#666">Sending...</span>';
                var fd = new FormData();
                fd.append('action', 'mh_track_pageview');
                fd.append('session_id', 'diag_ajax_' + Date.now());
                fd.append('page_url', '/diagnostic-test-ajax/');
                fd.append('page_title', 'AJAX Test');
                fd.append('post_id', '0');
                fd.append('post_type', '');
                fd.append('referrer', '');
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo esc_js(admin_url('admin-ajax.php')); ?>', true);
                xhr.onload = function() {
                    btn.disabled = false;
                    try {
                        var r = JSON.parse(xhr.responseText);
                        if (r.success) result.innerHTML = '<span style="color:#00a32a">&#9989; AJAX works! (' + xhr.status + ') ID: ' + (r.data && r.data.id || '?') + '</span>';
                        else result.innerHTML = '<span style="color:#d63638">&#10060; AJAX failed (' + xhr.status + '): ' + JSON.stringify(r.data).substring(0,200) + '</span>';
                    } catch(e) { result.innerHTML = '<span style="color:#d63638">&#10060; AJAX error (' + xhr.status + '): ' + xhr.responseText.substring(0,200) + '</span>'; }
                };
                xhr.onerror = function() { btn.disabled = false; result.innerHTML = '<span style="color:#d63638">&#10060; Network error</span>'; };
                xhr.send(fd);
            });
            </script>

            <h3 style="margin-top:20px;">Frontend Check</h3>
            <p>Open any page on your site, press <strong>F12</strong> (browser dev tools), go to <strong>Console</strong> tab. You should see:</p>
            <code style="background:#f1f1f1;padding:8px 12px;display:block;max-width:600px;margin-bottom:8px;">[MicroHub Tracking] Initializing...</code>
            <code style="background:#f1f1f1;padding:8px 12px;display:block;max-width:600px;margin-bottom:8px;">[MicroHub Tracking] Recording page view: /your-page/</code>
            <code style="background:#f1f1f1;padding:8px 12px;display:block;max-width:600px;">[MicroHub Tracking] REST OK: mh_track_pageview</code>
            <p style="margin-top:10px;">If you see errors instead, they will tell us exactly what's blocked.</p>
endif; ?>

        <!-- Data Management -->
        <div style="background: #fff; border: 1px solid #c3c4c7; padding: 20px; border-radius: 4px;">
            <h2 style="margin-top: 0;">Data Management</h2>
            <p style="color: #646970;">Analytics data is automatically cleaned up after 90 days. You can also clear it manually.</p>

            <?php if (isset($_POST['mh_clear_analytics']) && check_admin_referer('mh_clear_analytics_nonce')) :
                $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}mh_page_views");
                $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}mh_tracking_events");
                $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}mh_bot_blocks");
            ?>
                <div class="notice notice-success"><p>All analytics data has been cleared.</p></div>
            <?php endif; ?>

            <form method="post" action="">
                <?php wp_nonce_field('mh_clear_analytics_nonce'); ?>
                <input type="submit" name="mh_clear_analytics" class="button" style="color: #d63638; border-color: #d63638;"
                       value="Clear All Analytics Data"
                       onclick="return confirm('Are you sure? This will delete all tracking data permanently.');" />
            </form>
        </div>
    </div>

    <!-- Chart.js from CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <script>
    (function() {
        var ctx = document.getElementById('mh-traffic-chart');
        if (!ctx) return;

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo wp_json_encode($chart_labels); ?>,
                datasets: [
                    {
                        label: 'Page Views',
                        data: <?php echo wp_json_encode($chart_views); ?>,
                        borderColor: '#2271b1',
                        backgroundColor: 'rgba(34, 113, 177, 0.1)',
                        fill: true,
                        tension: 0.3,
                        borderWidth: 2,
                        pointRadius: 3
                    },
                    {
                        label: 'Unique Visitors',
                        data: <?php echo wp_json_encode($chart_visitors); ?>,
                        borderColor: '#00a32a',
                        backgroundColor: 'rgba(0, 163, 42, 0.1)',
                        fill: true,
                        tension: 0.3,
                        borderWidth: 2,
                        pointRadius: 3
                    }
                ]
            },
            options: {
                responsive: true,
                interaction: { intersect: false, mode: 'index' },
                plugins: {
                    legend: { position: 'top' }
                },
                scales: {
                    y: { beginAtZero: true, ticks: { precision: 0 } }
                }
            }
        });
    })();
    </script>

    <style>
    .mh-analytics-wrap h2 { font-size: 16px; font-weight: 600; }
    .mh-analytics-wrap .widefat td, .mh-analytics-wrap .widefat th { padding: 8px 10px; }
    @media (max-width: 960px) {
        .mh-stats-grid { grid-template-columns: repeat(2, 1fr) !important; }
    }
    </style>
    <?php
}
