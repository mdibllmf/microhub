<?php
/**
 * Plugin Name: MicroHub - Microscopy Research Repository
 * Plugin URI: https://github.com/mdibllmf/microhub
 * Description: Professional microscopy research paper repository with AI chat, protocols, GitHub integration, and community discussions.
 * Version: 3.9.0
 * Author: MicroHub Team
 * License: GPL-2.0+
 * Text Domain: microhub
 */

if (!defined('WPINC')) {
    die;
}

define('MICROHUB_VERSION', '3.9.0');
define('MICROHUB_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MICROHUB_PLUGIN_URL', plugin_dir_url(__FILE__));

// Activation
function activate_microhub() {
    // Load required classes first
    require_once MICROHUB_PLUGIN_DIR . 'includes/class-microhub-post-types.php';
    require_once MICROHUB_PLUGIN_DIR . 'includes/class-microhub-taxonomies.php';
    
    // Register post types and taxonomies BEFORE flushing
    MicroHub_Post_Types::register();
    MicroHub_Taxonomies::register();
    
    require_once MICROHUB_PLUGIN_DIR . 'includes/class-microhub-activator.php';
    MicroHub_Activator::activate();
    
    // Flush rewrite rules now that post types/taxonomies are registered
    flush_rewrite_rules();
    
    // Also set transient for delayed flush on next page load
    set_transient('microhub_flush_rewrite_rules', true, 60);
}
register_activation_hook(__FILE__, 'activate_microhub');

// Check for delayed flush on init
add_action('init', function() {
    if (get_transient('microhub_flush_rewrite_rules')) {
        delete_transient('microhub_flush_rewrite_rules');
        flush_rewrite_rules();
    }
}, 999); // Run late after all post types and taxonomies are registered

// Flush rewrite rules on plugin update (version change)
add_action('init', function() {
    $stored_version = get_option('microhub_plugin_version', '');
    if ($stored_version !== MICROHUB_VERSION) {
        update_option('microhub_plugin_version', MICROHUB_VERSION);
        flush_rewrite_rules();
    }
}, 1000);

// Deactivation
function deactivate_microhub() {
    require_once MICROHUB_PLUGIN_DIR . 'includes/class-microhub-deactivator.php';
    MicroHub_Deactivator::deactivate();
}
register_deactivation_hook(__FILE__, 'deactivate_microhub');

// Load classes
require_once MICROHUB_PLUGIN_DIR . 'includes/class-microhub-post-types.php';
require_once MICROHUB_PLUGIN_DIR . 'includes/class-microhub-taxonomies.php';
require_once MICROHUB_PLUGIN_DIR . 'includes/class-microhub-meta-boxes.php';
require_once MICROHUB_PLUGIN_DIR . 'includes/class-microhub-api.php';
require_once MICROHUB_PLUGIN_DIR . 'includes/class-microhub-shortcodes.php';
require_once MICROHUB_PLUGIN_DIR . 'includes/class-microhub-modular-shortcodes.php';
require_once MICROHUB_PLUGIN_DIR . 'includes/navigation-helper.php';
require_once MICROHUB_PLUGIN_DIR . 'includes/class-microhub-bot-guard.php';
require_once MICROHUB_PLUGIN_DIR . 'includes/class-microhub-tracking.php';

if (is_admin()) {
    require_once MICROHUB_PLUGIN_DIR . 'admin/admin-settings.php';
    require_once MICROHUB_PLUGIN_DIR . 'admin/admin-import.php';
    require_once MICROHUB_PLUGIN_DIR . 'admin/admin-diagnostics.php';
    require_once MICROHUB_PLUGIN_DIR . 'admin/admin-review.php';
    require_once MICROHUB_PLUGIN_DIR . 'admin/admin-ai-training.php';
    require_once MICROHUB_PLUGIN_DIR . 'admin/admin-ai-knowledge.php';
    require_once MICROHUB_PLUGIN_DIR . 'admin/admin-update-metrics.php';
    require_once MICROHUB_PLUGIN_DIR . 'admin/admin-analytics.php';
}

// Check if analytics tables need creating (handles upgrades without reactivation)
// Also verify tables actually exist even if version says '1.0' (dbDelta may have failed)
add_action('init', function() {
    global $wpdb;
    $needs_tables = get_option('mh_tracking_db_version') !== '1.0';
    if (!$needs_tables) {
        // Double-check: version says 1.0 but tables might not exist (dbDelta silent failure)
        $table = $wpdb->prefix . 'mh_page_views';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
            $needs_tables = true;
            delete_option('mh_tracking_db_version'); // Reset so activator retries
        }
    }
    if ($needs_tables) {
        require_once MICROHUB_PLUGIN_DIR . 'includes/class-microhub-activator.php';
        MicroHub_Activator::activate();
    }
}, 20);

// Initialize plugin
function run_microhub() {
    $post_types = new MicroHub_Post_Types();
    $post_types->init();

    $taxonomies = new MicroHub_Taxonomies();
    $taxonomies->init();

    $meta_boxes = new MicroHub_Meta_Boxes();
    $meta_boxes->init();

    $api = new MicroHub_API();
    $api->init();

    $shortcodes = new MicroHub_Shortcodes();
    $shortcodes->init();

    // Bot protection (runs on every frontend request, transparent to users)
    $bot_guard = new MicroHub_Bot_Guard();
    $bot_guard->init();

    // Visitor tracking (page views, events, session duration)
    $tracking = new MicroHub_Tracking();
    $tracking->init();

    add_action('wp_enqueue_scripts', 'microhub_enqueue_scripts');
    add_action('admin_enqueue_scripts', 'microhub_admin_enqueue_scripts');
    add_filter('single_template', 'microhub_single_template');
    add_filter('comments_open', 'microhub_enable_paper_comments', 10, 2);

    // Clear caches when MicroHub posts are created, updated, or deleted
    add_action('transition_post_status', 'microhub_clear_caches_on_change', 10, 3);
    add_action('before_delete_post', 'microhub_clear_caches_on_delete');
    
    // Allow guest comments on MicroHub papers (name required, email optional)
    add_filter('pre_comment_approved', 'microhub_allow_guest_comments', 10, 2);
    add_filter('preprocess_comment', 'microhub_preprocess_comment');

    // AJAX handlers for discussions (logged-in AND guest users)
    add_action('wp_ajax_mh_new_discussion', 'microhub_ajax_new_discussion');
    add_action('wp_ajax_nopriv_mh_new_discussion', 'microhub_ajax_new_discussion');
    add_action('wp_ajax_mh_submit_reply', 'microhub_ajax_submit_reply');
    add_action('wp_ajax_nopriv_mh_submit_reply', 'microhub_ajax_submit_reply');
}
add_action('plugins_loaded', 'run_microhub');

/**
 * AJAX handler: Create a new discussion
 */
function microhub_ajax_new_discussion() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mh_discussion_ajax')) {
        wp_send_json_error(array('message' => 'Security check failed. Please refresh the page and try again.'));
    }

    $title = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '';
    $content = isset($_POST['content']) ? sanitize_textarea_field($_POST['content']) : '';
    $author_name = isset($_POST['author_name']) ? sanitize_text_field($_POST['author_name']) : '';
    $author_email = isset($_POST['author_email']) ? sanitize_email($_POST['author_email']) : '';
    $category = isset($_POST['category']) ? sanitize_text_field($_POST['category']) : 'qa';

    // Use logged-in user info if available
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        if (empty($author_name)) {
            $author_name = $current_user->display_name;
        }
        if (empty($author_email)) {
            $author_email = $current_user->user_email;
        }
    }

    if (empty($title) || empty($content) || empty($author_name)) {
        wp_send_json_error(array('message' => 'Please fill in the title, message, and your name.'));
    }

    if (!empty($author_email) && !is_email($author_email)) {
        wp_send_json_error(array('message' => 'Please enter a valid email address.'));
    }

    $post_id = wp_insert_post(array(
        'post_type'      => 'mh_discussion',
        'post_title'     => $title,
        'post_content'   => $content,
        'post_status'    => 'publish',
        'comment_status' => 'open',
    ));

    if ($post_id && !is_wp_error($post_id)) {
        update_post_meta($post_id, '_mh_author_name', $author_name);
        update_post_meta($post_id, '_mh_author_email', $author_email);
        update_post_meta($post_id, '_mh_category', $category);

        // Flush rewrite rules to ensure the new post's permalink works
        flush_rewrite_rules();

        // Get the discussions listing page URL to redirect back to
        $discussions_url = '';
        if (function_exists('mh_get_page_url')) {
            $discussions_url = mh_get_page_url('discussions');
        }
        if (empty($discussions_url)) {
            $discussions_url = home_url('/discussions/');
        }

        wp_send_json_success(array(
            'message'        => 'Discussion posted successfully!',
            'post_id'        => $post_id,
            'post_url'       => get_permalink($post_id),
            'discussions_url' => $discussions_url,
        ));
    } else {
        $error_msg = is_wp_error($post_id) ? $post_id->get_error_message() : 'Unknown error creating discussion.';
        wp_send_json_error(array('message' => 'Error creating discussion: ' . $error_msg));
    }
}

/**
 * AJAX handler: Submit a reply to a discussion
 */
function microhub_ajax_submit_reply() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mh_discussion_ajax')) {
        wp_send_json_error(array('message' => 'Security check failed. Please refresh the page and try again.'));
    }

    $post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
    $content = isset($_POST['content']) ? sanitize_textarea_field($_POST['content']) : '';
    $author_name = isset($_POST['author_name']) ? sanitize_text_field($_POST['author_name']) : '';
    $author_email = isset($_POST['author_email']) ? sanitize_email($_POST['author_email']) : '';

    // Use logged-in user info if available
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        if (empty($author_name)) {
            $author_name = $current_user->display_name;
        }
        if (empty($author_email)) {
            $author_email = $current_user->user_email;
        }
    }

    if (empty($post_id) || empty($content) || empty($author_name)) {
        wp_send_json_error(array('message' => 'Please fill in your reply and name.'));
    }

    // Verify the target post exists and is a discussion
    $post = get_post($post_id);
    if (!$post || $post->post_type !== 'mh_discussion') {
        wp_send_json_error(array('message' => 'Discussion not found.'));
    }

    if (!empty($author_email) && !is_email($author_email)) {
        wp_send_json_error(array('message' => 'Please enter a valid email address.'));
    }

    $comment_id = wp_insert_comment(array(
        'comment_post_ID'    => $post_id,
        'comment_content'    => $content,
        'comment_author'     => $author_name,
        'comment_author_email' => $author_email,
        'comment_approved'   => 1,
    ));

    if ($comment_id) {
        $comment = get_comment($comment_id);
        $initials = strtoupper(substr($author_name, 0, 2));
        $reply_count = get_comments(array('post_id' => $post_id, 'status' => 'approve', 'count' => true));

        wp_send_json_success(array(
            'message'     => 'Reply posted successfully!',
            'comment_id'  => $comment_id,
            'author'      => $author_name,
            'initials'    => $initials,
            'content'     => nl2br(esc_html($content)),
            'date'        => 'just now',
            'reply_count' => $reply_count,
        ));
    } else {
        wp_send_json_error(array('message' => 'Error posting reply. Please try again.'));
    }
}

// Enable comments on papers and discussions
function microhub_enable_paper_comments($open, $post_id) {
    $post = get_post($post_id);
    if ($post && in_array($post->post_type, array('mh_paper', 'mh_discussion'))) {
        return true;
    }
    return $open;
}

// Allow comments without email for MicroHub papers and discussions
function microhub_allow_guest_comments($approved, $commentdata) {
    $post = get_post($commentdata['comment_post_ID']);
    if ($post && in_array($post->post_type, array('mh_paper', 'mh_discussion'))) {
        // Check if there's an author name
        if (empty($commentdata['comment_author'])) {
            return new WP_Error('require_name', 'Please enter your name to post a comment.');
        }
        // Auto-approve if name is provided
        return 1;
    }
    return $approved;
}

// Preprocess comment to allow empty email
function microhub_preprocess_comment($commentdata) {
    $post = get_post($commentdata['comment_post_ID']);
    if ($post && in_array($post->post_type, array('mh_paper', 'mh_discussion'))) {
        // If email is empty, set a placeholder to bypass WordPress validation
        if (empty($commentdata['comment_author_email'])) {
            $commentdata['comment_author_email'] = '';
        }
    }
    return $commentdata;
}

// Templates
function microhub_single_template($template) {
    global $post;
    if ($post && $post->post_type === 'mh_paper') {
        $custom = MICROHUB_PLUGIN_DIR . 'templates/single-mh_paper.php';
        if (file_exists($custom)) return $custom;
    }
    if ($post && $post->post_type === 'mh_discussion') {
        // Only use plugin template if theme doesn't provide one
        $theme_template = locate_template('single-mh_discussion.php');
        if ($theme_template) return $theme_template;
        $custom = MICROHUB_PLUGIN_DIR . 'templates/single-mh_discussion.php';
        if (file_exists($custom)) return $custom;
    }
    return $template;
}


// Enqueue frontend assets
function microhub_enqueue_scripts() {
    global $post;
    
    $should_load = is_singular('mh_paper') ||
                   is_singular('mh_protocol') ||
                   is_singular('mh_discussion') ||
                   is_tax('mh_technique') || 
                   is_tax('mh_microscope') || 
                   is_tax('mh_organism');
    
    if (!$should_load && is_a($post, 'WP_Post')) {
        $shortcodes = array('microhub_search_page', 'microhub_papers', 'microhub_featured', 'microhub_stats', 'microhub_forum', 'microhub_upload_protocol', 'microhub_upload_paper');
        foreach ($shortcodes as $sc) {
            if (has_shortcode($post->post_content, $sc)) {
                $should_load = true;
                break;
            }
        }
    }
    
    if ($should_load) {
        wp_enqueue_style(
            'microhub-frontend',
            MICROHUB_PLUGIN_URL . 'assets/css/microhub-frontend.css',
            array(),
            MICROHUB_VERSION
        );

        wp_enqueue_script(
            'microhub-frontend',
            MICROHUB_PLUGIN_URL . 'assets/js/frontend.js',
            array('jquery'),
            MICROHUB_VERSION,
            true
        );

        wp_localize_script('microhub-frontend', 'microhubData', array(
            'apiBase' => rest_url('microhub/v1'),
            'nonce' => wp_create_nonce('wp_rest'),
            'ajaxurl' => admin_url('admin-ajax.php'),
            'discussionNonce' => wp_create_nonce('mh_discussion_ajax'),
            'copilotUrl' => get_option('microhub_copilot_bot_url', ''),
            'copilotName' => get_option('microhub_copilot_bot_name', 'MicroHub Assistant'),
        ));
    }
}

// Admin assets
function microhub_admin_enqueue_scripts($hook) {
    global $post_type;
    if (strpos($hook, 'microhub') === false && !in_array($post_type, array('mh_paper', 'mh_protocol', 'mh_discussion'))) return;
    
    wp_enqueue_style('microhub-admin', MICROHUB_PLUGIN_URL . 'assets/css/microhub-admin.css', array(), MICROHUB_VERSION);
    wp_enqueue_script('microhub-admin', MICROHUB_PLUGIN_URL . 'assets/js/microhub-admin.js', array('jquery'), MICROHUB_VERSION, true);
}

// Clear MicroHub caches when papers/protocols are modified or deleted
function microhub_clear_caches_on_change($new_status, $old_status, $post) {
    if (!$post || !in_array($post->post_type, array('mh_paper', 'mh_protocol', 'mh_discussion'))) {
        return;
    }
    // Only clear if the status actually changed (published, trashed, deleted, etc.)
    if ($new_status !== $old_status) {
        microhub_invalidate_caches();
    }
}

function microhub_clear_caches_on_delete($post_id) {
    $post = get_post($post_id);
    if (!$post || !in_array($post->post_type, array('mh_paper', 'mh_protocol', 'mh_discussion'))) {
        return;
    }
    microhub_invalidate_caches();
}

function microhub_invalidate_caches() {
    global $wpdb;
    delete_transient('mh_filter_options');
    delete_transient('mh_stats');
    delete_transient('mh_enrichment_stats');
    // Only clear content caches, not rate-limit transients (mh_rl_*) or block transients (mh_blocked_*)
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE (option_name LIKE '_transient_mh_filter%' OR option_name LIKE '_transient_mh_stats%' OR option_name LIKE '_transient_mh_enrichment%' OR option_name LIKE '_transient_timeout_mh_filter%' OR option_name LIKE '_transient_timeout_mh_stats%' OR option_name LIKE '_transient_timeout_mh_enrichment%')");
}

// Settings are handled in admin/admin-settings.php
