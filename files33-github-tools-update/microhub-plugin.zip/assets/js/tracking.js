/**
 * MicroHub Visitor Tracking v3.9
 *
 * Tracks: page views, time on page, tag/filter clicks, link clicks, searches.
 * Privacy-friendly: no personal data collected, session-based only.
 *
 * Uses REST API as primary endpoint, admin-ajax.php as fallback.
 * SiteGround and security plugins often block admin-ajax.php for anonymous users,
 * but REST API routes (/wp-json/microhub/v1/track/*) work reliably.
 *
 * No jQuery dependency — pure vanilla JS.
 */
(function() {
    'use strict';

    if (typeof mhTracking === 'undefined') {
        console.warn('[MicroHub Tracking] mhTracking not found — script localization failed. Tracking disabled.');
        return;
    }

    console.log('[MicroHub Tracking] Initializing...', {
        ajaxurl: mhTracking.ajaxurl,
        restUrl: mhTracking.restUrl || 'not set',
        token: mhTracking.token ? mhTracking.token.substring(0, 8) + '...' : 'MISSING'
    });

    // Generate session ID client-side (server cookies don't work on cached pages)
    var sessionId = (function() {
        var match = document.cookie.match(/(?:^|; )mh_sid=([^;]+)/);
        if (match) return match[1];
        var chars = 'abcdefghijklmnopqrstuvwxyz0123456789', sid = '';
        for (var i = 0; i < 32; i++) sid += chars.charAt(Math.floor(Math.random() * chars.length));
        document.cookie = 'mh_sid=' + sid + '; expires=' + new Date(Date.now() + 30*60*1000).toUTCString() + '; path=/; SameSite=Lax';
        return sid;
    })();

    var T = {
        ajaxurl: mhTracking.ajaxurl || '/wp-admin/admin-ajax.php',
        restUrl: mhTracking.restUrl || '',
        token: mhTracking.token,
        sessionId: sessionId,
        postId: mhTracking.postId || 0,
        postType: mhTracking.postType || '',
        startTime: Date.now(),
        heartbeatInterval: null,
        pageUrl: window.location.pathname + window.location.search
    };

    /**
     * POST data via REST API (primary) with admin-ajax.php fallback.
     * REST API bypasses SiteGround/security plugin blocking of admin-ajax.php.
     */
    T.post = function(action, data, callback) {
        // Try REST API first (if available)
        if (T.restUrl) {
            var restEndpoint = '';
            if (action === 'mh_track_pageview') restEndpoint = T.restUrl + '/pageview';
            else if (action === 'mh_track_event') restEndpoint = T.restUrl + '/event';
            else if (action === 'mh_track_duration') restEndpoint = T.restUrl + '/duration';

            if (restEndpoint) {
                // Send as JSON to REST API
                var jsonData = {};
                for (var key in data) {
                    if (data.hasOwnProperty(key) && key !== 'action') {
                        jsonData[key] = data[key];
                    }
                }

                try {
                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', restEndpoint, true);
                    xhr.setRequestHeader('Content-Type', 'application/json');
                    xhr.onload = function() {
                        try {
                            var resp = JSON.parse(xhr.responseText);
                            if (resp.success) {
                                console.log('[MicroHub Tracking] REST OK:', action);
                                if (callback) callback(true, resp);
                            } else {
                                console.warn('[MicroHub Tracking] REST failed:', action, resp);
                                // Fallback to admin-ajax
                                T.postAjax(action, data, callback);
                            }
                        } catch(e) {
                            console.warn('[MicroHub Tracking] REST parse error:', xhr.status, xhr.responseText.substring(0, 100));
                            T.postAjax(action, data, callback);
                        }
                    };
                    xhr.onerror = function() {
                        console.warn('[MicroHub Tracking] REST network error, falling back to admin-ajax');
                        T.postAjax(action, data, callback);
                    };
                    xhr.send(JSON.stringify(jsonData));
                    return;
                } catch(e) {
                    console.warn('[MicroHub Tracking] REST exception:', e);
                }
            }
        }

        // No REST URL — use admin-ajax directly
        T.postAjax(action, data, callback);
    };

    /**
     * POST to admin-ajax.php (legacy fallback)
     */
    T.postAjax = function(action, data, callback) {
        var formData = new FormData();
        formData.append('action', action);
        for (var key in data) {
            if (data.hasOwnProperty(key)) {
                formData.append(key, data[key]);
            }
        }
        try {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', T.ajaxurl, true);
            xhr.onload = function() {
                try {
                    var resp = JSON.parse(xhr.responseText);
                    if (resp.success) {
                        console.log('[MicroHub Tracking] AJAX OK:', action);
                    } else {
                        console.warn('[MicroHub Tracking] AJAX failed:', action, resp);
                    }
                    if (callback) callback(resp.success, resp);
                } catch(e) {
                    console.warn('[MicroHub Tracking] AJAX parse error:', xhr.status, xhr.responseText.substring(0, 100));
                    if (callback) callback(false, null);
                }
            };
            xhr.onerror = function() {
                console.error('[MicroHub Tracking] AJAX network error:', action, '— admin-ajax.php may be blocked');
                if (callback) callback(false, null);
            };
            xhr.send(formData);
        } catch(e) {
            console.error('[MicroHub Tracking] AJAX exception:', e);
            if (callback) callback(false, null);
        }
    };

    /**
     * Record page view — this is the PRIMARY tracking call.
     */
    T.recordPageView = function() {
        console.log('[MicroHub Tracking] Recording page view:', T.pageUrl);
        T.post('mh_track_pageview', {
            token: T.token,
            session_id: T.sessionId,
            page_url: T.pageUrl,
            page_title: document.title || '',
            post_id: T.postId,
            post_type: T.postType,
            referrer: document.referrer || ''
        }, function(success) {
            if (success) {
                console.log('[MicroHub Tracking] Page view recorded successfully!');
            } else {
                console.error('[MicroHub Tracking] FAILED to record page view — check Network tab for details');
            }
        });
    };

    /**
     * Send a tracking event
     */
    T.trackEvent = function(eventType, eventTarget, eventValue) {
        T.post('mh_track_event', {
            token: T.token,
            session_id: T.sessionId,
            event_type: eventType,
            event_target: eventTarget || '',
            event_value: eventValue || '',
            post_id: T.postId
        });
    };

    /**
     * Send duration update
     */
    T.updateDuration = function() {
        var duration = Math.round((Date.now() - T.startTime) / 1000);
        if (duration < 1 || duration > 1800) return;

        // Use sendBeacon for reliability on page unload
        if (navigator.sendBeacon) {
            // Try REST API with sendBeacon
            if (T.restUrl) {
                var jsonStr = JSON.stringify({
                    token: T.token,
                    session_id: T.sessionId,
                    duration: duration,
                    page_url: T.pageUrl
                });
                var blob = new Blob([jsonStr], {type: 'application/json'});
                var sent = navigator.sendBeacon(T.restUrl + '/duration', blob);
                if (sent) return;
            }
            // Fallback to admin-ajax with sendBeacon
            var data = new FormData();
            data.append('action', 'mh_track_duration');
            data.append('token', T.token);
            data.append('session_id', T.sessionId);
            data.append('duration', duration);
            data.append('page_url', T.pageUrl);
            navigator.sendBeacon(T.ajaxurl, data);
        } else {
            T.post('mh_track_duration', {
                token: T.token,
                session_id: T.sessionId,
                duration: duration,
                page_url: T.pageUrl
            });
        }
    };

    /**
     * Track tag/taxonomy clicks
     */
    T.bindTagClicks = function() {
        var selectors = [
            'a[href*="/mh_technique/"]',
            'a[href*="/mh_microscope/"]',
            'a[href*="/mh_organism/"]',
            'a[href*="/mh_software/"]',
            'a[href*="/mh_fluorophore/"]',
            'a[href*="/mh_cell_line/"]',
            'a[href*="/mh_sample_prep/"]',
            'a[href*="/mh_facility/"]',
            '.mh-tag',
            '.mh-taxonomy-tag',
            '.mh-technique-tag',
            '.mh-microscope-tag',
            '.mh-organism-tag',
            '.mh-filter-tag',
            '.tag-link'
        ].join(', ');

        document.addEventListener('click', function(e) {
            var el = e.target.closest(selectors);
            if (el) {
                var tagText = (el.textContent || '').trim();
                var href = el.getAttribute('href') || '';
                T.trackEvent('tag_click', href, tagText);
            }
        });
    };

    /**
     * Track link clicks (internal and outbound)
     */
    T.bindLinkClicks = function() {
        document.addEventListener('click', function(e) {
            var el = e.target.closest('a[href]');
            if (!el) return;

            var href = el.getAttribute('href');
            if (!href || href === '#' || href.indexOf('javascript:') === 0) return;

            var linkText = (el.textContent || '').trim().substring(0, 100);
            var currentHost = window.location.hostname;

            try {
                var url = new URL(href, window.location.origin);
                if (url.hostname !== currentHost) {
                    T.trackEvent('outbound_link', href, linkText);
                } else {
                    if (href.indexOf('admin-ajax') === -1 && href.indexOf('wp-json') === -1) {
                        T.trackEvent('link_click', href, linkText);
                    }
                }
            } catch(e) {
                if (href.indexOf('admin-ajax') === -1) {
                    T.trackEvent('link_click', href, linkText);
                }
            }
        });
    };

    /**
     * Track search queries
     */
    T.bindSearchTracking = function() {
        var searchTimer = null;
        document.addEventListener('input', function(e) {
            var el = e.target;
            if (!el.matches('#mh-search-input, .mh-search-input, input[name="s"]')) return;

            var val = el.value.trim();
            if (val.length < 3) return;

            clearTimeout(searchTimer);
            searchTimer = setTimeout(function() {
                T.trackEvent('search', '', val);
            }, 2000);
        });
    };

    /**
     * Track filter changes
     */
    T.bindFilterTracking = function() {
        document.addEventListener('change', function(e) {
            var el = e.target;
            if (!el.matches('[data-filter], .mh-filter-select, select[name^="mh_"]')) return;

            var filterName = el.getAttribute('data-filter') || el.getAttribute('name') || 'unknown';
            var selected = el.options ? el.options[el.selectedIndex] : null;
            var filterValue = selected ? selected.textContent.trim() : el.value;
            if (filterValue) {
                T.trackEvent('filter_change', filterName, filterValue);
            }
        });

        // Quick filter buttons
        document.addEventListener('click', function(e) {
            var el = e.target.closest('.mh-quick-btn');
            if (el) {
                var filterName = el.getAttribute('data-filter') || 'quick_filter';
                var filterValue = (el.textContent || '').trim();
                T.trackEvent('filter_change', filterName, filterValue);
            }
        });
    };

    /**
     * Heartbeat - update duration every 30 seconds
     */
    T.startHeartbeat = function() {
        T.heartbeatInterval = setInterval(function() {
            T.updateDuration();
        }, 30000);
    };

    /**
     * Track page visibility changes
     */
    T.bindVisibility = function() {
        document.addEventListener('visibilitychange', function() {
            if (document.visibilityState === 'hidden') {
                T.updateDuration();
            }
        });

        window.addEventListener('beforeunload', function() {
            T.updateDuration();
        });
    };

    /**
     * Initialize all tracking
     */
    T.init = function() {
        console.log('[MicroHub Tracking] DOM ready, starting tracking...');
        // Record the page view first — this is the most important call
        T.recordPageView();
        T.bindTagClicks();
        T.bindLinkClicks();
        T.bindSearchTracking();
        T.bindFilterTracking();
        T.startHeartbeat();
        T.bindVisibility();
    };

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(T.init, 500);
        });
    } else {
        // DOM already ready
        setTimeout(T.init, 500);
    }

})();
