/**
 * MicroHub Visitor Tracking
 *
 * Tracks: page views, time on page, tag/filter clicks, link clicks, searches.
 * Privacy-friendly: no personal data collected, session-based only.
 *
 * Compatible with SiteGround page caching:
 * - Uses HMAC token (not WordPress nonces which expire in cached pages)
 * - Session ID generated client-side (server can't set cookies on cached pages)
 */
(function($) {
    'use strict';

    if (typeof mhTracking === 'undefined') return;

    var T = {
        ajaxurl: mhTracking.ajaxurl,
        token: mhTracking.token,
        postId: mhTracking.postId || 0,
        postType: mhTracking.postType || '',
        startTime: Date.now(),
        heartbeatInterval: null,
        pageUrl: window.location.pathname + window.location.search,
        sessionId: null
    };

    /**
     * Get or create session ID client-side (cache-safe — no server cookie needed)
     */
    T.getSessionId = function() {
        if (T.sessionId) return T.sessionId;

        // Try to read existing cookie
        var match = document.cookie.match(/(?:^|; )mh_sid=([^;]+)/);
        if (match) {
            T.sessionId = match[1];
            return T.sessionId;
        }

        // Generate a new session ID client-side
        var chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
        var sid = '';
        for (var i = 0; i < 32; i++) {
            sid += chars.charAt(Math.floor(Math.random() * chars.length));
        }

        // Set cookie (30 min expiry)
        var expires = new Date(Date.now() + 30 * 60 * 1000).toUTCString();
        document.cookie = 'mh_sid=' + sid + '; expires=' + expires + '; path=/; SameSite=Lax';

        T.sessionId = sid;
        return sid;
    };

    /**
     * Send a tracking event
     */
    T.trackEvent = function(eventType, eventTarget, eventValue) {
        var data = {
            action: 'mh_track_event',
            token: T.token,
            session_id: T.getSessionId(),
            event_type: eventType,
            event_target: eventTarget || '',
            event_value: eventValue || '',
            post_id: T.postId
        };

        // Use sendBeacon if available for reliability
        if (navigator.sendBeacon) {
            var formData = new FormData();
            for (var key in data) {
                formData.append(key, data[key]);
            }
            navigator.sendBeacon(T.ajaxurl, formData);
        } else {
            $.post(T.ajaxurl, data);
        }
    };

    /**
     * Send duration update
     */
    T.updateDuration = function() {
        var duration = Math.round((Date.now() - T.startTime) / 1000);
        if (duration < 1 || duration > 1800) return;

        var data = new FormData();
        data.append('action', 'mh_track_duration');
        data.append('token', T.token);
        data.append('session_id', T.getSessionId());
        data.append('duration', duration);
        data.append('page_url', T.pageUrl);

        if (navigator.sendBeacon) {
            navigator.sendBeacon(T.ajaxurl, data);
        } else {
            $.post(T.ajaxurl, {
                action: 'mh_track_duration',
                token: T.token,
                session_id: T.getSessionId(),
                duration: duration,
                page_url: T.pageUrl
            });
        }
    };

    /**
     * Track tag/taxonomy clicks
     */
    T.bindTagClicks = function() {
        $(document).on('click', [
            'a[href*="/mh_technique/"]',
            'a[href*="/mh_microscope/"]',
            'a[href*="/mh_organism/"]',
            'a[href*="/mh_software/"]',
            'a[href*="/mh_fluorophore/"]',
            'a[href*="/mh_cell_line/"]',
            'a[href*="/mh_sample_prep/"]',
            'a[href*="/mh_facility/"]',
            '.mh-tag',
            '.mh-taxonomy-tag',
            '.mh-technique-tag',
            '.mh-microscope-tag',
            '.mh-organism-tag',
            '.mh-filter-tag',
            '.tag-link'
        ].join(', '), function() {
            var tagText = $(this).text().trim();
            var href = $(this).attr('href') || '';
            T.trackEvent('tag_click', href, tagText);
        });
    };

    /**
     * Track link clicks (internal and outbound)
     */
    T.bindLinkClicks = function() {
        $(document).on('click', 'a[href]', function() {
            var href = $(this).attr('href');
            if (!href || href === '#' || href.indexOf('javascript:') === 0) return;

            var linkText = $(this).text().trim().substring(0, 100);
            var currentHost = window.location.hostname;

            try {
                var url = new URL(href, window.location.origin);
                if (url.hostname !== currentHost) {
                    T.trackEvent('outbound_link', href, linkText);
                } else {
                    if (href.indexOf('admin-ajax') === -1 && href.indexOf('wp-json') === -1) {
                        T.trackEvent('link_click', href, linkText);
                    }
                }
            } catch(e) {
                if (href.indexOf('admin-ajax') === -1) {
                    T.trackEvent('link_click', href, linkText);
                }
            }
        });
    };

    /**
     * Track search queries
     */
    T.bindSearchTracking = function() {
        var searchTimer = null;
        $(document).on('input', '#mh-search-input, .mh-search-input, input[name="s"]', function() {
            var val = $(this).val().trim();
            if (val.length < 3) return;

            clearTimeout(searchTimer);
            searchTimer = setTimeout(function() {
                T.trackEvent('search', '', val);
            }, 2000);
        });
    };

    /**
     * Track filter changes
     */
    T.bindFilterTracking = function() {
        $(document).on('change', '[data-filter], .mh-filter-select, select[name^="mh_"]', function() {
            var filterName = $(this).data('filter') || $(this).attr('name') || 'unknown';
            var filterValue = $(this).find('option:selected').text().trim() || $(this).val();
            if (filterValue) {
                T.trackEvent('filter_change', filterName, filterValue);
            }
        });

        $(document).on('click', '.mh-quick-btn', function() {
            var filterName = $(this).data('filter') || 'quick_filter';
            var filterValue = $(this).text().trim();
            T.trackEvent('filter_change', filterName, filterValue);
        });
    };

    /**
     * Heartbeat - update duration every 30 seconds
     */
    T.startHeartbeat = function() {
        T.heartbeatInterval = setInterval(function() {
            T.updateDuration();
        }, 30000);
    };

    /**
     * Track page visibility changes
     */
    T.bindVisibility = function() {
        document.addEventListener('visibilitychange', function() {
            if (document.visibilityState === 'hidden') {
                T.updateDuration();
            }
        });

        window.addEventListener('beforeunload', function() {
            T.updateDuration();
        });
    };

    /**
     * Initialize all tracking
     */
    T.init = function() {
        // Initialize session ID immediately
        T.getSessionId();

        T.bindTagClicks();
        T.bindLinkClicks();
        T.bindSearchTracking();
        T.bindFilterTracking();
        T.startHeartbeat();
        T.bindVisibility();
    };

    // Initialize when DOM is ready
    $(document).ready(function() {
        setTimeout(T.init, 500);
    });

})(jQuery);
