/**
 * MicroHub Visitor Tracking v3.11
 * Records page views and events via REST API.
 */
(function() {
    'use strict';

    if (typeof mhTracking === 'undefined') return;

    var sid = (function() {
        var m = document.cookie.match(/(?:^|; )mh_sid=([^;]+)/);
        if (m) return m[1];
        var c = 'abcdefghijklmnopqrstuvwxyz0123456789', s = '';
        for (var i = 0; i < 32; i++) s += c.charAt(Math.floor(Math.random() * c.length));
        document.cookie = 'mh_sid=' + s + '; expires=' + new Date(Date.now() + 30*60*1000).toUTCString() + '; path=/; SameSite=Lax';
        return s;
    })();

    var pageUrl = window.location.pathname + window.location.search;
    var startTime = Date.now();

    function post(endpoint, data) {
        data.session_id = sid;
        if (!mhTracking.restUrl) return;
        var xhr = new XMLHttpRequest();
        xhr.open('POST', mhTracking.restUrl + '/' + endpoint, true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify(data));
    }

    function trackEvent(type, target, value) {
        post('event', {
            event_type: type,
            event_target: target || '',
            event_value: value || '',
            post_id: mhTracking.postId || 0
        });
    }

    function updateDuration() {
        var dur = Math.round((Date.now() - startTime) / 1000);
        if (dur < 1 || dur > 1800) return;
        if (navigator.sendBeacon && mhTracking.restUrl) {
            navigator.sendBeacon(mhTracking.restUrl + '/duration',
                new Blob([JSON.stringify({ session_id: sid, duration: dur, page_url: pageUrl })],
                    { type: 'application/json' }));
        } else {
            post('duration', { duration: dur, page_url: pageUrl });
        }
    }

    function init() {
        // Record page view
        post('pageview', {
            page_url: pageUrl,
            page_title: document.title || '',
            post_id: mhTracking.postId || 0,
            post_type: mhTracking.postType || '',
            referrer: document.referrer || ''
        });

        // Outbound link clicks
        document.addEventListener('click', function(e) {
            var el = e.target.closest('a[href]');
            if (!el) return;
            var href = el.getAttribute('href');
            if (!href || href === '#') return;
            try {
                var url = new URL(href, window.location.origin);
                if (url.hostname !== window.location.hostname) {
                    trackEvent('outbound_link', href, (el.textContent || '').trim().substring(0, 100));
                }
            } catch(ex) {}
        });

        // Tag clicks
        document.addEventListener('click', function(e) {
            var el = e.target.closest('.mh-tag, .mh-taxonomy-tag, .tag-link');
            if (el) trackEvent('tag_click', el.getAttribute('href') || '', (el.textContent || '').trim());
        });

        // Search
        var searchTimer = null;
        document.addEventListener('input', function(e) {
            if (!e.target.matches('#mh-search-input, .mh-search-input, input[name="s"]')) return;
            var val = e.target.value.trim();
            if (val.length < 3) return;
            clearTimeout(searchTimer);
            searchTimer = setTimeout(function() { trackEvent('search', '', val); }, 2000);
        });

        // Duration tracking
        document.addEventListener('visibilitychange', function() {
            if (document.visibilityState === 'hidden') updateDuration();
        });
        window.addEventListener('beforeunload', updateDuration);
        setInterval(updateDuration, 30000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() { setTimeout(init, 300); });
    } else {
        setTimeout(init, 300);
    }
})();
