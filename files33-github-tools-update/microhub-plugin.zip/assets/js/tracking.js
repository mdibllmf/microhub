/**
 * MicroHub Visitor Tracking
 *
 * Tracks: page views, time on page, tag/filter clicks, link clicks, searches.
 * Privacy-friendly: no personal data collected, session-based only.
 *
 * IMPORTANT: This is vanilla JS — NO jQuery dependency.
 * jQuery was removed because SiteGround Speed Optimizer can reorder/combine
 * scripts, breaking the jQuery load order and silently killing all tracking.
 */
(function() {
    'use strict';

    if (typeof mhTracking === 'undefined') return;

    // Generate session ID client-side (server cookies don't work on cached pages)
    var sessionId = (function() {
        var match = document.cookie.match(/(?:^|; )mh_sid=([^;]+)/);
        if (match) return match[1];
        var chars = 'abcdefghijklmnopqrstuvwxyz0123456789', sid = '';
        for (var i = 0; i < 32; i++) sid += chars.charAt(Math.floor(Math.random() * chars.length));
        document.cookie = 'mh_sid=' + sid + '; expires=' + new Date(Date.now() + 30*60*1000).toUTCString() + '; path=/; SameSite=Lax';
        return sid;
    })();

    var T = {
        ajaxurl: mhTracking.ajaxurl || '/wp-admin/admin-ajax.php',
        token: mhTracking.token,
        sessionId: sessionId,
        postId: mhTracking.postId || 0,
        postType: mhTracking.postType || '',
        startTime: Date.now(),
        heartbeatInterval: null,
        pageUrl: window.location.pathname + window.location.search
    };

    /**
     * POST data to admin-ajax.php (vanilla JS, no jQuery needed)
     */
    T.post = function(data) {
        var formData = new FormData();
        for (var key in data) {
            if (data.hasOwnProperty(key)) {
                formData.append(key, data[key]);
            }
        }
        try {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', T.ajaxurl, true);
            xhr.send(formData);
        } catch(e) {
            // Silently fail — tracking should never break the site
        }
    };

    /**
     * Record page view via AJAX — this is the PRIMARY tracking mechanism.
     * The server-side wp_footer hook doesn't fire on cached pages,
     * so this client-side call is what actually records visits.
     */
    T.recordPageView = function() {
        T.post({
            action: 'mh_track_pageview',
            token: T.token,
            session_id: T.sessionId,
            page_url: T.pageUrl,
            page_title: document.title || '',
            post_id: T.postId,
            post_type: T.postType,
            referrer: document.referrer || ''
        });
    };

    /**
     * Send a tracking event
     */
    T.trackEvent = function(eventType, eventTarget, eventValue) {
        T.post({
            action: 'mh_track_event',
            token: T.token,
            session_id: T.sessionId,
            event_type: eventType,
            event_target: eventTarget || '',
            event_value: eventValue || '',
            post_id: T.postId
        });
    };

    /**
     * Send duration update
     */
    T.updateDuration = function() {
        var duration = Math.round((Date.now() - T.startTime) / 1000);
        if (duration < 1 || duration > 1800) return;

        // Use sendBeacon for reliability on page unload
        if (navigator.sendBeacon) {
            var data = new FormData();
            data.append('action', 'mh_track_duration');
            data.append('token', T.token);
            data.append('session_id', T.sessionId);
            data.append('duration', duration);
            data.append('page_url', T.pageUrl);
            navigator.sendBeacon(T.ajaxurl, data);
        } else {
            T.post({
                action: 'mh_track_duration',
                token: T.token,
                session_id: T.sessionId,
                duration: duration,
                page_url: T.pageUrl
            });
        }
    };

    /**
     * Track tag/taxonomy clicks
     */
    T.bindTagClicks = function() {
        var selectors = [
            'a[href*="/mh_technique/"]',
            'a[href*="/mh_microscope/"]',
            'a[href*="/mh_organism/"]',
            'a[href*="/mh_software/"]',
            'a[href*="/mh_fluorophore/"]',
            'a[href*="/mh_cell_line/"]',
            'a[href*="/mh_sample_prep/"]',
            'a[href*="/mh_facility/"]',
            '.mh-tag',
            '.mh-taxonomy-tag',
            '.mh-technique-tag',
            '.mh-microscope-tag',
            '.mh-organism-tag',
            '.mh-filter-tag',
            '.tag-link'
        ].join(', ');

        document.addEventListener('click', function(e) {
            var el = e.target.closest(selectors);
            if (el) {
                var tagText = (el.textContent || '').trim();
                var href = el.getAttribute('href') || '';
                T.trackEvent('tag_click', href, tagText);
            }
        });
    };

    /**
     * Track link clicks (internal and outbound)
     */
    T.bindLinkClicks = function() {
        document.addEventListener('click', function(e) {
            var el = e.target.closest('a[href]');
            if (!el) return;

            var href = el.getAttribute('href');
            if (!href || href === '#' || href.indexOf('javascript:') === 0) return;

            var linkText = (el.textContent || '').trim().substring(0, 100);
            var currentHost = window.location.hostname;

            try {
                var url = new URL(href, window.location.origin);
                if (url.hostname !== currentHost) {
                    T.trackEvent('outbound_link', href, linkText);
                } else {
                    if (href.indexOf('admin-ajax') === -1 && href.indexOf('wp-json') === -1) {
                        T.trackEvent('link_click', href, linkText);
                    }
                }
            } catch(e) {
                if (href.indexOf('admin-ajax') === -1) {
                    T.trackEvent('link_click', href, linkText);
                }
            }
        });
    };

    /**
     * Track search queries
     */
    T.bindSearchTracking = function() {
        var searchTimer = null;
        document.addEventListener('input', function(e) {
            var el = e.target;
            if (!el.matches('#mh-search-input, .mh-search-input, input[name="s"]')) return;

            var val = el.value.trim();
            if (val.length < 3) return;

            clearTimeout(searchTimer);
            searchTimer = setTimeout(function() {
                T.trackEvent('search', '', val);
            }, 2000);
        });
    };

    /**
     * Track filter changes
     */
    T.bindFilterTracking = function() {
        document.addEventListener('change', function(e) {
            var el = e.target;
            if (!el.matches('[data-filter], .mh-filter-select, select[name^="mh_"]')) return;

            var filterName = el.getAttribute('data-filter') || el.getAttribute('name') || 'unknown';
            var selected = el.options ? el.options[el.selectedIndex] : null;
            var filterValue = selected ? selected.textContent.trim() : el.value;
            if (filterValue) {
                T.trackEvent('filter_change', filterName, filterValue);
            }
        });

        // Quick filter buttons
        document.addEventListener('click', function(e) {
            var el = e.target.closest('.mh-quick-btn');
            if (el) {
                var filterName = el.getAttribute('data-filter') || 'quick_filter';
                var filterValue = (el.textContent || '').trim();
                T.trackEvent('filter_change', filterName, filterValue);
            }
        });
    };

    /**
     * Heartbeat - update duration every 30 seconds
     */
    T.startHeartbeat = function() {
        T.heartbeatInterval = setInterval(function() {
            T.updateDuration();
        }, 30000);
    };

    /**
     * Track page visibility changes
     */
    T.bindVisibility = function() {
        document.addEventListener('visibilitychange', function() {
            if (document.visibilityState === 'hidden') {
                T.updateDuration();
            }
        });

        window.addEventListener('beforeunload', function() {
            T.updateDuration();
        });
    };

    /**
     * Initialize all tracking
     */
    T.init = function() {
        // Record the page view first — this is the most important call
        T.recordPageView();
        T.bindTagClicks();
        T.bindLinkClicks();
        T.bindSearchTracking();
        T.bindFilterTracking();
        T.startHeartbeat();
        T.bindVisibility();
    };

    // Initialize when DOM is ready (no jQuery needed)
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(T.init, 500);
        });
    } else {
        // DOM already ready
        setTimeout(T.init, 500);
    }

})();
