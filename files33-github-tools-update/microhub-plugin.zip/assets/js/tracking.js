/**
 * MicroHub Visitor Tracking (Client-side)
 *
 * Tracks: time on page, tag/filter clicks, link clicks, searches.
 * Privacy-friendly: no personal data collected, session-based only.
 *
 * Page view recording uses a hybrid approach:
 * - Server-side (wp_footer): PHP records the view and sets window.mhPageViewRecorded = true
 * - Client-side (this script): If mhPageViewRecorded is NOT set (cached page), sends AJAX fallback
 * This ensures tracking works whether the page is served fresh or from cache.
 */
(function($) {
    'use strict';

    if (typeof mhTracking === 'undefined') return;

    var T = {
        ajaxurl: mhTracking.ajaxurl,
        nonce: mhTracking.nonce,
        sessionId: mhTracking.sessionId,
        postId: mhTracking.postId || 0,
        postType: mhTracking.postType || '',
        startTime: Date.now(),
        heartbeatInterval: null,
        pageUrl: window.location.pathname + window.location.search
    };

    /**
     * Ensure we have a valid session ID (generate one client-side if
     * the server-side value is missing, e.g. from a cached page)
     */
    T.ensureSessionId = function() {
        if (T.sessionId && T.sessionId.length === 32) return;

        var match = document.cookie.match(/(?:^|;\s*)mh_sid=([a-zA-Z0-9]{32})/);
        if (match) {
            T.sessionId = match[1];
            return;
        }

        var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        var sid = '';
        for (var i = 0; i < 32; i++) {
            sid += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        T.sessionId = sid;

        var expires = new Date(Date.now() + 1800000).toUTCString();
        document.cookie = 'mh_sid=' + sid + '; path=/; expires=' + expires + '; SameSite=Lax';
    };

    /**
     * Send a tracking AJAX request
     */
    T.sendRequest = function(data) {
        data.nonce = T.nonce;
        data.session_id = T.sessionId;
        $.post(T.ajaxurl, data);
    };

    /**
     * Record page view via AJAX (only if server-side didn't already record it).
     * On non-cached pages, wp_footer sets window.mhPageViewRecorded = true.
     * On cached pages, that PHP never executes, so the flag is absent.
     */
    T.recordPageViewIfNeeded = function() {
        if (window.mhPageViewRecorded) return; // server already recorded it

        T.sendRequest({
            action: 'mh_record_view',
            page_url: T.pageUrl,
            page_title: document.title || '',
            post_id: T.postId,
            post_type: T.postType,
            referrer: document.referrer || ''
        });
    };

    /**
     * Send a tracking event
     */
    T.trackEvent = function(eventType, eventTarget, eventValue) {
        T.sendRequest({
            action: 'mh_track_event',
            event_type: eventType,
            event_target: eventTarget || '',
            event_value: eventValue || '',
            post_id: T.postId
        });
    };

    /**
     * Send duration update
     */
    T.updateDuration = function() {
        var duration = Math.round((Date.now() - T.startTime) / 1000);
        if (duration < 1 || duration > 1800) return;

        var data = {
            action: 'mh_track_duration',
            nonce: T.nonce,
            session_id: T.sessionId,
            duration: duration,
            page_url: T.pageUrl
        };

        if (navigator.sendBeacon) {
            var formData = new FormData();
            for (var key in data) {
                formData.append(key, data[key]);
            }
            navigator.sendBeacon(T.ajaxurl, formData);
        } else {
            $.post(T.ajaxurl, data);
        }
    };

    /**
     * Track tag/taxonomy clicks
     */
    T.bindTagClicks = function() {
        $(document).on('click', [
            'a[href*="/mh_technique/"]',
            'a[href*="/mh_microscope/"]',
            'a[href*="/mh_organism/"]',
            'a[href*="/mh_software/"]',
            'a[href*="/mh_fluorophore/"]',
            'a[href*="/mh_cell_line/"]',
            'a[href*="/mh_sample_prep/"]',
            'a[href*="/mh_facility/"]',
            '.mh-tag',
            '.mh-taxonomy-tag',
            '.mh-technique-tag',
            '.mh-microscope-tag',
            '.mh-organism-tag',
            '.mh-filter-tag',
            '.tag-link'
        ].join(', '), function() {
            var tagText = $(this).text().trim();
            var href = $(this).attr('href') || '';
            T.trackEvent('tag_click', href, tagText);
        });
    };

    /**
     * Track link clicks (internal and outbound)
     */
    T.bindLinkClicks = function() {
        $(document).on('click', 'a[href]', function() {
            var href = $(this).attr('href');
            if (!href || href === '#' || href.indexOf('javascript:') === 0) return;

            var linkText = $(this).text().trim().substring(0, 100);
            var currentHost = window.location.hostname;

            try {
                var url = new URL(href, window.location.origin);
                if (url.hostname !== currentHost) {
                    T.trackEvent('outbound_link', href, linkText);
                } else {
                    if (href.indexOf('admin-ajax') === -1 && href.indexOf('wp-json') === -1) {
                        T.trackEvent('link_click', href, linkText);
                    }
                }
            } catch(e) {
                if (href.indexOf('admin-ajax') === -1) {
                    T.trackEvent('link_click', href, linkText);
                }
            }
        });
    };

    /**
     * Track search queries
     */
    T.bindSearchTracking = function() {
        var searchTimer = null;
        $(document).on('input', '#mh-search-input, .mh-search-input, input[name="s"]', function() {
            var val = $(this).val().trim();
            if (val.length < 3) return;

            clearTimeout(searchTimer);
            searchTimer = setTimeout(function() {
                T.trackEvent('search', '', val);
            }, 2000);
        });
    };

    /**
     * Track filter changes
     */
    T.bindFilterTracking = function() {
        $(document).on('change', '[data-filter], .mh-filter-select, select[name^="mh_"]', function() {
            var filterName = $(this).data('filter') || $(this).attr('name') || 'unknown';
            var filterValue = $(this).find('option:selected').text().trim() || $(this).val();
            if (filterValue) {
                T.trackEvent('filter_change', filterName, filterValue);
            }
        });

        $(document).on('click', '.mh-quick-btn', function() {
            var filterName = $(this).data('filter') || 'quick_filter';
            var filterValue = $(this).text().trim();
            T.trackEvent('filter_change', filterName, filterValue);
        });
    };

    /**
     * Heartbeat - update duration every 30 seconds
     */
    T.startHeartbeat = function() {
        T.heartbeatInterval = setInterval(function() {
            T.updateDuration();
        }, 30000);
    };

    /**
     * Track page visibility changes
     */
    T.bindVisibility = function() {
        document.addEventListener('visibilitychange', function() {
            if (document.visibilityState === 'hidden') {
                T.updateDuration();
            }
        });

        window.addEventListener('beforeunload', function() {
            T.updateDuration();
        });
    };

    /**
     * Initialize all tracking
     */
    T.init = function() {
        T.ensureSessionId();
        T.recordPageViewIfNeeded(); // AJAX fallback for cached pages
        T.bindTagClicks();
        T.bindLinkClicks();
        T.bindSearchTracking();
        T.bindFilterTracking();
        T.startHeartbeat();
        T.bindVisibility();
    };

    $(document).ready(function() {
        setTimeout(T.init, 500);
    });

})(jQuery);
