/**
 * MicroHub Visitor Tracking v3.12.2
 *
 * Records: page views, session duration, filter changes, tab clicks,
 *          tag clicks, outbound links, search queries.
 *
 * No jQuery. REST API primary (with WP nonce), admin-ajax.php fallback.
 */
(function () {
    'use strict';
    if (typeof mhTracking === 'undefined') {
        console.warn('[MH Tracking] mhTracking config not found — script localisation failed.');
        return;
    }
    console.log('[MH Tracking] Loaded. REST base:', mhTracking.restBase, '| AJAX:', mhTracking.ajaxurl, '| Nonce:', mhTracking.nonce ? 'yes' : 'MISSING');
    // -------------------------------------------------------------------------
    // Session ID — 30-minute rolling cookie
    // -------------------------------------------------------------------------
    var sid = (function () {
        var m = document.cookie.match(/(?:^|; )mh_sid=([^;]+)/);
        if (m) return m[1];
        var c = 'abcdefghijklmnopqrstuvwxyz0123456789', s = '';
        for (var i = 0; i < 32; i++) s += c[Math.floor(Math.random() * c.length)];
        var exp = new Date(Date.now() + 30 * 60 * 1000).toUTCString();
        document.cookie = 'mh_sid=' + s + '; expires=' + exp + '; path=/; SameSite=Lax';
        return s;
    })();
    var pageUrl   = window.location.pathname + window.location.search;
    var startTime = Date.now();
    // -------------------------------------------------------------------------
    // HTTP helpers
    // -------------------------------------------------------------------------
    /**
     * POST JSON to REST endpoint (with X-WP-Nonce); fall back to admin-ajax on failure.
     */
    function post(restPath, ajaxAction, data) {
        data.session_id = sid;
        var url = mhTracking.restBase + restPath;
        _xhrJson(url, data, function (ok, status, body) {
            if (ok) {
                console.log('[MH] REST ' + restPath + ' OK');
            } else {
                console.warn('[MH] REST ' + restPath + ' failed (' + status + ': ' + body.substring(0, 200) + ') — trying admin-ajax');
                _xhrAjax(ajaxAction, data);
            }
        });
    }
    function _xhrJson(url, data, cb) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        // Send WP nonce — required by many hosts (SiteGround, etc.) to allow REST POSTs
        if (mhTracking.nonce) {
            xhr.setRequestHeader('X-WP-Nonce', mhTracking.nonce);
        }
        xhr.timeout = 8000;
        xhr.ontimeout = function () { console.warn('[MH] REST timeout'); if (cb) cb(false, 0, 'timeout'); };
        xhr.onerror   = function () { console.warn('[MH] REST network error'); if (cb) cb(false, 0, 'network error'); };
        xhr.onload    = function () {
            var ok = false;
            try { ok = !!JSON.parse(xhr.responseText).success; } catch (e) {}
            if (cb) cb(ok, xhr.status, xhr.responseText || '');
        };
        xhr.send(JSON.stringify(data));
    }
    function _xhrAjax(action, data) {
        var fd = new FormData();
        fd.append('action', action);
        for (var k in data) {
            if (Object.prototype.hasOwnProperty.call(data, k)) fd.append(k, data[k]);
        }
        var xhr = new XMLHttpRequest();
        xhr.open('POST', mhTracking.ajaxurl, true);
        xhr.timeout = 8000;
        xhr.onload = function () {
            try {
                var r = JSON.parse(xhr.responseText);
                if (r.success) {
                    console.log('[MH] AJAX ' + action + ' OK');
                } else {
                    console.error('[MH] AJAX ' + action + ' failed:', xhr.responseText.substring(0, 200));
                }
            } catch (e) {
                console.error('[MH] AJAX ' + action + ' non-JSON response (' + xhr.status + '):', xhr.responseText.substring(0, 200));
            }
        };
        xhr.onerror = function () { console.error('[MH] AJAX ' + action + ' network error'); };
        xhr.ontimeout = function () { console.error('[MH] AJAX ' + action + ' timeout'); };
        xhr.send(fd);
    }
    // -------------------------------------------------------------------------
    // Tracking functions
    // -------------------------------------------------------------------------
    function trackPageView() {
        console.log('[MH] Sending pageview:', pageUrl);
        post('/track/pageview', 'mh_track_pageview', {
            page_url:   pageUrl,
            page_title: document.title || '',
            post_id:    mhTracking.postId   || 0,
            post_type:  mhTracking.postType || '',
            referrer:   document.referrer   || '',
        });
    }
    function trackEvent(type, target, value) {
        post('/track/event', 'mh_track_event', {
            event_type:   type,
            event_target: (target || '').substring(0, 500),
            event_value:  (value  || '').substring(0, 255),
            post_id:      mhTracking.postId || 0,
        });
    }
    function sendDuration() {
        var dur = Math.round((Date.now() - startTime) / 1000);
        if (dur < 2 || dur > 3600) return;
        var payload = JSON.stringify({ session_id: sid, duration: dur, page_url: pageUrl });
        // sendBeacon is most reliable on page-unload
        if (navigator.sendBeacon && mhTracking.restBase) {
            var blob = new Blob([payload], { type: 'application/json' });
            var sent = navigator.sendBeacon(mhTracking.restBase + '/track/duration', blob);
            if (sent) return;
        }
        // Fallback: synchronous-ish XHR (best effort)
        _xhrJson(mhTracking.restBase + '/track/duration', JSON.parse(payload), null);
    }
    // -------------------------------------------------------------------------
    // Event bindings
    // -------------------------------------------------------------------------
    function bindEvents() {
        // -- Unified click handler (tag clicks + outbound links) ---------------
        document.addEventListener('click', function (e) {
            var link = e.target.closest('a[href]');
            if (!link) return;
            var href = link.getAttribute('href') || '';
            if (!href || href === '#' || href.indexOf('javascript') === 0) return;
            // Tag / taxonomy link?
            var tagEl = e.target.closest(
                'a[href*="/mh_technique/"], a[href*="/mh_microscope/"], ' +
                'a[href*="/mh_organism/"], a[href*="/mh_software/"], ' +
                'a[href*="/mh_fluorophore/"], a[href*="/mh_cell_line/"], ' +
                '.mh-tag, .mh-taxonomy-tag, .tag-link'
            );
            if (tagEl) {
                trackEvent('tag_click', tagEl.getAttribute('href') || '', (tagEl.textContent || '').trim());
                return;
            }
            // Outbound link?
            try {
                var parsed = new URL(href, window.location.origin);
                if (parsed.hostname !== window.location.hostname) {
                    trackEvent('outbound_link', href, (link.textContent || '').trim().substring(0, 100));
                }
            } catch (err) { /* malformed URL */ }
        });
        // -- Filter dropdowns ([data-filter] selects) -------------------------
        document.addEventListener('change', function (e) {
            var el = e.target.closest('[data-filter]');
            if (el && el.value) {
                trackEvent('filter_change', el.getAttribute('data-filter') || el.name || 'filter', el.value);
                return;
            }
            // Sort dropdown
            var sort = e.target.closest('#mh-sort, [name="orderby"]');
            if (sort && sort.value) {
                trackEvent('filter_change', 'sort', sort.value);
            }
        });
        // -- Quick-filter buttons (.mh-quick-btn) -----------------------------
        document.addEventListener('click', function (e) {
            var btn = e.target.closest('.mh-quick-btn');
            if (!btn) return;
            var filter = btn.getAttribute('data-filter') || '';
            var label  = (btn.textContent || btn.innerText || '').trim();
            trackEvent('filter_change', 'quick:' + filter, label);
        });
        // -- Tab / section navigation -----------------------------------------
        document.addEventListener('click', function (e) {
            var tab = e.target.closest(
                '.mh-tab, .mh-tab-btn, [data-tab], ' +
                '.mh-section-toggle, .mh-collapse-btn, .mh-expand-btn, ' +
                '.mh-nav-tab, [role="tab"]'
            );
            if (!tab) return;
            var id    = tab.getAttribute('data-tab') || tab.getAttribute('href') || tab.id || '';
            var label = (tab.textContent || tab.innerText || '').trim().substring(0, 80);
            trackEvent('tab_click', id, label);
        });
        // -- Search input (debounced 2s) ---------------------------------------
        var searchTimer = null;
        document.addEventListener('input', function (e) {
            var el = e.target.closest('#mh-search-input, .mh-search-input, input[name="s"]');
            if (!el) return;
            var val = (el.value || '').trim();
            if (val.length < 3) return;
            clearTimeout(searchTimer);
            searchTimer = setTimeout(function () { trackEvent('search', '', val); }, 2000);
        });
        // -- Duration: on visibility change + beforeunload --------------------
        document.addEventListener('visibilitychange', function () {
            if (document.visibilityState === 'hidden') sendDuration();
        });
        window.addEventListener('beforeunload', sendDuration);
        // -- Heartbeat: every 60s, only while tab is visible ------------------
        setInterval(function () {
            if (document.visibilityState !== 'hidden') sendDuration();
        }, 60000);
    }
    // -------------------------------------------------------------------------
    // Init
    // -------------------------------------------------------------------------
    function init() {
        console.log('[MH Tracking] Init — recording pageview for', pageUrl);
        trackPageView();
        bindEvents();
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { setTimeout(init, 200); });
    } else {
        setTimeout(init, 200);
    }
})();
