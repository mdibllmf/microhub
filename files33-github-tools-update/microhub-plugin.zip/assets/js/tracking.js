/**
 * MicroHub Visitor Tracking v3.10
 *
 * Stripped-down version: no token auth, no jQuery, REST API primary.
 * Just records page views and events, nothing else.
 */
(function() {
    'use strict';

    if (typeof mhTracking === 'undefined') {
        console.error('[MH] FATAL: mhTracking variable not found. Script localization failed.');
        return;
    }

    console.log('[MH] Tracking init', mhTracking.restUrl || mhTracking.ajaxurl);

    var sid = (function() {
        var m = document.cookie.match(/(?:^|; )mh_sid=([^;]+)/);
        if (m) return m[1];
        var c = 'abcdefghijklmnopqrstuvwxyz0123456789', s = '';
        for (var i = 0; i < 32; i++) s += c.charAt(Math.floor(Math.random() * c.length));
        document.cookie = 'mh_sid=' + s + '; expires=' + new Date(Date.now() + 30*60*1000).toUTCString() + '; path=/; SameSite=Lax';
        return s;
    })();

    var pageUrl = window.location.pathname + window.location.search;
    var startTime = Date.now();

    // Simple POST helper — tries REST, falls back to AJAX
    function post(endpoint, ajaxAction, data, cb) {
        data.session_id = sid;

        // Try REST API first
        if (mhTracking.restUrl) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', mhTracking.restUrl + '/' + endpoint, true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.onload = function() {
                var ok = false;
                try { ok = JSON.parse(xhr.responseText).success; } catch(e) {}
                if (ok) {
                    console.log('[MH] OK via REST:', endpoint);
                    if (cb) cb(true);
                } else {
                    console.warn('[MH] REST failed (' + xhr.status + '):', xhr.responseText.substring(0, 150));
                    // Fallback to admin-ajax
                    postAjax(ajaxAction, data, cb);
                }
            };
            xhr.onerror = function() {
                console.warn('[MH] REST network error, trying admin-ajax');
                postAjax(ajaxAction, data, cb);
            };
            xhr.send(JSON.stringify(data));
            return;
        }

        // No REST URL — go straight to admin-ajax
        postAjax(ajaxAction, data, cb);
    }

    function postAjax(action, data, cb) {
        var fd = new FormData();
        fd.append('action', action);
        for (var k in data) {
            if (data.hasOwnProperty(k)) fd.append(k, data[k]);
        }
        var xhr = new XMLHttpRequest();
        xhr.open('POST', mhTracking.ajaxurl, true);
        xhr.onload = function() {
            var ok = false;
            try { ok = JSON.parse(xhr.responseText).success; } catch(e) {}
            if (ok) {
                console.log('[MH] OK via AJAX:', action);
            } else {
                console.error('[MH] AJAX FAILED (' + xhr.status + '):', xhr.responseText.substring(0, 150));
            }
            if (cb) cb(ok);
        };
        xhr.onerror = function() {
            console.error('[MH] AJAX network error:', action);
            if (cb) cb(false);
        };
        xhr.send(fd);
    }

    // Record page view
    function recordPageView() {
        console.log('[MH] Recording page view:', pageUrl);
        post('pageview', 'mh_track_pageview', {
            page_url: pageUrl,
            page_title: document.title || '',
            post_id: mhTracking.postId || 0,
            post_type: mhTracking.postType || '',
            referrer: document.referrer || ''
        }, function(ok) {
            if (ok) console.log('[MH] Page view RECORDED');
            else console.error('[MH] Page view FAILED — both REST and AJAX failed');
        });
    }

    function trackEvent(type, target, value) {
        post('event', 'mh_track_event', {
            event_type: type,
            event_target: target || '',
            event_value: value || '',
            post_id: mhTracking.postId || 0
        });
    }

    function updateDuration() {
        var dur = Math.round((Date.now() - startTime) / 1000);
        if (dur < 1 || dur > 1800) return;
        if (navigator.sendBeacon && mhTracking.restUrl) {
            var blob = new Blob([JSON.stringify({
                session_id: sid, duration: dur, page_url: pageUrl
            })], {type: 'application/json'});
            navigator.sendBeacon(mhTracking.restUrl + '/duration', blob);
        } else {
            post('duration', 'mh_track_duration', { duration: dur, page_url: pageUrl });
        }
    }

    // Event bindings
    function bindEvents() {
        // Tag clicks
        document.addEventListener('click', function(e) {
            var el = e.target.closest('a[href*="/mh_technique/"], a[href*="/mh_microscope/"], a[href*="/mh_organism/"], .mh-tag, .mh-taxonomy-tag, .tag-link');
            if (el) trackEvent('tag_click', el.getAttribute('href') || '', (el.textContent || '').trim());
        });

        // Link clicks
        document.addEventListener('click', function(e) {
            var el = e.target.closest('a[href]');
            if (!el) return;
            var href = el.getAttribute('href');
            if (!href || href === '#') return;
            try {
                var url = new URL(href, window.location.origin);
                if (url.hostname !== window.location.hostname) {
                    trackEvent('outbound_link', href, (el.textContent || '').trim().substring(0, 100));
                }
            } catch(e) {}
        });

        // Search
        var searchTimer = null;
        document.addEventListener('input', function(e) {
            if (!e.target.matches('#mh-search-input, .mh-search-input, input[name="s"]')) return;
            var val = e.target.value.trim();
            if (val.length < 3) return;
            clearTimeout(searchTimer);
            searchTimer = setTimeout(function() { trackEvent('search', '', val); }, 2000);
        });

        // Duration on leave
        document.addEventListener('visibilitychange', function() {
            if (document.visibilityState === 'hidden') updateDuration();
        });
        window.addEventListener('beforeunload', updateDuration);

        // Heartbeat every 30s
        setInterval(updateDuration, 30000);
    }

    // Start
    function init() {
        console.log('[MH] DOM ready, firing page view');
        recordPageView();
        bindEvents();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() { setTimeout(init, 300); });
    } else {
        setTimeout(init, 300);
    }
})();
