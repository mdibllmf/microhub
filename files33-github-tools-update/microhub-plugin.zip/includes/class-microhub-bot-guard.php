<?php
/**
 * MicroHub Bot Guard
 *
 * Lightweight bot detection for frontend page requests only.
 * Does NOT interfere with REST API, AJAX, cron, or other plugins.
 * Only blocks obviously malicious bots on frontend page loads.
 */

if (!defined('ABSPATH')) exit;

class MicroHub_Bot_Guard {

    /** Known bad bot user-agent patterns */
    private static $bot_patterns = array(
        'scrapy', 'phantomjs', 'headlesschrome', 'selenium',
        'puppeteer', 'playwright', 'mechanize',
        'zgrab', 'masscan', 'nikto', 'sqlmap', 'nmap',
        'dirbuster', 'gobuster', 'wpscan', 'nuclei',
        'semrush', 'ahrefs', 'mj12bot', 'dotbot', 'petalbot',
        'bytespider', 'dataforseo', 'claudebot', 'gptbot',
        'ccbot', 'baiduspider',
        'megaindex', 'blexbot', 'seokicks', 'serpstatbot',
        'zoominfobot', 'seekport', 'pandalytics', 'webmeup',
        'ltx71', 'netsystemsresearch', 'netcraft',
        'cocolyze', 'webdatastats',
        'meta-externalagent', 'applebot-extended',
    );

    /** Allowed bots — never block these */
    private static $allowed_bots = array(
        'googlebot', 'bingbot', 'duckduckbot', 'facebot',
        'twitterbot', 'linkedinbot', 'slackbot', 'whatsapp',
        'telegrambot', 'applebot', 'yandexbot',
        'facebookexternalhit', 'archive.org_bot',
        'uptimerobot', 'amazonbot',
    );

    /** Rate limit: max requests per IP per minute */
    const RATE_LIMIT = 60;
    const RATE_WINDOW = 60;

    public function init() {
        // Only check frontend page requests — NOT REST API, NOT AJAX
        add_action('template_redirect', array($this, 'check_request'), 1);

        // Honeypot trap in footer
        add_action('wp_footer', array($this, 'render_honeypot'));
        add_action('wp_ajax_mh_hp_check', array($this, 'honeypot_triggered'));
        add_action('wp_ajax_nopriv_mh_hp_check', array($this, 'honeypot_triggered'));
    }

    /**
     * Check if a user-agent is a known bad bot (for blocking)
     */
    public static function is_bot_ua($ua) {
        if (empty($ua)) return true;

        $ua_lower = strtolower($ua);

        // Never block allowed bots
        foreach (self::$allowed_bots as $good) {
            if (strpos($ua_lower, $good) !== false) {
                return false;
            }
        }

        // Check against known bad patterns
        foreach (self::$bot_patterns as $pattern) {
            if (strpos($ua_lower, $pattern) !== false) {
                return true;
            }
        }

        // Check for common bot indicators
        $generic_bot = array('bot', 'crawl', 'spider', 'slurp', 'fetch',
            'curl', 'wget', 'python-requests', 'python-urllib', 'httpx',
            'go-http-client', 'java/', 'libwww', 'httpclient', 'aiohttp');
        foreach ($generic_bot as $b) {
            if (strpos($ua_lower, $b) !== false) {
                return true;
            }
        }

        // No browser engine = not a real browser
        $browser_markers = array('mozilla', 'chrome', 'safari', 'firefox', 'edge', 'opera');
        foreach ($browser_markers as $marker) {
            if (strpos($ua_lower, $marker) !== false) {
                return false; // Has browser marker, not a bot
            }
        }

        return true; // No browser marker found
    }

    /**
     * Frontend request check — only runs on template_redirect
     * Skips admin pages, AJAX, cron, REST API, and logged-in admins
     */
    public function check_request() {
        // Skip everything except frontend page loads
        if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
            return;
        }

        // Never block logged-in users
        if (is_user_logged_in()) {
            return;
        }

        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        $ip = $this->get_visitor_ip();

        // Check if IP was previously blocked by honeypot
        $ip_hash = $this->hash_ip($ip);
        if (get_transient('mh_blocked_' . substr($ip_hash, 0, 16))) {
            $this->log_block($ip, $ua, 'honeypot_repeat');
            $this->soft_block();
            return;
        }

        // Only block requests with known bad bot user agents
        if (!empty($ua) && self::is_bot_ua($ua)) {
            $this->log_block($ip, $ua, 'bad_ua');
            $this->soft_block();
            return;
        }

        // Check for obvious attack patterns in URL
        if ($this->has_suspicious_patterns()) {
            $this->log_block($ip, $ua, 'suspicious_pattern');
            $this->soft_block();
            return;
        }

        // Rate limiting (generous: 60 req/min)
        if ($this->is_rate_limited($ip)) {
            $this->log_block($ip, $ua, 'rate_limit');
            $this->rate_limit_response();
            return;
        }
    }

    private function is_rate_limited($ip) {
        $ip_hash = $this->hash_ip($ip);
        $transient_key = 'mh_rl_' . substr($ip_hash, 0, 16);

        $data = get_transient($transient_key);
        if ($data === false) {
            set_transient($transient_key, array('count' => 1, 'start' => time()), self::RATE_WINDOW);
            return false;
        }

        $data['count']++;
        set_transient($transient_key, $data, self::RATE_WINDOW);
        return $data['count'] > self::RATE_LIMIT;
    }

    private function has_suspicious_patterns() {
        $uri = isset($_SERVER['REQUEST_URI']) ? strtolower($_SERVER['REQUEST_URI']) : '';
        $bad = array('wp-config', '.env', '.git/', 'eval(', 'base64_decode',
            'union+select', 'union%20select', '../', '%00', '<script',
            'wp-admin/install.php', 'wp-admin/setup-config.php');
        foreach ($bad as $pattern) {
            if (strpos($uri, $pattern) !== false) return true;
        }
        return false;
    }

    private function soft_block() {
        status_header(403);
        nocache_headers();
        echo '<!DOCTYPE html><html><head><title>Access Denied</title></head><body><h1>403 Forbidden</h1></body></html>';
        exit;
    }

    private function rate_limit_response() {
        status_header(429);
        nocache_headers();
        header('Retry-After: 60');
        echo '<!DOCTYPE html><html><head><title>Too Many Requests</title></head><body><h1>429 Too Many Requests</h1><p>Please slow down.</p></body></html>';
        exit;
    }

    public function render_honeypot() {
        if (is_admin()) return;
        ?>
        <div aria-hidden="true" style="position:absolute;left:-9999px;top:-9999px;width:1px;height:1px;overflow:hidden;">
            <a href="#" id="mh-hp-link" tabindex="-1">Site resources</a>
            <form id="mh-hp-form" method="post" action="<?php echo esc_url(admin_url('admin-ajax.php')); ?>">
                <input type="hidden" name="action" value="mh_hp_check" />
                <input type="text" name="mh_hp_field" id="mh-hp-field" tabindex="-1" autocomplete="off" />
            </form>
        </div>
        <?php
    }

    public function honeypot_triggered() {
        $ip = $this->get_visitor_ip();
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        $this->log_block($ip, $ua, 'honeypot');
        $ip_hash = $this->hash_ip($ip);
        set_transient('mh_blocked_' . substr($ip_hash, 0, 16), true, HOUR_IN_SECONDS);
        wp_send_json_error('Blocked', 403);
    }

    private function log_block($ip, $ua, $reason) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_bot_blocks';
        // Silently skip if table doesn't exist
        $exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
        if ($exists !== $table) return;
        $wpdb->insert($table, array(
            'ip_hash'    => $this->hash_ip($ip),
            'user_agent' => substr(sanitize_text_field($ua), 0, 500),
            'reason'     => $reason,
            'page_url'   => substr(esc_url_raw(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : ''), 0, 500),
        ), array('%s', '%s', '%s', '%s'));
    }

    private function hash_ip($ip) {
        $salt = defined('AUTH_SALT') ? AUTH_SALT : 'mh_default_salt';
        return hash('sha256', $ip . $salt . date('Y-m'));
    }

    private function get_visitor_ip() {
        $headers = array('HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR');
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        return '0.0.0.0';
    }
}
