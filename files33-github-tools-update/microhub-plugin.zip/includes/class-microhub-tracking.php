<?php
/**
 * MicroHub Visitor Tracking v3.12.1
 *
 * Complete rewrite. Custom DB tables only. Zero bot blocking.
 * Records page views, session duration, and interaction events.
 * Privacy-friendly: IPs are hashed, no personal data stored.
 *
 * Storage: custom tables (mh_page_views, mh_tracking_events)
 * Endpoints: REST API (primary) + admin-ajax.php (fallback)
 */
if ( ! defined( 'ABSPATH' ) ) exit;
class MicroHub_Tracking {
    /**
     * Boot hooks.
     */
    public function init() {
        // Ensure tables exist (lightweight check, result cached in object cache)
        add_action( 'init', array( $this, 'maybe_create_tables' ), 5 );
        // REST endpoints
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
        // AJAX fallback endpoints
        add_action( 'wp_ajax_mh_track_pageview',  array( $this, 'ajax_track_pageview' ) );
        add_action( 'wp_ajax_nopriv_mh_track_pageview', array( $this, 'ajax_track_pageview' ) );
        add_action( 'wp_ajax_mh_track_event',     array( $this, 'ajax_track_event' ) );
        add_action( 'wp_ajax_nopriv_mh_track_event',   array( $this, 'ajax_track_event' ) );
        add_action( 'wp_ajax_mh_track_duration',  array( $this, 'ajax_track_duration' ) );
        add_action( 'wp_ajax_nopriv_mh_track_duration', array( $this, 'ajax_track_duration' ) );
        // Enqueue tracking script on MicroHub pages only
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_tracking_script' ) );
        // Daily cleanup (cron job registered in activation hook)
        add_action( 'mh_tracking_cleanup', array( $this, 'cleanup_old_data' ) );
    }
    // =========================================================================
    // Table creation
    // =========================================================================
    /**
     * Create tracking tables if they don't exist yet.
     * Uses a lightweight transient so the SHOW TABLES query only runs once per hour.
     */
    public function maybe_create_tables() {
        if ( get_transient( 'mh_tables_verified' ) ) {
            return;
        }
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
            $this->create_tables();
        }
        set_transient( 'mh_tables_verified', 1, HOUR_IN_SECONDS );
    }
    /**
     * Create all three tracking tables. Called from activation hook and on-demand.
     */
    public static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}mh_page_views (
            id            bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_id    varchar(64)         NOT NULL DEFAULT '',
            page_url      varchar(500)        NOT NULL DEFAULT '',
            page_title    varchar(255)                 DEFAULT '',
            post_id       bigint(20) unsigned          DEFAULT 0,
            post_type     varchar(50)                  DEFAULT '',
            referrer      varchar(500)                 DEFAULT '',
            user_agent    varchar(500)                 DEFAULT '',
            ip_hash       varchar(64)                  DEFAULT '',
            duration      int(11)                      DEFAULT 0,
            created_at    datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY   (id),
            KEY idx_session (session_id),
            KEY idx_created (created_at),
            KEY idx_post    (post_id)
        ) $charset_collate;" );
        $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}mh_tracking_events (
            id            bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_id    varchar(64)         NOT NULL DEFAULT '',
            event_type    varchar(50)         NOT NULL DEFAULT '',
            event_target  varchar(500)                 DEFAULT '',
            event_value   varchar(255)                 DEFAULT '',
            post_id       bigint(20) unsigned          DEFAULT 0,
            ip_hash       varchar(64)                  DEFAULT '',
            created_at    datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY   (id),
            KEY idx_session    (session_id),
            KEY idx_event_type (event_type),
            KEY idx_created    (created_at)
        ) $charset_collate;" );
        // Schedule cleanup if not already scheduled
        if ( ! wp_next_scheduled( 'mh_tracking_cleanup' ) ) {
            wp_schedule_event( time(), 'daily', 'mh_tracking_cleanup' );
        }
    }
    // =========================================================================
    // REST API routes
    // =========================================================================
    public function register_rest_routes() {
        $args = array( 'permission_callback' => '__return_true' );
        register_rest_route( 'microhub/v1', '/track/pageview', array_merge( $args, array(
            'methods'  => 'POST',
            'callback' => array( $this, 'rest_track_pageview' ),
        ) ) );
        register_rest_route( 'microhub/v1', '/track/event', array_merge( $args, array(
            'methods'  => 'POST',
            'callback' => array( $this, 'rest_track_event' ),
        ) ) );
        register_rest_route( 'microhub/v1', '/track/duration', array_merge( $args, array(
            'methods'  => 'POST',
            'callback' => array( $this, 'rest_track_duration' ),
        ) ) );
    }
    // =========================================================================
    // Script enqueue — MicroHub pages only
    // =========================================================================
    public function enqueue_tracking_script() {
        if ( is_admin() ) return;
        global $post;
        // Only load on MicroHub content — same set as microhub_enqueue_scripts()
        $load = is_singular( 'mh_paper' )    ||
                is_singular( 'mh_protocol' ) ||
                is_singular( 'mh_discussion' ) ||
                is_tax( 'mh_technique' )     ||
                is_tax( 'mh_microscope' )    ||
                is_tax( 'mh_microscope_model' ) ||
                is_tax( 'mh_organism' )      ||
                is_tax( 'mh_software' )      ||
                is_tax( 'mh_fluorophore' )   ||
                is_tax( 'mh_cell_line' )     ||
                is_tax( 'mh_sample_prep' )   ||
                is_tax( 'mh_facility' )      ||
                is_front_page()              ||
                is_home();
        // Also load on any page that contains a MicroHub shortcode
        if ( ! $load && $post instanceof WP_Post ) {
            $shortcodes = array(
                'microhub_search_page', 'microhub_papers', 'microhub_featured',
                'microhub_stats', 'microhub_forum', 'microhub_results_grid',
                'microhub_filters', 'microhub_hero', 'microhub_quick_filters',
                'microhub_recent_papers', 'microhub_top_cited',
            );
            foreach ( $shortcodes as $sc ) {
                if ( has_shortcode( $post->post_content, $sc ) ) {
                    $load = true;
                    break;
                }
            }
        }
        if ( ! $load ) return;
        wp_enqueue_script(
            'microhub-tracking',
            MICROHUB_PLUGIN_URL . 'assets/js/tracking.js',
            array(),
            MICROHUB_VERSION,
            true   // footer
        );
        $post_id   = 0;
        $post_type = '';
        if ( is_singular() && $post instanceof WP_Post ) {
            $post_id   = $post->ID;
            $post_type = $post->post_type;
        }
        // NOTE: restBase must NOT have a trailing slash — tracking.js appends /track/pageview etc.
        wp_localize_script( 'microhub-tracking', 'mhTracking', array(
            'ajaxurl'  => admin_url( 'admin-ajax.php' ),
            'restBase' => rtrim( rest_url( 'microhub/v1' ), '/' ),
            'postId'   => $post_id,
            'postType' => $post_type,
        ) );
    }
    // =========================================================================
    // REST handlers
    // =========================================================================
    public function rest_track_pageview( $request ) {
        global $wpdb;
        $session_id = sanitize_text_field( $request->get_param( 'session_id' ) ?: '' );
        $page_url   = sanitize_text_field( $request->get_param( 'page_url' )   ?: '/' );
        $page_title = sanitize_text_field( $request->get_param( 'page_title' ) ?: '' );
        $post_id    = absint( $request->get_param( 'post_id' ) );
        $post_type  = sanitize_text_field( $request->get_param( 'post_type' )  ?: '' );
        $referrer   = sanitize_text_field( $request->get_param( 'referrer' )   ?: '' );
        if ( empty( $session_id ) ) {
            $session_id = 'anon_' . substr( md5( microtime() . wp_rand() ), 0, 20 );
        }
        $result = $wpdb->insert(
            $wpdb->prefix . 'mh_page_views',
            array(
                'session_id' => $session_id,
                'page_url'   => substr( $page_url, 0, 500 ),
                'page_title' => substr( $page_title, 0, 255 ),
                'post_id'    => $post_id,
                'post_type'  => $post_type,
                'referrer'   => substr( $referrer, 0, 500 ),
                'user_agent' => substr( $this->get_ua(), 0, 500 ),
                'ip_hash'    => $this->hash_ip( $this->get_ip() ),
                'duration'   => 0,
            ),
            array( '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d' )
        );
        if ( $result === false ) {
            return new WP_REST_Response( array(
                'success' => false,
                'error'   => $wpdb->last_error,
            ), 500 );
        }
        return new WP_REST_Response( array(
            'success' => true,
            'id'      => $wpdb->insert_id,
        ), 200 );
    }
    public function rest_track_event( $request ) {
        global $wpdb;
        $session_id   = sanitize_text_field( $request->get_param( 'session_id' )   ?: '' );
        $event_type   = sanitize_text_field( $request->get_param( 'event_type' )   ?: '' );
        $event_target = sanitize_text_field( $request->get_param( 'event_target' ) ?: '' );
        $event_value  = sanitize_text_field( $request->get_param( 'event_value' )  ?: '' );
        $post_id      = absint( $request->get_param( 'post_id' ) );
        if ( empty( $session_id ) || empty( $event_type ) ) {
            return new WP_REST_Response( array( 'success' => false, 'error' => 'Missing required fields' ), 400 );
        }
        $wpdb->insert(
            $wpdb->prefix . 'mh_tracking_events',
            array(
                'session_id'   => $session_id,
                'event_type'   => $event_type,
                'event_target' => substr( $event_target, 0, 500 ),
                'event_value'  => substr( $event_value, 0, 255 ),
                'post_id'      => $post_id,
                'ip_hash'      => $this->hash_ip( $this->get_ip() ),
            ),
            array( '%s', '%s', '%s', '%s', '%d', '%s' )
        );
        return new WP_REST_Response( array( 'success' => true ), 200 );
    }
    public function rest_track_duration( $request ) {
        global $wpdb;
        $session_id = sanitize_text_field( $request->get_param( 'session_id' ) ?: '' );
        $page_url   = sanitize_text_field( $request->get_param( 'page_url' )   ?: '' );
        $duration   = absint( $request->get_param( 'duration' ) );
        if ( empty( $session_id ) || $duration < 1 ) {
            return new WP_REST_Response( array( 'success' => false ), 400 );
        }
        $duration = min( $duration, 3600 );
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$wpdb->prefix}mh_page_views
             SET duration = %d
             WHERE session_id = %s AND page_url = %s
             ORDER BY id DESC LIMIT 1",
            $duration, $session_id, $page_url
        ) );
        return new WP_REST_Response( array( 'success' => true ), 200 );
    }
    // =========================================================================
    // AJAX fallback handlers
    // =========================================================================
    public function ajax_track_pageview() {
        global $wpdb;
        $session_id = sanitize_text_field( $_POST['session_id'] ?? '' );
        $page_url   = sanitize_text_field( $_POST['page_url']   ?? '/' );
        $page_title = sanitize_text_field( $_POST['page_title'] ?? '' );
        $post_id    = absint( $_POST['post_id'] ?? 0 );
        $post_type  = sanitize_text_field( $_POST['post_type']  ?? '' );
        $referrer   = sanitize_text_field( $_POST['referrer']   ?? '' );
        if ( empty( $session_id ) ) {
            $session_id = 'anon_' . substr( md5( microtime() . wp_rand() ), 0, 20 );
        }
        $result = $wpdb->insert(
            $wpdb->prefix . 'mh_page_views',
            array(
                'session_id' => $session_id,
                'page_url'   => substr( $page_url, 0, 500 ),
                'page_title' => substr( $page_title, 0, 255 ),
                'post_id'    => $post_id,
                'post_type'  => $post_type,
                'referrer'   => substr( $referrer, 0, 500 ),
                'user_agent' => substr( $this->get_ua(), 0, 500 ),
                'ip_hash'    => $this->hash_ip( $this->get_ip() ),
                'duration'   => 0,
            ),
            array( '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d' )
        );
        if ( $result === false ) {
            wp_send_json_error( 'DB error: ' . $wpdb->last_error );
        }
        wp_send_json_success( array( 'id' => $wpdb->insert_id ) );
    }
    public function ajax_track_event() {
        global $wpdb;
        $session_id   = sanitize_text_field( $_POST['session_id']   ?? '' );
        $event_type   = sanitize_text_field( $_POST['event_type']   ?? '' );
        $event_target = sanitize_text_field( $_POST['event_target'] ?? '' );
        $event_value  = sanitize_text_field( $_POST['event_value']  ?? '' );
        $post_id      = absint( $_POST['post_id'] ?? 0 );
        if ( empty( $session_id ) || empty( $event_type ) ) {
            wp_send_json_error( 'Missing fields' );
        }
        $wpdb->insert(
            $wpdb->prefix . 'mh_tracking_events',
            array(
                'session_id'   => $session_id,
                'event_type'   => $event_type,
                'event_target' => substr( $event_target, 0, 500 ),
                'event_value'  => substr( $event_value, 0, 255 ),
                'post_id'      => $post_id,
                'ip_hash'      => $this->hash_ip( $this->get_ip() ),
            ),
            array( '%s', '%s', '%s', '%s', '%d', '%s' )
        );
        wp_send_json_success();
    }
    public function ajax_track_duration() {
        global $wpdb;
        $session_id = sanitize_text_field( $_POST['session_id'] ?? '' );
        $page_url   = sanitize_text_field( $_POST['page_url']   ?? '' );
        $duration   = absint( $_POST['duration'] ?? 0 );
        if ( empty( $session_id ) || $duration < 1 ) {
            wp_send_json_error( 'Missing fields' );
        }
        $duration = min( $duration, 3600 );
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$wpdb->prefix}mh_page_views
             SET duration = %d
             WHERE session_id = %s AND page_url = %s
             ORDER BY id DESC LIMIT 1",
            $duration, $session_id, $page_url
        ) );
        wp_send_json_success();
    }
    // =========================================================================
    // Helpers
    // =========================================================================
    private function get_ip() {
        foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR' ) as $h ) {
            if ( ! empty( $_SERVER[ $h ] ) ) {
                $ip = trim( explode( ',', $_SERVER[ $h ] )[0] );
                if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) return $ip;
            }
        }
        return '0.0.0.0';
    }
    private function get_ua() {
        return isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ) : '';
    }
    private function hash_ip( $ip ) {
        $salt = defined( 'AUTH_SALT' ) ? AUTH_SALT : 'mh_salt_v1';
        return hash( 'sha256', $ip . $salt . date( 'Y-m' ) );
    }
    // =========================================================================
    // Scheduled cleanup
    // =========================================================================
    public function cleanup_old_data() {
        global $wpdb;
        $cutoff = date( 'Y-m-d H:i:s', strtotime( '-90 days' ) );
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}mh_page_views WHERE created_at < %s", $cutoff
        ) );
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}mh_tracking_events WHERE created_at < %s", $cutoff
        ) );
    }
    // =========================================================================
    // Analytics query helpers (used by admin-analytics.php)
    // =========================================================================
    public static function get_visitor_count( $days = 30 ) {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(DISTINCT ip_hash) FROM {$wpdb->prefix}mh_page_views
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)", $days
        ) );
    }
    public static function get_pageview_count( $days = 30 ) {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}mh_page_views
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)", $days
        ) );
    }
    public static function get_avg_duration( $days = 30 ) {
        global $wpdb;
        return (float) $wpdb->get_var( $wpdb->prepare(
            "SELECT AVG(duration) FROM {$wpdb->prefix}mh_page_views
             WHERE duration > 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)", $days
        ) );
    }
    public static function get_daily_views( $days = 30 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT DATE(created_at) as date,
                    COUNT(*) as views,
                    COUNT(DISTINCT ip_hash) as visitors
             FROM {$wpdb->prefix}mh_page_views
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY DATE(created_at)
             ORDER BY date ASC", $days
        ) );
    }
    public static function get_top_pages( $days = 30, $limit = 20 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT page_url, page_title,
                    COUNT(*) as views,
                    COUNT(DISTINCT ip_hash) as visitors,
                    AVG(duration) as avg_duration
             FROM {$wpdb->prefix}mh_page_views
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY page_url, page_title
             ORDER BY views DESC
             LIMIT %d", $days, $limit
        ) );
    }
    public static function get_top_referrers( $days = 30, $limit = 20 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT referrer, COUNT(*) as visits
             FROM {$wpdb->prefix}mh_page_views
             WHERE referrer != '' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY referrer
             ORDER BY visits DESC
             LIMIT %d", $days, $limit
        ) );
    }
    public static function get_tag_usage( $days = 30, $limit = 30 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT event_value, COUNT(*) as clicks
             FROM {$wpdb->prefix}mh_tracking_events
             WHERE event_type = 'tag_click'
               AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_value
             ORDER BY clicks DESC
             LIMIT %d", $days, $limit
        ) );
    }
    public static function get_link_clicks( $days = 30, $limit = 30 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT event_target, event_value, COUNT(*) as clicks
             FROM {$wpdb->prefix}mh_tracking_events
             WHERE event_type IN ('link_click','outbound_link')
               AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_target, event_value
             ORDER BY clicks DESC
             LIMIT %d", $days, $limit
        ) );
    }
    public static function get_search_queries( $days = 30, $limit = 30 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT event_value, COUNT(*) as count
             FROM {$wpdb->prefix}mh_tracking_events
             WHERE event_type = 'search'
               AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_value
             ORDER BY count DESC
             LIMIT %d", $days, $limit
        ) );
    }
    public static function get_filter_usage( $days = 30, $limit = 30 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT event_target as filter_name, event_value, COUNT(*) as count
             FROM {$wpdb->prefix}mh_tracking_events
             WHERE event_type IN ('filter_change','tab_click')
               AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_target, event_value
             ORDER BY count DESC
             LIMIT %d", $days, $limit
        ) );
    }
    // Stub — bot_blocks table may not exist in the rewrite; return empty to avoid analytics errors
    public static function get_bot_stats( $days = 30 ) {
        return array();
    }
    public static function get_total_bot_blocks( $days = 30 ) {
        return 0;
    }
}
