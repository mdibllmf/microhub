<?php
/**
 * MicroHub Simple Visitor Tracking
 *
 * Stores all tracking data in wp_options — no custom tables.
 * WordPress guarantees wp_options always works.
 */

if (!defined('ABSPATH')) exit;

class MicroHub_Tracking {

    public function init() {
        add_action('rest_api_init', array($this, 'register_routes'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_script'));
        add_action('mh_tracking_cleanup', array($this, 'cleanup'));
    }

    public function register_routes() {
        register_rest_route('microhub/v1', '/track/pageview', array(
            'methods'  => 'POST',
            'callback' => array($this, 'handle_pageview'),
            'permission_callback' => '__return_true',
        ));
        register_rest_route('microhub/v1', '/track/event', array(
            'methods'  => 'POST',
            'callback' => array($this, 'handle_event'),
            'permission_callback' => '__return_true',
        ));
        register_rest_route('microhub/v1', '/track/duration', array(
            'methods'  => 'POST',
            'callback' => array($this, 'handle_duration'),
            'permission_callback' => '__return_true',
        ));
    }

    public function enqueue_script() {
        if (is_admin()) return;

        // Only load on MicroHub content pages — mirrors the conditional in microhub_enqueue_scripts()
        global $post;
        $should_load = is_singular('mh_paper') ||
                       is_singular('mh_protocol') ||
                       is_singular('mh_discussion') ||
                       is_tax('mh_technique') ||
                       is_tax('mh_microscope') ||
                       is_tax('mh_organism') ||
                       is_tax('mh_software') ||
                       is_tax('mh_fluorophore') ||
                       is_tax('mh_cell_line') ||
                       is_tax('mh_sample_prep') ||
                       is_front_page() ||
                       is_home();

        if (!$should_load && is_a($post, 'WP_Post')) {
            $shortcodes = array(
                'microhub_search_page', 'microhub_papers', 'microhub_featured',
                'microhub_stats', 'microhub_forum', 'microhub_results_grid',
                'microhub_filters', 'microhub_hero',
            );
            foreach ($shortcodes as $sc) {
                if (has_shortcode($post->post_content, $sc)) {
                    $should_load = true;
                    break;
                }
            }
        }

        if (!$should_load) return;

        wp_enqueue_script('microhub-tracking', MICROHUB_PLUGIN_URL . 'assets/js/tracking.js', array(), MICROHUB_VERSION, true);

        $post_id = 0;
        $post_type = '';
        if (is_singular()) {
            if ($post) {
                $post_id = $post->ID;
                $post_type = $post->post_type;
            }
        }

        wp_localize_script('microhub-tracking', 'mhTracking', array(
            'ajaxurl'  => admin_url('admin-ajax.php'),
            'restUrl'  => rest_url('microhub/v1/track'),
            'postId'   => $post_id,
            'postType' => $post_type,
        ));
    }

    // --- REST handlers ---

    public function handle_pageview($request) {
        $session_id = sanitize_text_field($request->get_param('session_id') ?? '');
        $page_url   = sanitize_text_field($request->get_param('page_url') ?? '/');
        $page_title = sanitize_text_field($request->get_param('page_title') ?? '');
        $post_id    = absint($request->get_param('post_id') ?? 0);
        $post_type  = sanitize_text_field($request->get_param('post_type') ?? '');
        $referrer   = sanitize_text_field($request->get_param('referrer') ?? '');

        if (empty($session_id)) $session_id = wp_generate_password(16, false);

        $ip_hash = $this->hash_ip();

        $date = current_time('Y-m-d');
        $views = get_option('mh_pv_' . $date, array());
        $views[] = array(
            'sid'   => $session_id,
            'url'   => substr($page_url, 0, 500),
            'title' => substr($page_title, 0, 255),
            'pid'   => $post_id,
            'pt'    => $post_type,
            'ref'   => substr($referrer, 0, 500),
            'ip'    => $ip_hash,
            'dur'   => 0,
            't'     => current_time('H:i:s'),
        );
        if (count($views) > 500) $views = array_slice($views, -500);
        update_option('mh_pv_' . $date, $views, false);

        return new WP_REST_Response(array('success' => true));
    }

    public function handle_event($request) {
        $session_id   = sanitize_text_field($request->get_param('session_id') ?? '');
        $event_type   = sanitize_text_field($request->get_param('event_type') ?? '');
        $event_target = sanitize_text_field($request->get_param('event_target') ?? '');
        $event_value  = sanitize_text_field($request->get_param('event_value') ?? '');
        $post_id      = absint($request->get_param('post_id') ?? 0);

        if (empty($session_id) || empty($event_type)) {
            return new WP_REST_Response(array('success' => false), 400);
        }

        $date = current_time('Y-m-d');
        $events = get_option('mh_ev_' . $date, array());
        $events[] = array(
            'sid'    => $session_id,
            'type'   => $event_type,
            'target' => substr($event_target, 0, 500),
            'value'  => substr($event_value, 0, 255),
            'pid'    => $post_id,
            't'      => current_time('H:i:s'),
        );
        if (count($events) > 500) $events = array_slice($events, -500);
        update_option('mh_ev_' . $date, $events, false);

        return new WP_REST_Response(array('success' => true));
    }

    public function handle_duration($request) {
        $session_id = sanitize_text_field($request->get_param('session_id') ?? '');
        $duration   = min(absint($request->get_param('duration') ?? 0), 1800);
        $page_url   = sanitize_text_field($request->get_param('page_url') ?? '');

        if (empty($session_id) || $duration < 1) {
            return new WP_REST_Response(array('success' => false), 400);
        }

        $date = current_time('Y-m-d');
        $views = get_option('mh_pv_' . $date, array());
        for ($i = count($views) - 1; $i >= 0; $i--) {
            if (isset($views[$i]['sid']) && $views[$i]['sid'] === $session_id &&
                isset($views[$i]['url']) && $views[$i]['url'] === $page_url) {
                $views[$i]['dur'] = $duration;
                update_option('mh_pv_' . $date, $views, false);
                break;
            }
        }

        return new WP_REST_Response(array('success' => true));
    }

    // --- Helpers ---

    private function hash_ip() {
        $ip = '0.0.0.0';
        foreach (array('HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR') as $h) {
            if (!empty($_SERVER[$h])) {
                $candidate = $_SERVER[$h];
                if (strpos($candidate, ',') !== false) $candidate = trim(explode(',', $candidate)[0]);
                if (filter_var($candidate, FILTER_VALIDATE_IP)) { $ip = $candidate; break; }
            }
        }
        $salt = defined('AUTH_SALT') ? AUTH_SALT : 'mh';
        return hash('sha256', $ip . $salt . date('Y-m'));
    }

    public function record_page_view() { return; }

    public function cleanup() {
        global $wpdb;
        $cutoff = date('Y-m-d', strtotime('-90 days'));
        $options = $wpdb->get_col($wpdb->prepare(
            "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
            'mh_pv_%', 'mh_ev_%'
        ));
        foreach ($options as $name) {
            $date = substr($name, 6);
            if ($date < $cutoff) delete_option($name);
        }
    }

    // --- Dashboard query methods ---

    private static function load_views($days) {
        $all = array();
        $start = date('Y-m-d', strtotime("-{$days} days"));
        $end = current_time('Y-m-d');
        $d = $start;
        while ($d <= $end) {
            $data = get_option('mh_pv_' . $d, array());
            if (is_array($data)) {
                foreach ($data as $v) { $v['date'] = $d; $all[] = $v; }
            }
            $d = date('Y-m-d', strtotime($d . ' +1 day'));
        }
        return $all;
    }

    private static function load_events($days) {
        $all = array();
        $start = date('Y-m-d', strtotime("-{$days} days"));
        $end = current_time('Y-m-d');
        $d = $start;
        while ($d <= $end) {
            $data = get_option('mh_ev_' . $d, array());
            if (is_array($data)) {
                foreach ($data as $e) { $e['date'] = $d; $all[] = $e; }
            }
            $d = date('Y-m-d', strtotime($d . ' +1 day'));
        }
        return $all;
    }

    public static function get_visitor_count($days = 30) {
        $ips = array();
        foreach (self::load_views($days) as $v) {
            if (!empty($v['ip'])) $ips[$v['ip']] = 1;
        }
        return count($ips);
    }

    public static function get_pageview_count($days = 30) {
        return count(self::load_views($days));
    }

    public static function get_avg_duration($days = 30) {
        $durs = array();
        foreach (self::load_views($days) as $v) {
            if (!empty($v['dur']) && $v['dur'] > 0) $durs[] = (int)$v['dur'];
        }
        return empty($durs) ? 0 : array_sum($durs) / count($durs);
    }

    public static function get_daily_views($days = 30) {
        $by_date = array();
        foreach (self::load_views($days) as $v) {
            $d = $v['date'];
            if (!isset($by_date[$d])) $by_date[$d] = array('views' => 0, 'ips' => array());
            $by_date[$d]['views']++;
            if (!empty($v['ip'])) $by_date[$d]['ips'][$v['ip']] = 1;
        }
        ksort($by_date);
        $out = array();
        foreach ($by_date as $date => $data) {
            $o = new stdClass(); $o->date = $date; $o->views = $data['views']; $o->visitors = count($data['ips']);
            $out[] = $o;
        }
        return $out;
    }

    public static function get_top_pages($days = 30, $limit = 20) {
        $pages = array();
        foreach (self::load_views($days) as $v) {
            $url = $v['url'] ?? '/';
            if (!isset($pages[$url])) $pages[$url] = array('url' => $url, 'title' => '', 'views' => 0, 'ips' => array(), 'durs' => array());
            $pages[$url]['views']++;
            if (!empty($v['title'])) $pages[$url]['title'] = $v['title'];
            if (!empty($v['ip'])) $pages[$url]['ips'][$v['ip']] = 1;
            if (!empty($v['dur']) && $v['dur'] > 0) $pages[$url]['durs'][] = (int)$v['dur'];
        }
        usort($pages, function($a, $b) { return $b['views'] - $a['views']; });
        $out = array();
        foreach (array_slice($pages, 0, $limit) as $p) {
            $o = new stdClass();
            $o->page_url = $p['url']; $o->page_title = $p['title']; $o->views = $p['views'];
            $o->visitors = count($p['ips']);
            $o->avg_duration = empty($p['durs']) ? 0 : array_sum($p['durs']) / count($p['durs']);
            $out[] = $o;
        }
        return $out;
    }

    public static function get_top_referrers($days = 30, $limit = 20) {
        $refs = array();
        foreach (self::load_views($days) as $v) {
            $r = $v['ref'] ?? '';
            if (empty($r)) continue;
            if (!isset($refs[$r])) $refs[$r] = 0;
            $refs[$r]++;
        }
        arsort($refs);
        $out = array();
        foreach (array_slice($refs, 0, $limit, true) as $ref => $cnt) {
            $o = new stdClass(); $o->referrer = $ref; $o->visits = $cnt; $out[] = $o;
        }
        return $out;
    }

    public static function get_tag_usage($days = 30, $limit = 30) {
        return self::count_events_by_value($days, 'tag_click', $limit, 'clicks');
    }

    public static function get_link_clicks($days = 30, $limit = 30) {
        $links = array();
        foreach (self::load_events($days) as $e) {
            $t = $e['type'] ?? '';
            if ($t !== 'link_click' && $t !== 'outbound_link') continue;
            $key = ($e['target'] ?? '') . '|' . ($e['value'] ?? '');
            if (!isset($links[$key])) $links[$key] = array('target' => $e['target'] ?? '', 'value' => $e['value'] ?? '', 'clicks' => 0);
            $links[$key]['clicks']++;
        }
        usort($links, function($a, $b) { return $b['clicks'] - $a['clicks']; });
        $out = array();
        foreach (array_slice($links, 0, $limit) as $l) {
            $o = new stdClass(); $o->event_target = $l['target']; $o->event_value = $l['value']; $o->clicks = $l['clicks'];
            $out[] = $o;
        }
        return $out;
    }

    public static function get_search_queries($days = 30, $limit = 30) {
        return self::count_events_by_value($days, 'search', $limit, 'count');
    }

    public static function get_filter_usage($days = 30, $limit = 30) {
        $filters = array();
        foreach (self::load_events($days) as $e) {
            if (($e['type'] ?? '') !== 'filter_change') continue;
            $key = ($e['target'] ?? '') . '|' . ($e['value'] ?? '');
            if (!isset($filters[$key])) $filters[$key] = array('name' => $e['target'] ?? '', 'value' => $e['value'] ?? '', 'count' => 0);
            $filters[$key]['count']++;
        }
        usort($filters, function($a, $b) { return $b['count'] - $a['count']; });
        $out = array();
        foreach (array_slice($filters, 0, $limit) as $f) {
            $o = new stdClass(); $o->filter_name = $f['name']; $o->event_value = $f['value']; $o->count = $f['count'];
            $out[] = $o;
        }
        return $out;
    }

    public static function get_bot_stats($days = 30) { return array(); }
    public static function get_total_bot_blocks($days = 30) { return 0; }

    private static function count_events_by_value($days, $type, $limit, $count_key) {
        $counts = array();
        foreach (self::load_events($days) as $e) {
            if (($e['type'] ?? '') !== $type) continue;
            $val = $e['value'] ?? '';
            if (empty($val)) continue;
            if (!isset($counts[$val])) $counts[$val] = 0;
            $counts[$val]++;
        }
        arsort($counts);
        $out = array();
        foreach (array_slice($counts, 0, $limit, true) as $val => $cnt) {
            $o = new stdClass(); $o->event_value = $val; $o->$count_key = $cnt; $out[] = $o;
        }
        return $out;
    }
}
