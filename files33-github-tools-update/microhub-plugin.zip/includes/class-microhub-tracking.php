<?php
/**
 * MicroHub Visitor Tracking
 *
 * Tracks page views, session duration, tag usage, and link clicks.
 * All data is privacy-friendly: IPs are hashed, no cookies store personal info.
 * Only visible to admins (manage_options capability).
 *
 * Uses hybrid tracking for maximum reliability:
 * - Server-side (wp_footer): Records page views when PHP executes (non-cached pages)
 * - Client-side (AJAX fallback): Records page views when pages are served from cache
 * - Deduplication prevents double-counting
 */

if (!defined('ABSPATH')) exit;

class MicroHub_Tracking {

    public function init() {
        // One-time migration: ensure is_bot column exists (uses separate option key
        // to avoid conflicting with mh_tracking_db_version checked in microhub.php)
        $this->maybe_upgrade_tables();

        // Record page views server-side in wp_footer (works for non-cached pages)
        add_action('wp_footer', array($this, 'record_page_view'));

        // AJAX fallback for page views (works when pages are served from cache)
        add_action('wp_ajax_mh_record_view', array($this, 'ajax_record_view'));
        add_action('wp_ajax_nopriv_mh_record_view', array($this, 'ajax_record_view'));

        // AJAX endpoints for interaction tracking (events, duration, heartbeat)
        add_action('wp_ajax_mh_track_event', array($this, 'ajax_track_event'));
        add_action('wp_ajax_nopriv_mh_track_event', array($this, 'ajax_track_event'));
        add_action('wp_ajax_mh_track_duration', array($this, 'ajax_track_duration'));
        add_action('wp_ajax_nopriv_mh_track_duration', array($this, 'ajax_track_duration'));
        add_action('wp_ajax_mh_heartbeat', array($this, 'ajax_heartbeat'));
        add_action('wp_ajax_nopriv_mh_heartbeat', array($this, 'ajax_heartbeat'));

        // Enqueue tracking script for events/duration/AJAX fallback
        add_action('wp_enqueue_scripts', array($this, 'enqueue_tracking_script'));

        // Daily cleanup of old data (keep 90 days)
        add_action('mh_tracking_cleanup', array($this, 'cleanup_old_data'));
        if (!wp_next_scheduled('mh_tracking_cleanup')) {
            wp_schedule_event(time(), 'daily', 'mh_tracking_cleanup');
        }
    }

    /**
     * One-time upgrade: ensure is_bot column exists in tracking tables.
     * Uses a SEPARATE option key (mh_tracking_has_is_bot) to avoid conflicting
     * with mh_tracking_db_version which microhub.php checks against '1.0'.
     */
    private function maybe_upgrade_tables() {
        if (get_option('mh_tracking_has_is_bot')) {
            return;
        }

        global $wpdb;

        $table = $wpdb->prefix . 'mh_page_views';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") === $table) {
            $col = $wpdb->get_results("SHOW COLUMNS FROM `$table` LIKE 'is_bot'");
            if (empty($col)) {
                $wpdb->query("ALTER TABLE `$table` ADD COLUMN `is_bot` tinyint(1) DEFAULT 0 AFTER `ip_hash`");
                $wpdb->query("ALTER TABLE `$table` ADD KEY `idx_bot` (`is_bot`)");
            }
        }

        $table2 = $wpdb->prefix . 'mh_tracking_events';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table2'") === $table2) {
            $col2 = $wpdb->get_results("SHOW COLUMNS FROM `$table2` LIKE 'is_bot'");
            if (empty($col2)) {
                $wpdb->query("ALTER TABLE `$table2` ADD COLUMN `is_bot` tinyint(1) DEFAULT 0 AFTER `ip_hash`");
            }
        }

        update_option('mh_tracking_has_is_bot', '1', 'yes');
    }

    /**
     * Record a page view directly in wp_footer (server-side).
     * Sets a JS flag so the client-side AJAX fallback knows not to double-record.
     * On cached pages, this PHP won't execute, so the AJAX fallback takes over.
     */
    public function record_page_view() {
        if (is_admin()) return;

        global $wpdb;

        $session_id = $this->get_session_id();
        $page_url = isset($_SERVER['REQUEST_URI']) ? esc_url_raw($_SERVER['REQUEST_URI']) : '';
        $page_title = wp_get_document_title();
        $referrer = isset($_SERVER['HTTP_REFERER']) ? esc_url_raw($_SERVER['HTTP_REFERER']) : '';
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '';

        $post_id = 0;
        $post_type = '';
        if (is_singular()) {
            global $post;
            if ($post) {
                $post_id = $post->ID;
                $post_type = $post->post_type;
            }
        }

        $ip = $this->get_visitor_ip();
        $ip_hash = $this->hash_ip($ip);
        $is_bot = self::check_is_bot($ua) ? 1 : 0;

        $table = $wpdb->prefix . 'mh_page_views';
        $this->insert_page_view($table, array(
            'session_id' => $session_id,
            'page_url'   => substr($page_url, 0, 500),
            'page_title' => substr($page_title, 0, 255),
            'post_id'    => $post_id,
            'post_type'  => $post_type,
            'referrer'   => substr($referrer, 0, 500),
            'user_agent' => substr($ua, 0, 500),
            'ip_hash'    => $ip_hash,
            'is_bot'     => $is_bot,
            'duration'   => 0,
        ));

        // Tell the JS that the server already recorded this page view
        // so the AJAX fallback doesn't fire (deduplication)
        echo '<script>window.mhPageViewRecorded=true;</script>';
    }

    /**
     * Insert a page view row, with fallback if is_bot column is missing
     */
    private function insert_page_view($table, $data) {
        global $wpdb;
        $format = array('%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%d');
        $result = $wpdb->insert($table, $data, $format);

        if ($result === false) {
            // Retry without is_bot if column doesn't exist
            unset($data['is_bot']);
            array_splice($format, 8, 1);
            $wpdb->insert($table, $data, $format);
        }
    }

    /**
     * AJAX fallback: Record a page view when the page was served from cache
     * (PHP didn't execute, so wp_footer didn't fire)
     */
    public function ajax_record_view() {
        $this->verify_tracking_request();

        global $wpdb;

        $session_id = sanitize_text_field(self::post_string('session_id'));
        $page_url   = esc_url_raw(self::post_string('page_url'));
        $page_title = sanitize_text_field(self::post_string('page_title'));
        $post_id    = absint(self::post_string('post_id'));
        $post_type  = sanitize_text_field(self::post_string('post_type'));
        $referrer   = esc_url_raw(self::post_string('referrer'));

        if (empty($session_id) || empty($page_url)) {
            wp_send_json_error('Missing data');
        }

        $ip = $this->get_visitor_ip();
        $ip_hash = $this->hash_ip($ip);
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '';
        $is_bot = self::check_is_bot($ua) ? 1 : 0;

        $table = $wpdb->prefix . 'mh_page_views';
        $this->insert_page_view($table, array(
            'session_id' => $session_id,
            'page_url'   => substr($page_url, 0, 500),
            'page_title' => substr($page_title, 0, 255),
            'post_id'    => $post_id,
            'post_type'  => $post_type,
            'referrer'   => substr($referrer, 0, 500),
            'user_agent' => substr($ua, 0, 500),
            'ip_hash'    => $ip_hash,
            'is_bot'     => $is_bot,
            'duration'   => 0,
        ));

        wp_send_json_success();
    }

    /**
     * Enqueue tracking JavaScript
     */
    public function enqueue_tracking_script() {
        if (is_admin()) return;

        wp_enqueue_script(
            'microhub-tracking',
            MICROHUB_PLUGIN_URL . 'assets/js/tracking.js',
            array('jquery'),
            MICROHUB_VERSION,
            true
        );

        $post_id = 0;
        $post_type = '';
        if (is_singular()) {
            global $post;
            if ($post) {
                $post_id = $post->ID;
                $post_type = $post->post_type;
            }
        }

        wp_localize_script('microhub-tracking', 'mhTracking', array(
            'ajaxurl'   => admin_url('admin-ajax.php'),
            'nonce'     => wp_create_nonce('mh_tracking_nonce'),
            'postId'    => $post_id,
            'postType'  => $post_type,
            'sessionId' => $this->get_session_id(),
        ));
    }

    /**
     * Get or create a session ID (stored in a simple non-personal cookie)
     */
    private function get_session_id() {
        if (isset($_COOKIE['mh_sid'])) {
            return sanitize_text_field($_COOKIE['mh_sid']);
        }
        $sid = wp_generate_password(32, false);
        if (!headers_sent()) {
            setcookie('mh_sid', $sid, time() + 1800, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
        }
        return $sid;
    }

    /**
     * Hash an IP address for privacy
     */
    private function hash_ip($ip) {
        $salt = defined('AUTH_SALT') ? AUTH_SALT : 'mh_default_salt';
        return hash('sha256', $ip . $salt . date('Y-m'));
    }

    /**
     * Get the visitor's real IP
     */
    private function get_visitor_ip() {
        $headers = array('HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR');
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        return '0.0.0.0';
    }

    /**
     * Safely check if a user agent is a bot for analytics tagging
     */
    private static function check_is_bot($ua) {
        if (method_exists('MicroHub_Bot_Guard', 'is_bot_for_analytics')) {
            return MicroHub_Bot_Guard::is_bot_for_analytics($ua);
        }
        if (method_exists('MicroHub_Bot_Guard', 'is_bot_ua')) {
            return MicroHub_Bot_Guard::is_bot_ua($ua);
        }
        return empty($ua);
    }

    /**
     * Safely get a string value from $_POST
     */
    private static function post_string($key) {
        return isset($_POST[$key]) && is_string($_POST[$key]) ? $_POST[$key] : '';
    }

    /**
     * Verify a tracking AJAX request
     */
    private function verify_tracking_request() {
        $nonce = isset($_POST['nonce']) && is_string($_POST['nonce']) ? $_POST['nonce'] : '';
        if ($nonce !== '' && wp_verify_nonce($nonce, 'mh_tracking_nonce')) {
            return;
        }

        $sid = isset($_POST['session_id']) && is_string($_POST['session_id']) ? $_POST['session_id'] : '';
        if ($sid === '' || !preg_match('/^[a-zA-Z0-9]{32}$/', $sid)) {
            wp_send_json_error('Invalid request', 403);
        }

        if (empty($_SERVER['HTTP_USER_AGENT'])) {
            wp_send_json_error('Invalid request', 403);
        }
    }

    /**
     * AJAX: Track an interaction event
     */
    public function ajax_track_event() {
        $this->verify_tracking_request();

        global $wpdb;

        $session_id   = sanitize_text_field(self::post_string('session_id'));
        $event_type   = sanitize_text_field(self::post_string('event_type'));
        $event_target = sanitize_text_field(self::post_string('event_target'));
        $event_value  = sanitize_text_field(self::post_string('event_value'));
        $post_id      = absint(self::post_string('post_id'));

        if (empty($session_id) || empty($event_type)) {
            wp_send_json_error('Missing data');
        }

        $allowed_types = array(
            'tag_click', 'link_click', 'outbound_link', 'search',
            'filter_change', 'paper_view', 'protocol_view', 'discussion_view',
            'download', 'chat_open', 'pagination',
        );

        if (!in_array($event_type, $allowed_types)) {
            wp_send_json_error('Invalid event type');
        }

        $ip = $this->get_visitor_ip();
        $ip_hash = $this->hash_ip($ip);
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '';
        $is_bot = self::check_is_bot($ua) ? 1 : 0;

        $table = $wpdb->prefix . 'mh_tracking_events';
        $data = array(
            'session_id'   => $session_id,
            'event_type'   => $event_type,
            'event_target' => substr($event_target, 0, 500),
            'event_value'  => substr($event_value, 0, 255),
            'post_id'      => $post_id,
            'ip_hash'      => $ip_hash,
            'is_bot'       => $is_bot,
        );
        $format = array('%s', '%s', '%s', '%s', '%d', '%s', '%d');

        $result = $wpdb->insert($table, $data, $format);
        if ($result === false) {
            unset($data['is_bot']);
            array_splice($format, 6, 1);
            $wpdb->insert($table, $data, $format);
        }

        wp_send_json_success();
    }

    /**
     * AJAX: Update session duration for a page view
     */
    public function ajax_track_duration() {
        $this->verify_tracking_request();

        global $wpdb;

        $session_id = sanitize_text_field(self::post_string('session_id'));
        $duration   = absint(self::post_string('duration'));
        $page_url   = esc_url_raw(self::post_string('page_url'));

        if (empty($session_id) || $duration < 1) {
            wp_send_json_error('Missing data');
        }

        $duration = min($duration, 1800);

        $table = $wpdb->prefix . 'mh_page_views';
        $wpdb->query($wpdb->prepare(
            "UPDATE $table SET duration = %d WHERE session_id = %s AND page_url = %s ORDER BY id DESC LIMIT 1",
            $duration, $session_id, $page_url
        ));

        wp_send_json_success();
    }

    /**
     * AJAX: Heartbeat to keep session alive
     */
    public function ajax_heartbeat() {
        $this->verify_tracking_request();
        wp_send_json_success(array('alive' => true));
    }

    /**
     * Clean up data older than 90 days
     */
    public function cleanup_old_data() {
        global $wpdb;

        $cutoff = date('Y-m-d H:i:s', strtotime('-90 days'));

        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}mh_page_views WHERE created_at < %s", $cutoff
        ));
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}mh_tracking_events WHERE created_at < %s", $cutoff
        ));
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}mh_bot_blocks WHERE created_at < %s", $cutoff
        ));
    }

    // =========================================================================
    // Query helpers for the admin dashboard
    // =========================================================================

    public static function get_visitor_count($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT ip_hash) FROM $table WHERE is_bot = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }

    public static function get_pageview_count($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE is_bot = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }

    public static function get_avg_duration($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return (float) $wpdb->get_var($wpdb->prepare(
            "SELECT AVG(duration) FROM $table WHERE is_bot = 0 AND duration > 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }

    public static function get_daily_views($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(created_at) as date, COUNT(*) as views, COUNT(DISTINCT ip_hash) as visitors
             FROM $table WHERE is_bot = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY DATE(created_at) ORDER BY date ASC",
            $days
        ));
    }

    public static function get_top_pages($days = 30, $limit = 20) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT page_url, page_title, COUNT(*) as views, COUNT(DISTINCT ip_hash) as visitors, AVG(duration) as avg_duration
             FROM $table WHERE is_bot = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY page_url, page_title ORDER BY views DESC LIMIT %d",
            $days, $limit
        ));
    }

    public static function get_top_referrers($days = 30, $limit = 20) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT referrer, COUNT(*) as visits
             FROM $table WHERE is_bot = 0 AND referrer != '' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY referrer ORDER BY visits DESC LIMIT %d",
            $days, $limit
        ));
    }

    public static function get_tag_usage($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_value, COUNT(*) as clicks
             FROM $table WHERE is_bot = 0 AND event_type = 'tag_click' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_value ORDER BY clicks DESC LIMIT %d",
            $days, $limit
        ));
    }

    public static function get_link_clicks($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_target, event_value, COUNT(*) as clicks
             FROM $table WHERE is_bot = 0 AND event_type IN ('link_click','outbound_link') AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_target, event_value ORDER BY clicks DESC LIMIT %d",
            $days, $limit
        ));
    }

    public static function get_search_queries($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_value, COUNT(*) as count
             FROM $table WHERE is_bot = 0 AND event_type = 'search' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_value ORDER BY count DESC LIMIT %d",
            $days, $limit
        ));
    }

    public static function get_filter_usage($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_target as filter_name, event_value, COUNT(*) as count
             FROM $table WHERE is_bot = 0 AND event_type = 'filter_change' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_target, event_value ORDER BY count DESC LIMIT %d",
            $days, $limit
        ));
    }

    public static function get_bot_stats($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_bot_blocks';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT reason, COUNT(*) as blocks
             FROM $table WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY reason ORDER BY blocks DESC",
            $days
        ));
    }

    public static function get_total_bot_blocks($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_bot_blocks';
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }

    /**
     * Get raw total row count (including bots) for diagnostics
     */
    public static function get_raw_row_count() {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM $table");
    }
}
