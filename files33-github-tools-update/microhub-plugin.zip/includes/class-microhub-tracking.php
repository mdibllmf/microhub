<?php
/**
 * MicroHub Visitor Tracking
 *
 * Tracks page views, session duration, tag usage, and link clicks.
 * All data is privacy-friendly: IPs are hashed, no cookies store personal info.
 *
 * Compatible with SiteGround page caching:
 * - Uses HMAC token instead of WordPress nonces (nonces expire in cached pages)
 * - Session IDs generated client-side (cookies can't be set on cached pages)
 * - Tables created with direct SQL (dbDelta fails on some hosts)
 * - Admin users are tracked (admin is often the primary tester)
 */

if (!defined('ABSPATH')) exit;

class MicroHub_Tracking {

    /** HMAC secret key for verifying tracking requests (not time-limited like nonces) */
    private static function get_hmac_key() {
        return defined('AUTH_SALT') ? AUTH_SALT : 'mh_tracking_default_key';
    }

    public function init() {
        // Record page view on frontend (server-side, runs on uncached pages)
        add_action('wp_footer', array($this, 'record_page_view'));

        // AJAX endpoints for frontend tracking (uses HMAC, not nonces — cache-safe)
        add_action('wp_ajax_mh_track_event', array($this, 'ajax_track_event'));
        add_action('wp_ajax_nopriv_mh_track_event', array($this, 'ajax_track_event'));
        add_action('wp_ajax_mh_track_duration', array($this, 'ajax_track_duration'));
        add_action('wp_ajax_nopriv_mh_track_duration', array($this, 'ajax_track_duration'));
        add_action('wp_ajax_mh_heartbeat', array($this, 'ajax_heartbeat'));
        add_action('wp_ajax_nopriv_mh_heartbeat', array($this, 'ajax_heartbeat'));

        // Enqueue tracking script on all frontend pages
        add_action('wp_enqueue_scripts', array($this, 'enqueue_tracking_script'));

        // Daily cleanup of old data (keep 90 days)
        add_action('mh_tracking_cleanup', array($this, 'cleanup_old_data'));
        if (!wp_next_scheduled('mh_tracking_cleanup')) {
            wp_schedule_event(time(), 'daily', 'mh_tracking_cleanup');
        }
    }

    /**
     * Ensure tracking tables exist (self-healing, called before inserts)
     */
    public static function ensure_tables() {
        global $wpdb;

        $table = $wpdb->prefix . 'mh_page_views';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") === $table) {
            return true; // Tables already exist
        }

        // Create tables with direct SQL (dbDelta fails on some hosts like SiteGround)
        $charset_collate = $wpdb->get_charset_collate();

        $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}mh_page_views (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_id varchar(64) NOT NULL,
            page_url varchar(500) NOT NULL,
            page_title varchar(255) DEFAULT '',
            post_id bigint(20) unsigned DEFAULT 0,
            post_type varchar(50) DEFAULT '',
            referrer varchar(500) DEFAULT '',
            user_agent varchar(500) DEFAULT '',
            ip_hash varchar(64) NOT NULL,
            is_bot tinyint(1) DEFAULT 0,
            duration int(11) DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_session (session_id),
            KEY idx_created (created_at),
            KEY idx_post (post_id),
            KEY idx_bot (is_bot)
        ) $charset_collate;");

        $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}mh_tracking_events (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_id varchar(64) NOT NULL,
            event_type varchar(50) NOT NULL,
            event_target varchar(500) DEFAULT '',
            event_value varchar(255) DEFAULT '',
            post_id bigint(20) unsigned DEFAULT 0,
            ip_hash varchar(64) NOT NULL,
            is_bot tinyint(1) DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_session (session_id),
            KEY idx_event_type (event_type),
            KEY idx_created (created_at)
        ) $charset_collate;");

        $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}mh_bot_blocks (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            ip_hash varchar(64) NOT NULL,
            user_agent varchar(500) DEFAULT '',
            reason varchar(100) NOT NULL,
            page_url varchar(500) DEFAULT '',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_created (created_at),
            KEY idx_ip (ip_hash)
        ) $charset_collate;");

        update_option('mh_tracking_db_version', '1.0');

        return $wpdb->get_var("SHOW TABLES LIKE '$table'") === $table;
    }

    /**
     * Enqueue tracking JavaScript on all frontend pages
     */
    public function enqueue_tracking_script() {
        if (is_admin()) return;

        wp_enqueue_script(
            'microhub-tracking',
            MICROHUB_PLUGIN_URL . 'assets/js/tracking.js',
            array('jquery'),
            MICROHUB_VERSION,
            true
        );

        // Generate HMAC token (not time-limited like nonces — survives page caching)
        $hmac_token = hash_hmac('sha256', 'mh_tracking', self::get_hmac_key());

        wp_localize_script('microhub-tracking', 'mhTracking', array(
            'ajaxurl'   => admin_url('admin-ajax.php'),
            'token'     => $hmac_token,
            'postId'    => is_singular() ? get_the_ID() : 0,
            'postType'  => is_singular() ? get_post_type() : '',
        ));
    }

    /**
     * Verify HMAC token from tracking request (cache-safe, unlike nonces)
     */
    private function verify_tracking_token() {
        $token = isset($_POST['token']) ? sanitize_text_field($_POST['token']) : '';
        $expected = hash_hmac('sha256', 'mh_tracking', self::get_hmac_key());
        return hash_equals($expected, $token);
    }

    /**
     * Hash an IP address for privacy
     */
    private function hash_ip($ip) {
        $salt = defined('AUTH_SALT') ? AUTH_SALT : 'mh_default_salt';
        return hash('sha256', $ip . $salt . date('Y-m'));
    }

    /**
     * Get the visitor's real IP
     */
    private function get_visitor_ip() {
        $headers = array('HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR');
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        return '0.0.0.0';
    }

    /**
     * Detect bot from user-agent (standalone, no dependency on Bot_Guard class)
     */
    private static function detect_bot($ua) {
        if (empty($ua)) return true;
        $ua_lower = strtolower($ua);

        // Allow known good bots
        $good = array('googlebot','bingbot','duckduckbot','facebot','twitterbot','linkedinbot','slackbot','whatsapp','telegrambot','applebot');
        foreach ($good as $g) {
            if (strpos($ua_lower, $g) !== false) return false;
        }

        // Check known bad patterns
        $bad = array('scrapy','phantomjs','headlesschrome','selenium','puppeteer','playwright','zgrab','masscan','nikto','sqlmap','nmap','dirbuster','gobuster','wpscan','nuclei','semrush','ahrefs','mj12bot','dotbot','petalbot','bytespider','dataforseo');
        foreach ($bad as $b) {
            if (strpos($ua_lower, $b) !== false) return true;
        }

        return false;
    }

    /**
     * Record a page view (server-side, runs on uncached page loads)
     * NOTE: Admin users ARE tracked — admin is often the only/primary tester
     */
    public function record_page_view() {
        // Only skip actual wp-admin pages
        if (is_admin()) return;

        global $wpdb, $post;

        // Ensure tables exist (self-healing)
        if (!self::ensure_tables()) return;

        $ip = $this->get_visitor_ip();
        $ip_hash = $this->hash_ip($ip);
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '';
        $session_id = isset($_COOKIE['mh_sid']) ? sanitize_text_field($_COOKIE['mh_sid']) : 'server_' . substr(md5($ip . date('Y-m-d-H')), 0, 16);

        $is_bot = self::detect_bot($ua) ? 1 : 0;

        $page_url = isset($_SERVER['REQUEST_URI']) ? esc_url_raw($_SERVER['REQUEST_URI']) : '';
        $page_title = is_singular() && $post ? $post->post_title : wp_title('', false);
        $post_id = is_singular() && $post ? $post->ID : 0;
        $post_type = is_singular() && $post ? $post->post_type : '';
        $referrer = isset($_SERVER['HTTP_REFERER']) ? esc_url_raw($_SERVER['HTTP_REFERER']) : '';

        $table = $wpdb->prefix . 'mh_page_views';
        $result = $wpdb->insert($table, array(
            'session_id' => $session_id,
            'page_url'   => substr($page_url, 0, 500),
            'page_title' => substr($page_title, 0, 255),
            'post_id'    => $post_id,
            'post_type'  => $post_type,
            'referrer'   => substr($referrer, 0, 500),
            'user_agent' => substr($ua, 0, 500),
            'ip_hash'    => $ip_hash,
            'is_bot'     => $is_bot,
            'duration'   => 0,
        ), array('%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%d'));

        // If insert failed (e.g. missing is_bot column from old schema), try without it
        if ($result === false) {
            $wpdb->insert($table, array(
                'session_id' => $session_id,
                'page_url'   => substr($page_url, 0, 500),
                'page_title' => substr($page_title, 0, 255),
                'post_id'    => $post_id,
                'post_type'  => $post_type,
                'referrer'   => substr($referrer, 0, 500),
                'user_agent' => substr($ua, 0, 500),
                'ip_hash'    => $ip_hash,
                'duration'   => 0,
            ), array('%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d'));
        }
    }

    /**
     * AJAX: Track an interaction event (tag click, link click, search, filter)
     * Uses HMAC token instead of nonce — compatible with page caching
     */
    public function ajax_track_event() {
        if (!$this->verify_tracking_token()) {
            wp_send_json_error('Invalid token');
        }

        global $wpdb;

        // Ensure tables exist
        self::ensure_tables();

        $session_id  = sanitize_text_field($_POST['session_id'] ?? '');
        $event_type  = sanitize_text_field($_POST['event_type'] ?? '');
        $event_target = sanitize_text_field($_POST['event_target'] ?? '');
        $event_value = sanitize_text_field($_POST['event_value'] ?? '');
        $post_id     = absint($_POST['post_id'] ?? 0);

        if (empty($session_id) || empty($event_type)) {
            wp_send_json_error('Missing data');
        }

        $allowed_types = array(
            'tag_click', 'link_click', 'outbound_link', 'search',
            'filter_change', 'paper_view', 'protocol_view', 'discussion_view',
            'download', 'chat_open', 'pagination',
        );

        if (!in_array($event_type, $allowed_types)) {
            wp_send_json_error('Invalid event type');
        }

        $ip = $this->get_visitor_ip();
        $ip_hash = $this->hash_ip($ip);
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '';
        $is_bot = self::detect_bot($ua) ? 1 : 0;

        $table = $wpdb->prefix . 'mh_tracking_events';
        $wpdb->insert($table, array(
            'session_id'   => $session_id,
            'event_type'   => $event_type,
            'event_target' => substr($event_target, 0, 500),
            'event_value'  => substr($event_value, 0, 255),
            'post_id'      => $post_id,
            'ip_hash'      => $ip_hash,
            'is_bot'       => $is_bot,
        ), array('%s', '%s', '%s', '%s', '%d', '%s', '%d'));

        wp_send_json_success();
    }

    /**
     * AJAX: Update session duration for a page view
     */
    public function ajax_track_duration() {
        if (!$this->verify_tracking_token()) {
            wp_send_json_error('Invalid token');
        }

        global $wpdb;

        $session_id = sanitize_text_field($_POST['session_id'] ?? '');
        $duration   = absint($_POST['duration'] ?? 0);
        $page_url   = esc_url_raw($_POST['page_url'] ?? '');

        if (empty($session_id) || $duration < 1) {
            wp_send_json_error('Missing data');
        }

        // Cap duration at 30 minutes to avoid stale tabs
        $duration = min($duration, 1800);

        $table = $wpdb->prefix . 'mh_page_views';
        $wpdb->query($wpdb->prepare(
            "UPDATE $table SET duration = %d WHERE session_id = %s AND page_url = %s ORDER BY id DESC LIMIT 1",
            $duration, $session_id, $page_url
        ));

        wp_send_json_success();
    }

    /**
     * AJAX: Heartbeat to keep session alive
     */
    public function ajax_heartbeat() {
        if (!$this->verify_tracking_token()) {
            wp_send_json_error('Invalid token');
        }
        wp_send_json_success(array('alive' => true));
    }

    /**
     * Clean up data older than 90 days
     */
    public function cleanup_old_data() {
        global $wpdb;

        $cutoff = date('Y-m-d H:i:s', strtotime('-90 days'));

        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}mh_page_views WHERE created_at < %s", $cutoff
        ));
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}mh_tracking_events WHERE created_at < %s", $cutoff
        ));
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}mh_bot_blocks WHERE created_at < %s", $cutoff
        ));
    }

    // =========================================================================
    // Query helpers for the admin dashboard
    // =========================================================================

    public static function get_visitor_count($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT ip_hash) FROM $table WHERE is_bot = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }

    public static function get_pageview_count($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE is_bot = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }

    public static function get_avg_duration($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return (float) $wpdb->get_var($wpdb->prepare(
            "SELECT AVG(duration) FROM $table WHERE is_bot = 0 AND duration > 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }

    public static function get_daily_views($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(created_at) as date, COUNT(*) as views, COUNT(DISTINCT ip_hash) as visitors
             FROM $table WHERE is_bot = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY DATE(created_at) ORDER BY date ASC",
            $days
        ));
    }

    public static function get_top_pages($days = 30, $limit = 20) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT page_url, page_title, COUNT(*) as views, COUNT(DISTINCT ip_hash) as visitors, AVG(duration) as avg_duration
             FROM $table WHERE is_bot = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY page_url, page_title ORDER BY views DESC LIMIT %d",
            $days, $limit
        ));
    }

    public static function get_top_referrers($days = 30, $limit = 20) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT referrer, COUNT(*) as visits
             FROM $table WHERE is_bot = 0 AND referrer != '' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY referrer ORDER BY visits DESC LIMIT %d",
            $days, $limit
        ));
    }

    public static function get_tag_usage($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_value, COUNT(*) as clicks
             FROM $table WHERE is_bot = 0 AND event_type = 'tag_click' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_value ORDER BY clicks DESC LIMIT %d",
            $days, $limit
        ));
    }

    public static function get_link_clicks($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_target, event_value, COUNT(*) as clicks
             FROM $table WHERE is_bot = 0 AND event_type IN ('link_click','outbound_link') AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_target, event_value ORDER BY clicks DESC LIMIT %d",
            $days, $limit
        ));
    }

    public static function get_search_queries($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_value, COUNT(*) as count
             FROM $table WHERE is_bot = 0 AND event_type = 'search' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_value ORDER BY count DESC LIMIT %d",
            $days, $limit
        ));
    }

    public static function get_filter_usage($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_target as filter_name, event_value, COUNT(*) as count
             FROM $table WHERE is_bot = 0 AND event_type = 'filter_change' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_target, event_value ORDER BY count DESC LIMIT %d",
            $days, $limit
        ));
    }

    public static function get_bot_stats($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_bot_blocks';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT reason, COUNT(*) as blocks
             FROM $table WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY reason ORDER BY blocks DESC",
            $days
        ));
    }

    public static function get_total_bot_blocks($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_bot_blocks';
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }
}
