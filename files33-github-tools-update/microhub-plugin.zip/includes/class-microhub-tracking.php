<?php
/**
 * MicroHub Visitor Tracking - Rebuilt from scratch
 *
 * Self-contained tracking system with NO external dependencies.
 * Creates its own tables, handles errors, auto-repairs.
 */

if (!defined('ABSPATH')) exit;

class MicroHub_Tracking {

    private static $table_verified = false;

    public function init() {
        // Record page view on frontend
        add_action('wp_footer', array($this, 'record_page_view'));

        // AJAX endpoints
        add_action('wp_ajax_mh_track_event', array($this, 'ajax_track_event'));
        add_action('wp_ajax_nopriv_mh_track_event', array($this, 'ajax_track_event'));
        add_action('wp_ajax_mh_track_duration', array($this, 'ajax_track_duration'));
        add_action('wp_ajax_nopriv_mh_track_duration', array($this, 'ajax_track_duration'));
        add_action('wp_ajax_mh_heartbeat', array($this, 'ajax_heartbeat'));
        add_action('wp_ajax_nopriv_mh_heartbeat', array($this, 'ajax_heartbeat'));

        // Enqueue tracking script
        add_action('wp_enqueue_scripts', array($this, 'enqueue_tracking_script'));

        // Daily cleanup
        add_action('mh_tracking_cleanup', array($this, 'cleanup_old_data'));
        if (!wp_next_scheduled('mh_tracking_cleanup')) {
            wp_schedule_event(time(), 'daily', 'mh_tracking_cleanup');
        }
    }

    // =========================================================================
    // Table management — self-healing, no dbDelta
    // =========================================================================

    /**
     * Ensure tracking tables exist. Uses direct CREATE TABLE, not dbDelta.
     * Called once per request, cached in static var.
     */
    private static function ensure_tables() {
        if (self::$table_verified) return true;

        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';

        // Quick check — if table exists, we're good
        $exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
        if ($exists === $table) {
            self::$table_verified = true;
            return true;
        }

        // Table doesn't exist — create all three tables
        $charset = '';
        if (!empty($wpdb->charset)) {
            $charset = "DEFAULT CHARACTER SET {$wpdb->charset}";
        }
        if (!empty($wpdb->collate)) {
            $charset .= " COLLATE {$wpdb->collate}";
        }

        // Page views table
        $wpdb->query("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}mh_page_views` (
            `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `session_id` varchar(64) NOT NULL,
            `page_url` varchar(500) NOT NULL,
            `page_title` varchar(255) DEFAULT '',
            `post_id` bigint(20) unsigned DEFAULT 0,
            `post_type` varchar(50) DEFAULT '',
            `referrer` varchar(500) DEFAULT '',
            `user_agent` varchar(500) DEFAULT '',
            `ip_hash` varchar(64) NOT NULL,
            `is_bot` tinyint(1) DEFAULT 0,
            `duration` int(11) DEFAULT 0,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_session` (`session_id`),
            KEY `idx_created` (`created_at`),
            KEY `idx_bot` (`is_bot`)
        ) {$charset}");

        // Events table
        $wpdb->query("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}mh_tracking_events` (
            `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `session_id` varchar(64) NOT NULL,
            `event_type` varchar(50) NOT NULL,
            `event_target` varchar(500) DEFAULT '',
            `event_value` varchar(255) DEFAULT '',
            `post_id` bigint(20) unsigned DEFAULT 0,
            `ip_hash` varchar(64) NOT NULL,
            `is_bot` tinyint(1) DEFAULT 0,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_session` (`session_id`),
            KEY `idx_event_type` (`event_type`),
            KEY `idx_created` (`created_at`)
        ) {$charset}");

        // Bot blocks table
        $wpdb->query("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}mh_bot_blocks` (
            `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `ip_hash` varchar(64) NOT NULL,
            `user_agent` varchar(500) DEFAULT '',
            `reason` varchar(100) NOT NULL,
            `page_url` varchar(500) DEFAULT '',
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_created` (`created_at`)
        ) {$charset}");

        // Verify the main table was created
        $verify = $wpdb->get_var("SHOW TABLES LIKE '$table'");
        if ($verify === $table) {
            self::$table_verified = true;
            update_option('mh_tracking_db_version', '2.0');
            return true;
        }

        // Table creation failed — log the error
        update_option('mh_tracking_last_error', 'Table creation failed: ' . $wpdb->last_error, false);
        return false;
    }

    // =========================================================================
    // Frontend tracking
    // =========================================================================

    public function enqueue_tracking_script() {
        if (is_admin()) return;

        wp_enqueue_script(
            'microhub-tracking',
            MICROHUB_PLUGIN_URL . 'assets/js/tracking.js',
            array('jquery'),
            MICROHUB_VERSION,
            true
        );

        $post_id = 0;
        $post_type = '';
        if (is_singular()) {
            global $post;
            if ($post) {
                $post_id = $post->ID;
                $post_type = $post->post_type;
            }
        }

        wp_localize_script('microhub-tracking', 'mhTracking', array(
            'ajaxurl'   => admin_url('admin-ajax.php'),
            'nonce'     => wp_create_nonce('mh_tracking_nonce'),
            'postId'    => $post_id,
            'postType'  => $post_type,
            'sessionId' => $this->get_session_id(),
        ));
    }

    private function get_session_id() {
        if (isset($_COOKIE['mh_sid'])) {
            return sanitize_text_field($_COOKIE['mh_sid']);
        }
        $sid = wp_generate_password(32, false);
        if (!headers_sent()) {
            setcookie('mh_sid', $sid, time() + 1800, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
        }
        return $sid;
    }

    private function hash_ip($ip) {
        $salt = defined('AUTH_SALT') ? AUTH_SALT : 'mh_default_salt';
        return hash('sha256', $ip . $salt . date('Y-m'));
    }

    private function get_visitor_ip() {
        $headers = array('HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR');
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        return '0.0.0.0';
    }

    /**
     * Simple bot check — no dependency on MicroHub_Bot_Guard
     */
    private static function is_bot($ua) {
        if (empty($ua)) return true;
        $ua = strtolower($ua);
        $bots = array('bot', 'crawl', 'spider', 'slurp', 'scraper', 'fetch',
            'curl', 'wget', 'python', 'httpx', 'go-http', 'java/',
            'phantomjs', 'headlesschrome', 'selenium', 'puppeteer');
        foreach ($bots as $b) {
            if (strpos($ua, $b) !== false) {
                // Allow known good search engine bots
                $good = array('googlebot', 'bingbot', 'duckduckbot', 'applebot');
                foreach ($good as $g) {
                    if (strpos($ua, $g) !== false) return false;
                }
                return true;
            }
        }
        return false;
    }

    /**
     * Record a page view — the core tracking function
     */
    public function record_page_view() {
        if (is_admin()) return;

        // Ensure tables exist (auto-creates if needed)
        if (!self::ensure_tables()) return;

        global $wpdb, $post;

        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '';
        $page_url = isset($_SERVER['REQUEST_URI']) ? esc_url_raw($_SERVER['REQUEST_URI']) : '';
        $referrer = isset($_SERVER['HTTP_REFERER']) ? esc_url_raw($_SERVER['HTTP_REFERER']) : '';

        $table = $wpdb->prefix . 'mh_page_views';
        $result = $wpdb->query($wpdb->prepare(
            "INSERT INTO `$table` (session_id, page_url, page_title, post_id, post_type, referrer, user_agent, ip_hash, is_bot, duration)
             VALUES (%s, %s, %s, %d, %s, %s, %s, %s, %d, %d)",
            $this->get_session_id(),
            substr($page_url, 0, 500),
            substr(is_singular() && $post ? $post->post_title : wp_title('', false), 0, 255),
            is_singular() && $post ? $post->ID : 0,
            is_singular() && $post ? $post->post_type : '',
            substr($referrer, 0, 500),
            substr($ua, 0, 500),
            $this->hash_ip($this->get_visitor_ip()),
            self::is_bot($ua) ? 1 : 0,
            0
        ));

        // If direct INSERT failed, try without is_bot column (in case of old table schema)
        if ($result === false) {
            $wpdb->query($wpdb->prepare(
                "INSERT INTO `$table` (session_id, page_url, page_title, post_id, post_type, referrer, user_agent, ip_hash, duration)
                 VALUES (%s, %s, %s, %d, %s, %s, %s, %s, %d)",
                $this->get_session_id(),
                substr($page_url, 0, 500),
                substr(is_singular() && $post ? $post->post_title : wp_title('', false), 0, 255),
                is_singular() && $post ? $post->ID : 0,
                is_singular() && $post ? $post->post_type : '',
                substr($referrer, 0, 500),
                substr($ua, 0, 500),
                $this->hash_ip($this->get_visitor_ip()),
                0
            ));
        }
    }

    // =========================================================================
    // AJAX handlers
    // =========================================================================

    public function ajax_track_event() {
        check_ajax_referer('mh_tracking_nonce', 'nonce');
        if (!self::ensure_tables()) { wp_send_json_error('DB unavailable'); }

        global $wpdb;

        $session_id   = isset($_POST['session_id']) && is_string($_POST['session_id']) ? sanitize_text_field($_POST['session_id']) : '';
        $event_type   = isset($_POST['event_type']) && is_string($_POST['event_type']) ? sanitize_text_field($_POST['event_type']) : '';
        $event_target = isset($_POST['event_target']) && is_string($_POST['event_target']) ? sanitize_text_field($_POST['event_target']) : '';
        $event_value  = isset($_POST['event_value']) && is_string($_POST['event_value']) ? sanitize_text_field($_POST['event_value']) : '';
        $post_id      = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;

        if (empty($session_id) || empty($event_type)) {
            wp_send_json_error('Missing data');
        }

        $allowed = array('tag_click','link_click','outbound_link','search','filter_change',
            'paper_view','protocol_view','discussion_view','download','chat_open','pagination');
        if (!in_array($event_type, $allowed)) {
            wp_send_json_error('Invalid event type');
        }

        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '';
        $table = $wpdb->prefix . 'mh_tracking_events';
        $wpdb->query($wpdb->prepare(
            "INSERT INTO `$table` (session_id, event_type, event_target, event_value, post_id, ip_hash, is_bot)
             VALUES (%s, %s, %s, %s, %d, %s, %d)",
            $session_id,
            $event_type,
            substr($event_target, 0, 500),
            substr($event_value, 0, 255),
            $post_id,
            $this->hash_ip($this->get_visitor_ip()),
            self::is_bot($ua) ? 1 : 0
        ));

        wp_send_json_success();
    }

    public function ajax_track_duration() {
        check_ajax_referer('mh_tracking_nonce', 'nonce');

        global $wpdb;

        $session_id = isset($_POST['session_id']) && is_string($_POST['session_id']) ? sanitize_text_field($_POST['session_id']) : '';
        $duration   = isset($_POST['duration']) ? absint($_POST['duration']) : 0;
        $page_url   = isset($_POST['page_url']) && is_string($_POST['page_url']) ? esc_url_raw($_POST['page_url']) : '';

        if (empty($session_id) || $duration < 1) {
            wp_send_json_error('Missing data');
        }

        $duration = min($duration, 1800);
        $table = $wpdb->prefix . 'mh_page_views';
        $wpdb->query($wpdb->prepare(
            "UPDATE `$table` SET duration = %d WHERE session_id = %s AND page_url = %s ORDER BY id DESC LIMIT 1",
            $duration, $session_id, $page_url
        ));

        wp_send_json_success();
    }

    public function ajax_heartbeat() {
        check_ajax_referer('mh_tracking_nonce', 'nonce');
        wp_send_json_success(array('alive' => true));
    }

    // =========================================================================
    // Cleanup
    // =========================================================================

    public function cleanup_old_data() {
        global $wpdb;
        $cutoff = date('Y-m-d H:i:s', strtotime('-90 days'));
        $wpdb->query($wpdb->prepare("DELETE FROM `{$wpdb->prefix}mh_page_views` WHERE created_at < %s", $cutoff));
        $wpdb->query($wpdb->prepare("DELETE FROM `{$wpdb->prefix}mh_tracking_events` WHERE created_at < %s", $cutoff));
        $wpdb->query($wpdb->prepare("DELETE FROM `{$wpdb->prefix}mh_bot_blocks` WHERE created_at < %s", $cutoff));
    }

    // =========================================================================
    // Query helpers for dashboard
    // =========================================================================

    public static function get_visitor_count($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        $result = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT ip_hash) FROM `$table` WHERE is_bot = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)", $days
        ));
        // If query failed (is_bot column missing), try without filter
        if ($result === null && !empty($wpdb->last_error)) {
            $result = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(DISTINCT ip_hash) FROM `$table` WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)", $days
            ));
        }
        return (int) $result;
    }

    public static function get_pageview_count($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        $result = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM `$table` WHERE is_bot = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)", $days
        ));
        if ($result === null && !empty($wpdb->last_error)) {
            $result = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM `$table` WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)", $days
            ));
        }
        return (int) $result;
    }

    public static function get_avg_duration($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return (float) $wpdb->get_var($wpdb->prepare(
            "SELECT AVG(duration) FROM `$table` WHERE duration > 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)", $days
        ));
    }

    public static function get_daily_views($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        $result = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(created_at) as date, COUNT(*) as views, COUNT(DISTINCT ip_hash) as visitors
             FROM `$table` WHERE is_bot = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY DATE(created_at) ORDER BY date ASC", $days
        ));
        if (empty($result) && !empty($wpdb->last_error)) {
            $result = $wpdb->get_results($wpdb->prepare(
                "SELECT DATE(created_at) as date, COUNT(*) as views, COUNT(DISTINCT ip_hash) as visitors
                 FROM `$table` WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
                 GROUP BY DATE(created_at) ORDER BY date ASC", $days
            ));
        }
        return $result ?: array();
    }

    public static function get_top_pages($days = 30, $limit = 20) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT page_url, page_title, COUNT(*) as views, COUNT(DISTINCT ip_hash) as visitors, AVG(duration) as avg_duration
             FROM `$table` WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY page_url, page_title ORDER BY views DESC LIMIT %d", $days, $limit
        )) ?: array();
    }

    public static function get_top_referrers($days = 30, $limit = 20) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT referrer, COUNT(*) as visits
             FROM `$table` WHERE referrer != '' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY referrer ORDER BY visits DESC LIMIT %d", $days, $limit
        )) ?: array();
    }

    public static function get_tag_usage($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_value, COUNT(*) as clicks
             FROM `$table` WHERE event_type = 'tag_click' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_value ORDER BY clicks DESC LIMIT %d", $days, $limit
        )) ?: array();
    }

    public static function get_link_clicks($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_target, event_value, COUNT(*) as clicks
             FROM `$table` WHERE event_type IN ('link_click','outbound_link') AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_target, event_value ORDER BY clicks DESC LIMIT %d", $days, $limit
        )) ?: array();
    }

    public static function get_search_queries($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_value, COUNT(*) as count
             FROM `$table` WHERE event_type = 'search' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_value ORDER BY count DESC LIMIT %d", $days, $limit
        )) ?: array();
    }

    public static function get_filter_usage($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_target as filter_name, event_value, COUNT(*) as count
             FROM `$table` WHERE event_type = 'filter_change' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_target, event_value ORDER BY count DESC LIMIT %d", $days, $limit
        )) ?: array();
    }

    public static function get_bot_stats($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_bot_blocks';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT reason, COUNT(*) as blocks
             FROM `$table` WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY reason ORDER BY blocks DESC", $days
        )) ?: array();
    }

    public static function get_total_bot_blocks($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_bot_blocks';
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM `$table` WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)", $days
        ));
    }

    // =========================================================================
    // Diagnostics
    // =========================================================================

    public static function get_table_diagnostics() {
        global $wpdb;
        $info = array();

        $table = $wpdb->prefix . 'mh_page_views';
        $info['table_exists'] = ($wpdb->get_var("SHOW TABLES LIKE '$table'") === $table);
        $info['db_version'] = get_option('mh_tracking_db_version', '(not set)');
        $info['last_error'] = get_option('mh_tracking_last_error', '(none)');
        $info['total_rows'] = 0;
        $info['human_rows'] = 0;
        $info['bot_rows'] = 0;
        $info['columns'] = array();
        $info['create_error'] = '';

        if ($info['table_exists']) {
            $info['total_rows'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$table`");
            $info['human_rows'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$table` WHERE is_bot = 0");
            $info['bot_rows'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$table` WHERE is_bot = 1");
            $cols = $wpdb->get_results("SHOW COLUMNS FROM `$table`");
            if ($cols) {
                foreach ($cols as $col) {
                    $info['columns'][] = $col->Field;
                }
            }
        } else {
            // Try to create it now and report what happens
            $charset = '';
            if (!empty($wpdb->charset)) $charset = "DEFAULT CHARACTER SET {$wpdb->charset}";
            if (!empty($wpdb->collate)) $charset .= " COLLATE {$wpdb->collate}";

            $wpdb->query("CREATE TABLE IF NOT EXISTS `$table` (
                `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                `session_id` varchar(64) NOT NULL,
                `page_url` varchar(500) NOT NULL,
                `page_title` varchar(255) DEFAULT '',
                `post_id` bigint(20) unsigned DEFAULT 0,
                `post_type` varchar(50) DEFAULT '',
                `referrer` varchar(500) DEFAULT '',
                `user_agent` varchar(500) DEFAULT '',
                `ip_hash` varchar(64) NOT NULL,
                `is_bot` tinyint(1) DEFAULT 0,
                `duration` int(11) DEFAULT 0,
                `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `idx_created` (`created_at`)
            ) {$charset}");

            if ($wpdb->last_error) {
                $info['create_error'] = $wpdb->last_error;
            } else {
                // Check if it worked
                $verify = $wpdb->get_var("SHOW TABLES LIKE '$table'");
                if ($verify === $table) {
                    $info['table_exists'] = true;
                    $info['create_error'] = 'Table was just created successfully!';
                } else {
                    $info['create_error'] = 'CREATE TABLE ran without error but table still not found';
                }
            }
        }

        return $info;
    }

    /**
     * Force create/recreate tables — called from diagnostics
     */
    public static function force_create_tables() {
        self::$table_verified = false;
        return self::ensure_tables();
    }
}
