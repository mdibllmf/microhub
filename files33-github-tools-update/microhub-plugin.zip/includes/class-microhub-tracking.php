<?php
/**
 * MicroHub Visitor Tracking v3.10
 *
 * SIMPLIFIED — all validation/blocking removed to debug why tracking fails.
 * Records page views, session duration, and interaction events.
 * Privacy-friendly: IPs are hashed, no personal data stored.
 */

if (!defined('ABSPATH')) exit;

class MicroHub_Tracking {

    public function init() {
        // AJAX endpoints (legacy — admin-ajax.php)
        add_action('wp_ajax_mh_track_pageview', array($this, 'ajax_track_pageview'));
        add_action('wp_ajax_nopriv_mh_track_pageview', array($this, 'ajax_track_pageview'));
        add_action('wp_ajax_mh_track_event', array($this, 'ajax_track_event'));
        add_action('wp_ajax_nopriv_mh_track_event', array($this, 'ajax_track_event'));
        add_action('wp_ajax_mh_track_duration', array($this, 'ajax_track_duration'));
        add_action('wp_ajax_nopriv_mh_track_duration', array($this, 'ajax_track_duration'));

        // REST API endpoints (primary — bypasses admin-ajax.php)
        add_action('rest_api_init', array($this, 'register_rest_routes'));

        // Enqueue tracking script
        add_action('wp_enqueue_scripts', array($this, 'enqueue_tracking_script'));

        // Daily cleanup
        add_action('mh_tracking_cleanup', array($this, 'cleanup_old_data'));
        if (!wp_next_scheduled('mh_tracking_cleanup')) {
            wp_schedule_event(time(), 'daily', 'mh_tracking_cleanup');
        }
    }

    /**
     * Register REST API routes
     */
    public function register_rest_routes() {
        register_rest_route('microhub/v1', '/track/pageview', array(
            'methods'  => 'POST',
            'callback' => array($this, 'rest_track_pageview'),
            'permission_callback' => '__return_true',
        ));
        register_rest_route('microhub/v1', '/track/event', array(
            'methods'  => 'POST',
            'callback' => array($this, 'rest_track_event'),
            'permission_callback' => '__return_true',
        ));
        register_rest_route('microhub/v1', '/track/duration', array(
            'methods'  => 'POST',
            'callback' => array($this, 'rest_track_duration'),
            'permission_callback' => '__return_true',
        ));
    }

    /**
     * Enqueue tracking script
     */
    public function enqueue_tracking_script() {
        if (is_admin()) return;

        wp_enqueue_script(
            'microhub-tracking',
            MICROHUB_PLUGIN_URL . 'assets/js/tracking.js',
            array(),
            MICROHUB_VERSION,
            true
        );

        $post_id = 0;
        $post_type = '';
        if (is_singular()) {
            global $post;
            if ($post) {
                $post_id = $post->ID;
                $post_type = $post->post_type;
            }
        }

        wp_localize_script('microhub-tracking', 'mhTracking', array(
            'ajaxurl'   => admin_url('admin-ajax.php'),
            'restUrl'   => rest_url('microhub/v1/track'),
            'postId'    => $post_id,
            'postType'  => $post_type,
        ));
    }

    // =========================================================================
    // REST API handlers (PRIMARY — no token, no bot check, minimal validation)
    // =========================================================================

    public function rest_track_pageview($request) {
        global $wpdb;

        $session_id = sanitize_text_field($request->get_param('session_id') ?? '');
        $page_url   = sanitize_text_field($request->get_param('page_url') ?? '');
        $page_title = sanitize_text_field($request->get_param('page_title') ?? '');
        $post_id    = absint($request->get_param('post_id') ?? 0);
        $post_type  = sanitize_text_field($request->get_param('post_type') ?? '');
        $referrer   = sanitize_text_field($request->get_param('referrer') ?? '');

        if (empty($session_id)) {
            $session_id = 'anon_' . substr(md5(microtime()), 0, 16);
        }
        if (empty($page_url)) {
            $page_url = '/';
        }

        $ip = $this->get_visitor_ip();
        $ip_hash = $this->hash_ip($ip);
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT']), 0, 500) : '';

        $table = $wpdb->prefix . 'mh_page_views';
        $result = $wpdb->insert($table, array(
            'session_id' => $session_id,
            'page_url'   => substr($page_url, 0, 500),
            'page_title' => substr($page_title, 0, 255),
            'post_id'    => $post_id,
            'post_type'  => $post_type,
            'referrer'   => substr($referrer, 0, 500),
            'user_agent' => $ua,
            'ip_hash'    => $ip_hash,
            'is_bot'     => 0,
            'duration'   => 0,
        ), array('%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%d'));

        if ($result === false) {
            return new WP_REST_Response(array(
                'success' => false,
                'data'    => 'DB insert failed: ' . $wpdb->last_error,
                'table'   => $table,
            ), 500);
        }

        return new WP_REST_Response(array('success' => true, 'data' => array('recorded' => true, 'id' => $wpdb->insert_id)));
    }

    public function rest_track_event($request) {
        global $wpdb;

        $session_id   = sanitize_text_field($request->get_param('session_id') ?? '');
        $event_type   = sanitize_text_field($request->get_param('event_type') ?? '');
        $event_target = sanitize_text_field($request->get_param('event_target') ?? '');
        $event_value  = sanitize_text_field($request->get_param('event_value') ?? '');
        $post_id      = absint($request->get_param('post_id') ?? 0);

        if (empty($session_id) || empty($event_type)) {
            return new WP_REST_Response(array('success' => false, 'data' => 'Missing session_id or event_type'), 400);
        }

        $ip = $this->get_visitor_ip();
        $ip_hash = $this->hash_ip($ip);

        $table = $wpdb->prefix . 'mh_tracking_events';
        $wpdb->insert($table, array(
            'session_id'   => $session_id,
            'event_type'   => $event_type,
            'event_target' => substr($event_target, 0, 500),
            'event_value'  => substr($event_value, 0, 255),
            'post_id'      => $post_id,
            'ip_hash'      => $ip_hash,
            'is_bot'       => 0,
        ), array('%s', '%s', '%s', '%s', '%d', '%s', '%d'));

        return new WP_REST_Response(array('success' => true));
    }

    public function rest_track_duration($request) {
        global $wpdb;

        $session_id = sanitize_text_field($request->get_param('session_id') ?? '');
        $duration   = absint($request->get_param('duration') ?? 0);
        $page_url   = sanitize_text_field($request->get_param('page_url') ?? '');

        if (empty($session_id) || $duration < 1) {
            return new WP_REST_Response(array('success' => false, 'data' => 'Missing data'), 400);
        }

        $duration = min($duration, 1800);

        $table = $wpdb->prefix . 'mh_page_views';
        $wpdb->query($wpdb->prepare(
            "UPDATE $table SET duration = %d WHERE session_id = %s AND page_url = %s ORDER BY id DESC LIMIT 1",
            $duration, $session_id, $page_url
        ));

        return new WP_REST_Response(array('success' => true));
    }

    // =========================================================================
    // AJAX handlers (FALLBACK — same logic, no token, no bot check)
    // =========================================================================

    public function ajax_track_pageview() {
        global $wpdb;

        $session_id = sanitize_text_field($_POST['session_id'] ?? '');
        $page_url   = sanitize_text_field($_POST['page_url'] ?? '');
        $page_title = sanitize_text_field($_POST['page_title'] ?? '');
        $post_id    = absint($_POST['post_id'] ?? 0);
        $post_type  = sanitize_text_field($_POST['post_type'] ?? '');
        $referrer   = sanitize_text_field($_POST['referrer'] ?? '');

        if (empty($session_id)) {
            $session_id = 'anon_' . substr(md5(microtime()), 0, 16);
        }
        if (empty($page_url)) {
            $page_url = '/';
        }

        $ip = $this->get_visitor_ip();
        $ip_hash = $this->hash_ip($ip);
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT']), 0, 500) : '';

        $table = $wpdb->prefix . 'mh_page_views';
        $result = $wpdb->insert($table, array(
            'session_id' => $session_id,
            'page_url'   => substr($page_url, 0, 500),
            'page_title' => substr($page_title, 0, 255),
            'post_id'    => $post_id,
            'post_type'  => $post_type,
            'referrer'   => substr($referrer, 0, 500),
            'user_agent' => $ua,
            'ip_hash'    => $ip_hash,
            'is_bot'     => 0,
            'duration'   => 0,
        ), array('%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%d'));

        if ($result === false) {
            wp_send_json_error('DB error: ' . $wpdb->last_error);
        }

        wp_send_json_success(array('recorded' => true, 'id' => $wpdb->insert_id));
    }

    public function ajax_track_event() {
        global $wpdb;

        $session_id   = sanitize_text_field($_POST['session_id'] ?? '');
        $event_type   = sanitize_text_field($_POST['event_type'] ?? '');
        $event_target = sanitize_text_field($_POST['event_target'] ?? '');
        $event_value  = sanitize_text_field($_POST['event_value'] ?? '');
        $post_id      = absint($_POST['post_id'] ?? 0);

        if (empty($session_id) || empty($event_type)) {
            wp_send_json_error('Missing data');
        }

        $ip = $this->get_visitor_ip();
        $ip_hash = $this->hash_ip($ip);

        $table = $wpdb->prefix . 'mh_tracking_events';
        $wpdb->insert($table, array(
            'session_id'   => $session_id,
            'event_type'   => $event_type,
            'event_target' => substr($event_target, 0, 500),
            'event_value'  => substr($event_value, 0, 255),
            'post_id'      => $post_id,
            'ip_hash'      => $ip_hash,
            'is_bot'       => 0,
        ), array('%s', '%s', '%s', '%s', '%d', '%s', '%d'));

        wp_send_json_success();
    }

    public function ajax_track_duration() {
        global $wpdb;

        $session_id = sanitize_text_field($_POST['session_id'] ?? '');
        $duration   = absint($_POST['duration'] ?? 0);
        $page_url   = sanitize_text_field($_POST['page_url'] ?? '');

        if (empty($session_id) || $duration < 1) {
            wp_send_json_error('Missing data');
        }

        $duration = min($duration, 1800);

        $table = $wpdb->prefix . 'mh_page_views';
        $wpdb->query($wpdb->prepare(
            "UPDATE $table SET duration = %d WHERE session_id = %s AND page_url = %s ORDER BY id DESC LIMIT 1",
            $duration, $session_id, $page_url
        ));

        wp_send_json_success();
    }

    // =========================================================================
    // Stub for wp_footer (disabled — client-side JS handles everything)
    // =========================================================================

    public function record_page_view() {
        return;
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    private function hash_ip($ip) {
        $salt = defined('AUTH_SALT') ? AUTH_SALT : 'mh_default_salt';
        return hash('sha256', $ip . $salt . date('Y-m'));
    }

    private function get_visitor_ip() {
        $headers = array('HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR');
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        return '0.0.0.0';
    }

    public function cleanup_old_data() {
        global $wpdb;
        $cutoff = date('Y-m-d H:i:s', strtotime('-90 days'));
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}mh_page_views WHERE created_at < %s", $cutoff));
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}mh_tracking_events WHERE created_at < %s", $cutoff));
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}mh_bot_blocks WHERE created_at < %s", $cutoff));
    }

    // =========================================================================
    // Query helpers for admin dashboard
    // =========================================================================

    public static function get_visitor_count($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT ip_hash) FROM $table WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)", $days
        ));
    }

    public static function get_pageview_count($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)", $days
        ));
    }

    public static function get_avg_duration($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return (float) $wpdb->get_var($wpdb->prepare(
            "SELECT AVG(duration) FROM $table WHERE duration > 0 AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)", $days
        ));
    }

    public static function get_daily_views($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(created_at) as date, COUNT(*) as views, COUNT(DISTINCT ip_hash) as visitors
             FROM $table WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY DATE(created_at) ORDER BY date ASC", $days
        ));
    }

    public static function get_top_pages($days = 30, $limit = 20) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT page_url, page_title, COUNT(*) as views, COUNT(DISTINCT ip_hash) as visitors, AVG(duration) as avg_duration
             FROM $table WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY page_url, page_title ORDER BY views DESC LIMIT %d", $days, $limit
        ));
    }

    public static function get_top_referrers($days = 30, $limit = 20) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_page_views';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT referrer, COUNT(*) as visits
             FROM $table WHERE referrer != '' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY referrer ORDER BY visits DESC LIMIT %d", $days, $limit
        ));
    }

    public static function get_tag_usage($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_value, COUNT(*) as clicks
             FROM $table WHERE event_type = 'tag_click' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_value ORDER BY clicks DESC LIMIT %d", $days, $limit
        ));
    }

    public static function get_link_clicks($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_target, event_value, COUNT(*) as clicks
             FROM $table WHERE event_type IN ('link_click','outbound_link') AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_target, event_value ORDER BY clicks DESC LIMIT %d", $days, $limit
        ));
    }

    public static function get_search_queries($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_value, COUNT(*) as count
             FROM $table WHERE event_type = 'search' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_value ORDER BY count DESC LIMIT %d", $days, $limit
        ));
    }

    public static function get_filter_usage($days = 30, $limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_tracking_events';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT event_target as filter_name, event_value, COUNT(*) as count
             FROM $table WHERE event_type = 'filter_change' AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY event_target, event_value ORDER BY count DESC LIMIT %d", $days, $limit
        ));
    }

    public static function get_bot_stats($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_bot_blocks';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT reason, COUNT(*) as blocks FROM $table WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY reason ORDER BY blocks DESC", $days
        ));
    }

    public static function get_total_bot_blocks($days = 30) {
        global $wpdb;
        $table = $wpdb->prefix . 'mh_bot_blocks';
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)", $days
        ));
    }
}
