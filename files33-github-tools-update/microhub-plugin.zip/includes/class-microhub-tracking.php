<?php
/**
 * MicroHub Visitor Tracking — wp_options storage
 *
 * Uses ONLY WordPress core tables (wp_options + wp_postmeta).
 * NO custom tables. Works on any hosting, even "Database is limited" environments.
 *
 * Storage format:
 *   wp_options: mh_stats_YYYY-MM-DD => serialized daily aggregate
 *   wp_postmeta: _mh_view_count => total views per post
 */

if (!defined('ABSPATH')) exit;

class MicroHub_Tracking {

    public function init() {
        // Record page view on frontend
        add_action('wp_footer', array($this, 'record_page_view'));

        // AJAX endpoints
        add_action('wp_ajax_mh_track_event', array($this, 'ajax_track_event'));
        add_action('wp_ajax_nopriv_mh_track_event', array($this, 'ajax_track_event'));
        add_action('wp_ajax_mh_track_duration', array($this, 'ajax_track_duration'));
        add_action('wp_ajax_nopriv_mh_track_duration', array($this, 'ajax_track_duration'));
        add_action('wp_ajax_mh_heartbeat', array($this, 'ajax_heartbeat'));
        add_action('wp_ajax_nopriv_mh_heartbeat', array($this, 'ajax_heartbeat'));

        // Enqueue tracking script
        add_action('wp_enqueue_scripts', array($this, 'enqueue_tracking_script'));

        // Daily cleanup
        add_action('mh_tracking_cleanup', array($this, 'cleanup_old_data'));
        if (!wp_next_scheduled('mh_tracking_cleanup')) {
            wp_schedule_event(time(), 'daily', 'mh_tracking_cleanup');
        }
    }

    // =========================================================================
    // Daily stats storage — one wp_option per day
    // =========================================================================

    /**
     * Get today's stats array from wp_options (or empty default)
     */
    private static function get_day_stats($date = null) {
        if ($date === null) $date = current_time('Y-m-d');
        $key = 'mh_stats_' . $date;
        $stats = get_option($key, false);
        if ($stats === false || !is_array($stats)) {
            $stats = array(
                'views'     => 0,
                'visitors'  => array(),
                'pages'     => array(),
                'referrers' => array(),
                'events'    => array(),
                'bot_blocks'=> array(),
            );
        }
        return $stats;
    }

    /**
     * Save today's stats
     */
    private static function save_day_stats($stats, $date = null) {
        if ($date === null) $date = current_time('Y-m-d');
        $key = 'mh_stats_' . $date;
        // Use update_option with autoload=no to avoid loading all days into memory
        update_option($key, $stats, false);
    }

    // =========================================================================
    // Frontend tracking
    // =========================================================================

    public function enqueue_tracking_script() {
        if (is_admin()) return;

        wp_enqueue_script(
            'microhub-tracking',
            MICROHUB_PLUGIN_URL . 'assets/js/tracking.js',
            array('jquery'),
            MICROHUB_VERSION,
            true
        );

        $post_id = 0;
        $post_type = '';
        if (is_singular()) {
            global $post;
            if ($post) {
                $post_id = $post->ID;
                $post_type = $post->post_type;
            }
        }

        wp_localize_script('microhub-tracking', 'mhTracking', array(
            'ajaxurl'   => admin_url('admin-ajax.php'),
            'nonce'     => wp_create_nonce('mh_tracking_nonce'),
            'postId'    => $post_id,
            'postType'  => $post_type,
            'sessionId' => $this->get_session_id(),
        ));
    }

    private function get_session_id() {
        if (isset($_COOKIE['mh_sid'])) {
            return sanitize_text_field($_COOKIE['mh_sid']);
        }
        $sid = wp_generate_password(32, false);
        if (!headers_sent()) {
            setcookie('mh_sid', $sid, time() + 1800, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
        }
        return $sid;
    }

    private function hash_ip($ip) {
        $salt = defined('AUTH_SALT') ? AUTH_SALT : 'mh_default_salt';
        return substr(hash('sha256', $ip . $salt . date('Y-m')), 0, 16);
    }

    private function get_visitor_ip() {
        $headers = array('HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR');
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        return '0.0.0.0';
    }

    /**
     * Simple bot check — standalone, no external dependency
     */
    private static function is_bot($ua) {
        if (empty($ua)) return true;
        $ua = strtolower($ua);

        // Allow known good bots
        $good = array('googlebot', 'bingbot', 'duckduckbot', 'applebot', 'yandexbot');
        foreach ($good as $g) {
            if (strpos($ua, $g) !== false) return false;
        }

        // Block known bad patterns
        $bots = array('bot', 'crawl', 'spider', 'slurp', 'scraper', 'fetch',
            'curl', 'wget', 'python', 'httpx', 'go-http', 'java/',
            'phantomjs', 'headlesschrome', 'selenium', 'puppeteer');
        foreach ($bots as $b) {
            if (strpos($ua, $b) !== false) return true;
        }
        return false;
    }

    /**
     * Record a page view — writes to wp_options daily aggregate
     */
    public function record_page_view() {
        if (is_admin()) return;

        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';

        // Skip bots
        if (self::is_bot($ua)) return;

        global $post;

        $page_url = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field($_SERVER['REQUEST_URI']) : '/';
        $referrer = isset($_SERVER['HTTP_REFERER']) ? esc_url_raw($_SERVER['HTTP_REFERER']) : '';
        $ip_hash = $this->hash_ip($this->get_visitor_ip());
        $page_title = '';
        $post_id = 0;

        if (is_singular() && $post) {
            $page_title = $post->post_title;
            $post_id = $post->ID;
        } else {
            $page_title = wp_title('', false);
        }

        // Truncate
        $page_url = substr($page_url, 0, 200);
        $page_title = substr($page_title, 0, 100);

        // Get today's stats and update
        $stats = self::get_day_stats();
        $stats['views']++;
        $stats['visitors'][$ip_hash] = 1;

        // Page-level tracking
        if (!isset($stats['pages'][$page_url])) {
            $stats['pages'][$page_url] = array(
                'title' => $page_title,
                'views' => 0,
                'duration_sum' => 0,
                'duration_count' => 0,
            );
        }
        $stats['pages'][$page_url]['views']++;

        // Referrer tracking (store domain only)
        if (!empty($referrer)) {
            $ref_host = wp_parse_url($referrer, PHP_URL_HOST);
            if ($ref_host && $ref_host !== wp_parse_url(home_url(), PHP_URL_HOST)) {
                if (!isset($stats['referrers'][$ref_host])) {
                    $stats['referrers'][$ref_host] = 0;
                }
                $stats['referrers'][$ref_host]++;
            }
        }

        self::save_day_stats($stats);

        // Also update post meta view count
        if ($post_id > 0) {
            $count = (int) get_post_meta($post_id, '_mh_view_count', true);
            update_post_meta($post_id, '_mh_view_count', $count + 1);
        }

        // Mark tracking as active
        update_option('mh_tracking_active', time(), false);
    }

    // =========================================================================
    // AJAX handlers
    // =========================================================================

    public function ajax_track_event() {
        check_ajax_referer('mh_tracking_nonce', 'nonce');

        $event_type   = isset($_POST['event_type']) && is_string($_POST['event_type']) ? sanitize_text_field($_POST['event_type']) : '';
        $event_target = isset($_POST['event_target']) && is_string($_POST['event_target']) ? sanitize_text_field($_POST['event_target']) : '';
        $event_value  = isset($_POST['event_value']) && is_string($_POST['event_value']) ? sanitize_text_field($_POST['event_value']) : '';

        if (empty($event_type)) {
            wp_send_json_error('Missing event type');
        }

        $allowed = array('tag_click','link_click','outbound_link','search','filter_change',
            'paper_view','protocol_view','discussion_view','download','chat_open','pagination');
        if (!in_array($event_type, $allowed)) {
            wp_send_json_error('Invalid event type');
        }

        // Skip bot events
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        if (self::is_bot($ua)) {
            wp_send_json_success();
            return;
        }

        $event_value = substr($event_value, 0, 100);
        $event_target = substr($event_target, 0, 200);

        $stats = self::get_day_stats();
        if (!isset($stats['events'][$event_type])) {
            $stats['events'][$event_type] = array();
        }

        $ev_key = !empty($event_value) ? $event_value : $event_target;
        $ev_key = substr($ev_key, 0, 100);
        if (empty($ev_key)) $ev_key = '(none)';

        if (!isset($stats['events'][$event_type][$ev_key])) {
            $stats['events'][$event_type][$ev_key] = 0;
        }
        $stats['events'][$event_type][$ev_key]++;

        // For link clicks, also store the target URL
        if (in_array($event_type, array('link_click', 'outbound_link')) && !empty($event_target)) {
            $link_key = 'link_targets';
            if (!isset($stats[$link_key])) $stats[$link_key] = array();
            $link_label = !empty($event_value) ? $event_value : substr($event_target, 0, 80);
            $stats[$link_key][$event_target] = array(
                'label' => $link_label,
                'clicks' => isset($stats[$link_key][$event_target]['clicks'])
                    ? $stats[$link_key][$event_target]['clicks'] + 1
                    : 1,
            );
        }

        self::save_day_stats($stats);
        wp_send_json_success();
    }

    public function ajax_track_duration() {
        check_ajax_referer('mh_tracking_nonce', 'nonce');

        $duration = isset($_POST['duration']) ? absint($_POST['duration']) : 0;
        $page_url = isset($_POST['page_url']) && is_string($_POST['page_url']) ? sanitize_text_field($_POST['page_url']) : '';

        if ($duration < 1 || empty($page_url)) {
            wp_send_json_error('Missing data');
        }

        $duration = min($duration, 1800);
        $page_url = substr($page_url, 0, 200);

        $stats = self::get_day_stats();
        if (isset($stats['pages'][$page_url])) {
            $stats['pages'][$page_url]['duration_sum'] += $duration;
            $stats['pages'][$page_url]['duration_count']++;
        }
        self::save_day_stats($stats);

        wp_send_json_success();
    }

    public function ajax_heartbeat() {
        check_ajax_referer('mh_tracking_nonce', 'nonce');
        wp_send_json_success(array('alive' => true));
    }

    // =========================================================================
    // Bot block logging (called by MicroHub_Bot_Guard)
    // =========================================================================

    public static function log_bot_block($reason) {
        $stats = self::get_day_stats();
        if (!isset($stats['bot_blocks'][$reason])) {
            $stats['bot_blocks'][$reason] = 0;
        }
        $stats['bot_blocks'][$reason]++;
        self::save_day_stats($stats);
    }

    // =========================================================================
    // Cleanup — remove stats older than 90 days
    // =========================================================================

    public function cleanup_old_data() {
        global $wpdb;
        $cutoff = date('Y-m-d', strtotime('-90 days'));
        // Delete all mh_stats_ options older than cutoff
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name < %s",
            'mh_stats_%',
            'mh_stats_' . $cutoff
        ));
    }

    // =========================================================================
    // Query helpers for dashboard — aggregate across date-keyed options
    // =========================================================================

    /**
     * Get all daily stats for a date range
     */
    private static function get_range_stats($days = 30) {
        global $wpdb;
        $start = date('Y-m-d', strtotime("-{$days} days"));

        // Fetch all mh_stats_ options in range
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT option_name, option_value FROM {$wpdb->options}
             WHERE option_name LIKE %s AND option_name >= %s
             ORDER BY option_name ASC",
            'mh_stats_%',
            'mh_stats_' . $start
        ));

        $all = array();
        if ($rows) {
            foreach ($rows as $row) {
                $date = str_replace('mh_stats_', '', $row->option_name);
                $data = maybe_unserialize($row->option_value);
                if (is_array($data)) {
                    $all[$date] = $data;
                }
            }
        }
        return $all;
    }

    public static function get_visitor_count($days = 30) {
        $range = self::get_range_stats($days);
        $all_visitors = array();
        foreach ($range as $stats) {
            if (isset($stats['visitors']) && is_array($stats['visitors'])) {
                $all_visitors += $stats['visitors'];
            }
        }
        return count($all_visitors);
    }

    public static function get_pageview_count($days = 30) {
        $range = self::get_range_stats($days);
        $total = 0;
        foreach ($range as $stats) {
            $total += isset($stats['views']) ? (int) $stats['views'] : 0;
        }
        return $total;
    }

    public static function get_avg_duration($days = 30) {
        $range = self::get_range_stats($days);
        $total_sum = 0;
        $total_count = 0;
        foreach ($range as $stats) {
            if (!isset($stats['pages']) || !is_array($stats['pages'])) continue;
            foreach ($stats['pages'] as $page) {
                if (isset($page['duration_sum']) && isset($page['duration_count'])) {
                    $total_sum += $page['duration_sum'];
                    $total_count += $page['duration_count'];
                }
            }
        }
        return $total_count > 0 ? round($total_sum / $total_count, 1) : 0;
    }

    public static function get_daily_views($days = 30) {
        $range = self::get_range_stats($days);
        $result = array();
        foreach ($range as $date => $stats) {
            $obj = new stdClass();
            $obj->date = $date;
            $obj->views = isset($stats['views']) ? (int) $stats['views'] : 0;
            $obj->visitors = isset($stats['visitors']) && is_array($stats['visitors'])
                ? count($stats['visitors']) : 0;
            $result[] = $obj;
        }
        return $result;
    }

    public static function get_top_pages($days = 30, $limit = 20) {
        $range = self::get_range_stats($days);
        $pages = array();
        $visitors_per_page = array();

        foreach ($range as $stats) {
            if (!isset($stats['pages']) || !is_array($stats['pages'])) continue;
            foreach ($stats['pages'] as $url => $data) {
                if (!isset($pages[$url])) {
                    $pages[$url] = array(
                        'title' => isset($data['title']) ? $data['title'] : '',
                        'views' => 0,
                        'duration_sum' => 0,
                        'duration_count' => 0,
                    );
                }
                $pages[$url]['views'] += isset($data['views']) ? $data['views'] : 0;
                $pages[$url]['duration_sum'] += isset($data['duration_sum']) ? $data['duration_sum'] : 0;
                $pages[$url]['duration_count'] += isset($data['duration_count']) ? $data['duration_count'] : 0;
            }
        }

        // Sort by views
        uasort($pages, function($a, $b) { return $b['views'] - $a['views']; });
        $pages = array_slice($pages, 0, $limit, true);

        $result = array();
        foreach ($pages as $url => $data) {
            $obj = new stdClass();
            $obj->page_url = $url;
            $obj->page_title = $data['title'];
            $obj->views = $data['views'];
            $obj->visitors = $data['views']; // approximate
            $obj->avg_duration = $data['duration_count'] > 0
                ? round($data['duration_sum'] / $data['duration_count']) : 0;
            $result[] = $obj;
        }
        return $result;
    }

    public static function get_top_referrers($days = 30, $limit = 20) {
        $range = self::get_range_stats($days);
        $refs = array();

        foreach ($range as $stats) {
            if (!isset($stats['referrers']) || !is_array($stats['referrers'])) continue;
            foreach ($stats['referrers'] as $domain => $count) {
                if (!isset($refs[$domain])) $refs[$domain] = 0;
                $refs[$domain] += $count;
            }
        }

        arsort($refs);
        $refs = array_slice($refs, 0, $limit, true);

        $result = array();
        foreach ($refs as $domain => $count) {
            $obj = new stdClass();
            $obj->referrer = $domain;
            $obj->visits = $count;
            $result[] = $obj;
        }
        return $result;
    }

    public static function get_tag_usage($days = 30, $limit = 30) {
        return self::get_event_stats('tag_click', $days, $limit);
    }

    public static function get_link_clicks($days = 30, $limit = 30) {
        $range = self::get_range_stats($days);
        $links = array();

        foreach ($range as $stats) {
            if (isset($stats['link_targets']) && is_array($stats['link_targets'])) {
                foreach ($stats['link_targets'] as $target => $data) {
                    if (!isset($links[$target])) {
                        $links[$target] = array('label' => $data['label'], 'clicks' => 0);
                    }
                    $links[$target]['clicks'] += $data['clicks'];
                }
            }
        }

        uasort($links, function($a, $b) { return $b['clicks'] - $a['clicks']; });
        $links = array_slice($links, 0, $limit, true);

        $result = array();
        foreach ($links as $target => $data) {
            $obj = new stdClass();
            $obj->event_target = $target;
            $obj->event_value = $data['label'];
            $obj->clicks = $data['clicks'];
            $result[] = $obj;
        }
        return $result;
    }

    public static function get_search_queries($days = 30, $limit = 30) {
        return self::get_event_stats('search', $days, $limit);
    }

    public static function get_filter_usage($days = 30, $limit = 30) {
        $range = self::get_range_stats($days);
        $filters = array();

        foreach ($range as $stats) {
            if (!isset($stats['events']['filter_change']) || !is_array($stats['events']['filter_change'])) continue;
            foreach ($stats['events']['filter_change'] as $value => $count) {
                if (!isset($filters[$value])) $filters[$value] = 0;
                $filters[$value] += $count;
            }
        }

        arsort($filters);
        $filters = array_slice($filters, 0, $limit, true);

        $result = array();
        foreach ($filters as $value => $count) {
            $obj = new stdClass();
            $obj->filter_name = 'filter';
            $obj->event_value = $value;
            $obj->count = $count;
            $result[] = $obj;
        }
        return $result;
    }

    /**
     * Generic event stats helper
     */
    private static function get_event_stats($event_type, $days = 30, $limit = 30) {
        $range = self::get_range_stats($days);
        $items = array();

        foreach ($range as $stats) {
            if (!isset($stats['events'][$event_type]) || !is_array($stats['events'][$event_type])) continue;
            foreach ($stats['events'][$event_type] as $value => $count) {
                if (!isset($items[$value])) $items[$value] = 0;
                $items[$value] += $count;
            }
        }

        arsort($items);
        $items = array_slice($items, 0, $limit, true);

        $result = array();
        foreach ($items as $value => $count) {
            $obj = new stdClass();
            $obj->event_value = $value;
            if ($event_type === 'tag_click') {
                $obj->clicks = $count;
            } else {
                $obj->count = $count;
            }
            $result[] = $obj;
        }
        return $result;
    }

    public static function get_bot_stats($days = 30) {
        $range = self::get_range_stats($days);
        $reasons = array();

        foreach ($range as $stats) {
            if (!isset($stats['bot_blocks']) || !is_array($stats['bot_blocks'])) continue;
            foreach ($stats['bot_blocks'] as $reason => $count) {
                if (!isset($reasons[$reason])) $reasons[$reason] = 0;
                $reasons[$reason] += $count;
            }
        }

        arsort($reasons);
        $result = array();
        foreach ($reasons as $reason => $count) {
            $obj = new stdClass();
            $obj->reason = $reason;
            $obj->blocks = $count;
            $result[] = $obj;
        }
        return $result;
    }

    public static function get_total_bot_blocks($days = 30) {
        $range = self::get_range_stats($days);
        $total = 0;
        foreach ($range as $stats) {
            if (!isset($stats['bot_blocks']) || !is_array($stats['bot_blocks'])) continue;
            foreach ($stats['bot_blocks'] as $count) {
                $total += $count;
            }
        }
        return $total;
    }

    // =========================================================================
    // Diagnostics
    // =========================================================================

    public static function get_table_diagnostics() {
        global $wpdb;
        $info = array();

        $info['storage_method'] = 'wp_options (no custom tables)';
        $info['tracking_active'] = get_option('mh_tracking_active', false);

        // Count how many daily stats we have
        $stat_count = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE 'mh_stats_%'"
        );
        $info['days_tracked'] = (int) $stat_count;

        // Get today's stats
        $today = self::get_day_stats();
        $info['today_views'] = isset($today['views']) ? $today['views'] : 0;
        $info['today_visitors'] = isset($today['visitors']) ? count($today['visitors']) : 0;
        $info['today_pages'] = isset($today['pages']) ? count($today['pages']) : 0;
        $info['today_events'] = 0;
        if (isset($today['events']) && is_array($today['events'])) {
            foreach ($today['events'] as $type => $vals) {
                if (is_array($vals)) {
                    $info['today_events'] += array_sum($vals);
                }
            }
        }

        // Check for old custom tables (can be cleaned up)
        $old_table = $wpdb->prefix . 'mh_page_views';
        $info['old_table_exists'] = ($wpdb->get_var("SHOW TABLES LIKE '$old_table'") === $old_table);

        return $info;
    }

    /**
     * Test write — verify wp_options is writable
     */
    public static function test_write() {
        $test_key = 'mh_tracking_test_' . time();
        $test_val = array('test' => true, 'time' => current_time('mysql'));
        update_option($test_key, $test_val, false);
        $read_back = get_option($test_key, false);
        delete_option($test_key);
        if ($read_back !== false && is_array($read_back) && isset($read_back['test'])) {
            return array('success' => true, 'message' => 'wp_options write test passed!');
        }
        return array('success' => false, 'message' => 'wp_options write test FAILED');
    }
}
