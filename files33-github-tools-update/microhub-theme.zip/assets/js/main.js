/**
 * MicroHub Theme JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const menuToggle = document.querySelector('.mh-nav-toggle');
    const navMenu = document.querySelector('.mh-nav-menu');
    
    if (menuToggle && navMenu) {
        menuToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            menuToggle.textContent = navMenu.classList.contains('active') ? '✕' : '☰';
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!menuToggle.contains(e.target) && !navMenu.contains(e.target)) {
                navMenu.classList.remove('active');
                menuToggle.textContent = '☰';
            }
        });
    }
    
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
    
    // Card hover effects
    document.querySelectorAll('.mh-card').forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-4px)';
        });
        card.addEventListener('mouseleave', function() {
            this.style.transform = '';
        });
    });
    
    // Section box toggle (click header to expand/collapse)
    document.querySelectorAll('.mh-text-section-header').forEach(header => {
        header.addEventListener('click', function() {
            const section = this.closest('.mh-text-section');
            if (section) {
                section.classList.toggle('collapsed');
            }
        });
    });
    
    // Full text highlight toggle
    const highlightToggle = document.getElementById('mh-toggle-highlights');
    const sectionsWrapper = document.getElementById('mh-full-text-content');
    
    if (highlightToggle && sectionsWrapper) {
        highlightToggle.addEventListener('click', function() {
            sectionsWrapper.classList.toggle('hide-highlights');
            const highlightOn = this.querySelector('.highlight-on');
            const highlightOff = this.querySelector('.highlight-off');
            
            if (sectionsWrapper.classList.contains('hide-highlights')) {
                highlightOn.style.display = 'none';
                highlightOff.style.display = 'inline';
            } else {
                highlightOn.style.display = 'inline';
                highlightOff.style.display = 'none';
            }
        });
    }
    
    // Expand/Collapse all sections
    const expandAllToggle = document.getElementById('mh-expand-all');
    
    if (expandAllToggle) {
        expandAllToggle.addEventListener('click', function() {
            const sections = document.querySelectorAll('.mh-text-section');
            const expandText = this.querySelector('.expand-text');
            const collapseText = this.querySelector('.collapse-text');
            
            // Check if most sections are collapsed
            const collapsedCount = document.querySelectorAll('.mh-text-section.collapsed').length;
            const shouldExpand = collapsedCount > sections.length / 2;
            
            sections.forEach(section => {
                if (shouldExpand) {
                    section.classList.remove('collapsed');
                } else {
                    section.classList.add('collapsed');
                }
            });
            
            if (shouldExpand) {
                expandText.style.display = 'none';
                collapseText.style.display = 'inline';
            } else {
                expandText.style.display = 'inline';
                collapseText.style.display = 'none';
            }
        });
    }
    
    // Highlight reference when jumping to it
    document.querySelectorAll('.mh-ref-link').forEach(link => {
        link.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId && targetId.startsWith('#ref-')) {
                const target = document.querySelector(targetId);
                if (target) {
                    target.classList.add('mh-ref-flash');
                    setTimeout(() => {
                        target.classList.remove('mh-ref-flash');
                    }, 2000);
                }
            }
        });
    });

    // ============================================
    // DISCUSSIONS: AJAX Form Handling
    // ============================================

    /**
     * Helper: show a status message near a form
     */
    function mhShowFormMessage(container, message, isError) {
        // Remove any existing messages in this container
        container.querySelectorAll('.mh-ajax-message').forEach(function(el) { el.remove(); });
        var div = document.createElement('div');
        div.className = 'mh-ajax-message';
        div.style.padding = '16px 20px';
        div.style.borderRadius = '8px';
        div.style.marginBottom = '16px';
        div.style.fontWeight = '500';
        if (isError) {
            div.style.background = '#3d1f1f';
            div.style.border = '1px solid #f85149';
            div.style.color = '#f85149';
        } else {
            div.style.background = '#1f3d2d';
            div.style.border = '1px solid #56d364';
            div.style.color = '#56d364';
        }
        div.textContent = message;
        container.insertBefore(div, container.firstChild);
    }

    /**
     * New Discussion form — AJAX submission
     * Works with forms that have: data-mh-discussion-form="new"
     * or the legacy forms with name="mh_new_discussion" submit button
     */
    function initDiscussionForms() {
        // Find all new-discussion forms (theme template and shortcode variants)
        var newDiscussionForms = document.querySelectorAll(
            'form[data-mh-discussion-form="new"], .mh-discussion-form form, .mh-upload-form'
        );

        newDiscussionForms.forEach(function(form) {
            // Only attach to forms that have the discussion nonce field
            if (!form.querySelector('[name="mh_discussion_nonce"]')) return;

            form.addEventListener('submit', function(e) {
                e.preventDefault();

                var submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
                var originalText = submitBtn ? submitBtn.textContent : '';
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.textContent = 'Posting...';
                }

                var title = (form.querySelector('[name="discussion_title"]') || {}).value || '';
                var content = (form.querySelector('[name="discussion_content"]') || {}).value || '';
                var category = (form.querySelector('[name="discussion_category"]') || {}).value || 'qa';
                var authorName = (form.querySelector('[name="author_name"]') || {}).value || '';
                var authorEmail = (form.querySelector('[name="author_email"]') || {}).value || '';

                var formData = new FormData();
                formData.append('action', 'mh_new_discussion');
                formData.append('nonce', (typeof microhubAjax !== 'undefined' && microhubAjax.discussionNonce) ? microhubAjax.discussionNonce : ((typeof microhubData !== 'undefined' && microhubData.discussionNonce) ? microhubData.discussionNonce : ''));
                formData.append('title', title);
                formData.append('content', content);
                formData.append('category', category);
                formData.append('author_name', authorName);
                formData.append('author_email', authorEmail);

                var ajaxUrl = (typeof microhubAjax !== 'undefined' && microhubAjax.ajaxurl) ? microhubAjax.ajaxurl : ((typeof microhubData !== 'undefined' && microhubData.ajaxurl) ? microhubData.ajaxurl : '/wp-admin/admin-ajax.php');

                fetch(ajaxUrl, {
                    method: 'POST',
                    credentials: 'same-origin',
                    body: formData
                })
                .then(function(response) { return response.json(); })
                .then(function(data) {
                    var container = form.closest('.mh-new-discussion-section') ||
                                    form.closest('.mh-discussion-form') ||
                                    form.closest('#mh-new-topic-form') ||
                                    form.parentElement;

                    if (data.success) {
                        mhShowFormMessage(container, data.data.message, false);
                        form.reset();
                        // Reload the current page to show the new discussion in the list
                        setTimeout(function() {
                            window.location.reload();
                        }, 1500);
                    } else {
                        mhShowFormMessage(container, data.data ? data.data.message : 'Error posting discussion.', true);
                        if (submitBtn) {
                            submitBtn.disabled = false;
                            submitBtn.textContent = originalText;
                        }
                    }
                })
                .catch(function() {
                    mhShowFormMessage(form.parentElement, 'Network error. Please try again.', true);
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.textContent = originalText;
                    }
                });
            });
        });

        // Reply forms — AJAX submission
        var replyForms = document.querySelectorAll(
            'form[data-mh-discussion-form="reply"], .mh-reply-form'
        );

        replyForms.forEach(function(form) {
            // Only attach to forms that have the reply nonce field
            if (!form.querySelector('[name="mh_reply_nonce"]')) return;

            form.addEventListener('submit', function(e) {
                e.preventDefault();

                var submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
                var originalText = submitBtn ? submitBtn.textContent : '';
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.textContent = 'Posting...';
                }

                var content = (form.querySelector('[name="reply_content"]') || {}).value || '';
                var authorName = (form.querySelector('[name="reply_author"]') || {}).value || '';
                var authorEmail = (form.querySelector('[name="reply_email"]') || {}).value || '';
                // Get the discussion post ID from a hidden field or from the page
                var postIdField = form.querySelector('[name="mh_discussion_post_id"]');
                var postId = postIdField ? postIdField.value : (document.querySelector('article.mh-discussion-article') ? document.querySelector('body').getAttribute('data-post-id') || '' : '');

                // Fallback: try to get post ID from a data attribute on the form or section
                if (!postId) {
                    var section = form.closest('[data-discussion-id]');
                    if (section) postId = section.getAttribute('data-discussion-id');
                }

                var formData = new FormData();
                formData.append('action', 'mh_submit_reply');
                formData.append('nonce', (typeof microhubAjax !== 'undefined' && microhubAjax.discussionNonce) ? microhubAjax.discussionNonce : ((typeof microhubData !== 'undefined' && microhubData.discussionNonce) ? microhubData.discussionNonce : ''));
                formData.append('post_id', postId);
                formData.append('content', content);
                formData.append('author_name', authorName);
                formData.append('author_email', authorEmail);

                var ajaxUrl = (typeof microhubAjax !== 'undefined' && microhubAjax.ajaxurl) ? microhubAjax.ajaxurl : ((typeof microhubData !== 'undefined' && microhubData.ajaxurl) ? microhubData.ajaxurl : '/wp-admin/admin-ajax.php');

                fetch(ajaxUrl, {
                    method: 'POST',
                    credentials: 'same-origin',
                    body: formData
                })
                .then(function(response) { return response.json(); })
                .then(function(data) {
                    var container = form.closest('.mh-reply-form-section') || form.parentElement;

                    if (data.success) {
                        mhShowFormMessage(container, data.data.message, false);
                        form.reset();

                        // Append the new reply to the replies list
                        var repliesList = document.querySelector('.mh-replies-list');
                        if (repliesList && data.data.content) {
                            var replyIndex = repliesList.querySelectorAll('.mh-reply-card').length + 1;
                            var replyHtml = '<div class="mh-reply-card" id="reply-' + data.data.comment_id + '">' +
                                '<div class="mh-reply-number">#' + replyIndex + '</div>' +
                                '<div class="mh-reply-avatar">' + (data.data.initials || '') + '</div>' +
                                '<div class="mh-reply-content">' +
                                    '<div class="mh-reply-header">' +
                                        '<span class="mh-reply-author">' + (data.data.author || '') + '</span>' +
                                        '<span class="mh-reply-date">just now</span>' +
                                    '</div>' +
                                    '<div class="mh-reply-text">' + data.data.content + '</div>' +
                                '</div>' +
                            '</div>';
                            repliesList.insertAdjacentHTML('beforeend', replyHtml);
                        }

                        // If there was a "no replies" placeholder, remove it
                        var noReplies = document.querySelector('.mh-no-replies');
                        if (noReplies) noReplies.remove();

                        // Update reply count in header
                        if (data.data.reply_count !== undefined) {
                            var countEl = document.querySelector('.mh-reply-count');
                            if (countEl) {
                                var countNum = parseInt(data.data.reply_count);
                                countEl.textContent = countNum + ' ' + (countNum === 1 ? 'reply' : 'replies');
                            }
                            var sectionH2 = document.querySelector('.mh-replies-section h2');
                            if (sectionH2) {
                                sectionH2.textContent = 'Replies (' + data.data.reply_count + ')';
                            }
                        }

                        if (submitBtn) {
                            submitBtn.disabled = false;
                            submitBtn.textContent = originalText;
                        }
                    } else {
                        mhShowFormMessage(container, data.data ? data.data.message : 'Error posting reply.', true);
                        if (submitBtn) {
                            submitBtn.disabled = false;
                            submitBtn.textContent = originalText;
                        }
                    }
                })
                .catch(function() {
                    mhShowFormMessage(form.parentElement, 'Network error. Please try again.', true);
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.textContent = originalText;
                    }
                });
            });
        });
    }

    // Initialize discussion forms if any are present on the page
    initDiscussionForms();
});
