<?php
/**
 * About Page Template (slug-based: automatically used for /about/ page)
 *
 * Displays information about MDIBL Light Microscopy Facility, the MicroHub
 * platform, data sources, and auto-generated statistics.
 */
get_header();

$stats = mh_get_stats();

// Get techniques for display
$techniques = array();
if (taxonomy_exists('mh_technique')) {
    $techniques = get_terms(array(
        'taxonomy' => 'mh_technique',
        'number' => 20,
        'orderby' => 'count',
        'order' => 'DESC',
        'hide_empty' => true
    ));
    if (is_wp_error($techniques)) {
        $techniques = array();
    }
}

// Check if page has real editor content (not a legacy shortcode)
$has_editor_content = false;
if (have_posts()) {
    while (have_posts()) {
        the_post();
        $raw = get_the_content();
        // Skip if content is empty or just a legacy shortcode
        if ($raw && !preg_match('/^\s*\[microhub_\w+\]\s*$/', $raw)) {
            $has_editor_content = true;
        }
    }
    rewind_posts();
}
?>

<div class="mh-page-header">
    <h1><?php the_title(); ?></h1>
    <?php if (has_excerpt()): ?>
        <p class="mh-page-subtitle"><?php echo get_the_excerpt(); ?></p>
    <?php else: ?>
        <p class="mh-page-subtitle">The open platform for microscopy research</p>
    <?php endif; ?>
</div>

<div class="mh-container">

    <?php if ($has_editor_content): ?>
    <!-- Custom page content from WordPress editor -->
    <?php while (have_posts()): the_post(); ?>
    <section class="mh-about-section mh-page-content">
        <?php the_content(); ?>
    </section>
    <?php endwhile; ?>
    <?php else: ?>

    <!-- About MDIBL LMF -->
    <section class="mh-about-section">
        <h2>About MicroHub</h2>
        <p>MicroHub is developed by the <strong>Light Microscopy Facility (LMF)</strong> at the <strong>MDI Biological Laboratory</strong> in Bar Harbor, Maine. The LMF provides advanced imaging services and expertise to researchers studying fundamental biological processes, with a focus on regeneration, aging, and the biology of organisms in their natural environment.</p>
        <p>MicroHub serves as an open, searchable database of microscopy research papers, enriched with structured metadata about the techniques, equipment, software, and biological models used across the field. Our goal is to make microscopy methods more discoverable and reproducible by connecting papers to the tools and protocols that produced the results.</p>
    </section>

    <!-- How Data Is Collected -->
    <section class="mh-about-section">
        <h2>How We Collect and Enrich Data</h2>
        <p>Papers are imported through an automated pipeline that collects publications from biomedical literature databases, acquires full text where available, extracts structured metadata using pattern matching and NLP, and then enriches each record with data from multiple external APIs.</p>

        <div class="mh-api-grid">
            <div class="mh-api-card">
                <h3>Paper Discovery</h3>
                <ul>
                    <li><strong>PubMed / PMC</strong> &mdash; Primary source for searching and fetching paper metadata and full-text XML</li>
                    <li><strong>Europe PMC</strong> &mdash; High-quality JATS XML full-text retrieval</li>
                    <li><strong>Unpaywall</strong> &mdash; Discovering open-access PDF URLs</li>
                </ul>
            </div>
            <div class="mh-api-card">
                <h3>Citation &amp; Metadata Enrichment</h3>
                <ul>
                    <li><strong>OpenAlex</strong> &mdash; Institutions, ROR IDs, topics, citations, and open-access status</li>
                    <li><strong>Semantic Scholar</strong> &mdash; Citation counts and fields of study</li>
                    <li><strong>CrossRef</strong> &mdash; Journal metadata, funders, and data repository links</li>
                </ul>
            </div>
            <div class="mh-api-card">
                <h3>Code &amp; Data Repositories</h3>
                <ul>
                    <li><strong>GitHub API</strong> &mdash; Repository health scores, stars, activity metrics, and language breakdowns</li>
                    <li><strong>DataCite</strong> &mdash; Dataset DOI resolution and publication linking</li>
                    <li><strong>OpenAIRE ScholeXplorer</strong> &mdash; Dataset-to-publication link discovery</li>
                </ul>
            </div>
            <div class="mh-api-card">
                <h3>Biological Validation</h3>
                <ul>
                    <li><strong>PubTator 3.0</strong> &mdash; Pre-computed named entity recognition for species, chemicals, and cell lines</li>
                    <li><strong>NCBI Taxonomy</strong> &mdash; Organism name to taxonomy ID validation</li>
                    <li><strong>Cellosaurus</strong> &mdash; Cell line validation and accession IDs</li>
                    <li><strong>FPbase</strong> &mdash; Fluorescent protein validation and spectral data</li>
                    <li><strong>SciCrunch</strong> &mdash; RRID (Research Resource Identifier) validation</li>
                    <li><strong>EBI OLS4</strong> &mdash; Mapping technique names to FBbi ontology terms</li>
                    <li><strong>ROR</strong> &mdash; Institution affiliation matching</li>
                </ul>
            </div>
        </div>
    </section>

    <!-- What Gets Extracted -->
    <section class="mh-about-section">
        <h2>What We Extract From Each Paper</h2>
        <div class="mh-extract-grid">
            <div class="mh-extract-item">
                <span class="mh-extract-icon">🔬</span>
                <strong>Microscopy Techniques</strong>
                <span>Confocal, light sheet, super-resolution, electron microscopy, and more</span>
            </div>
            <div class="mh-extract-item">
                <span class="mh-extract-icon">🔭</span>
                <strong>Equipment</strong>
                <span>Microscope brands/models, objectives, lasers, detectors, and filters</span>
            </div>
            <div class="mh-extract-item">
                <span class="mh-extract-icon">💻</span>
                <strong>Software</strong>
                <span>Image acquisition, analysis tools, and general-purpose software</span>
            </div>
            <div class="mh-extract-item">
                <span class="mh-extract-icon">🧬</span>
                <strong>Biological Models</strong>
                <span>Organisms, cell lines, fluorophores, and sample preparation methods</span>
            </div>
            <div class="mh-extract-item">
                <span class="mh-extract-icon">📋</span>
                <strong>Protocols</strong>
                <span>Links to protocols.io, Bio-protocol, JoVE, and other protocol sources</span>
            </div>
            <div class="mh-extract-item">
                <span class="mh-extract-icon">💾</span>
                <strong>Code &amp; Data</strong>
                <span>GitHub repositories, data deposits, and RRIDs</span>
            </div>
        </div>
    </section>

    <?php endif; ?>

    <!-- Stats Section (Auto-generated) -->
    <?php if ($stats['papers'] > 0): ?>
    <section class="mh-about-section">
        <h2>📊 Database Statistics</h2>
        <div class="mh-stats-grid" style="margin-top: 24px;">
            <div class="mh-stat-card">
                <span class="number"><?php echo mh_format_number($stats['papers']); ?></span>
                <span class="label">Papers</span>
            </div>
            <div class="mh-stat-card">
                <span class="number"><?php echo mh_format_number($stats['with_protocols']); ?></span>
                <span class="label">With Protocols</span>
            </div>
            <div class="mh-stat-card">
                <span class="number"><?php echo mh_format_number($stats['techniques']); ?></span>
                <span class="label">Techniques</span>
            </div>
            <div class="mh-stat-card">
                <span class="number"><?php echo mh_format_number($stats['with_github']); ?></span>
                <span class="label">With Code</span>
            </div>
            <div class="mh-stat-card">
                <span class="number"><?php echo mh_format_number($stats['microscopes']); ?></span>
                <span class="label">Microscopes</span>
            </div>
            <div class="mh-stat-card">
                <span class="number"><?php echo mh_format_number($stats['organisms']); ?></span>
                <span class="label">Organisms</span>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- Techniques Section (Auto-generated) -->
    <?php if (!empty($techniques)): ?>
    <section class="mh-about-section">
        <h2>🔬 Techniques Covered</h2>
        <div class="mh-tag-cloud" style="margin-top: 16px;">
            <?php foreach ($techniques as $term):
                $link = get_term_link($term);
                if (!is_wp_error($link)):
            ?>
                <a href="<?php echo esc_url($link); ?>" class="mh-tag mh-tag-technique mh-tag-lg">
                    <?php echo esc_html($term->name); ?>
                    <small><?php echo $term->count; ?></small>
                </a>
            <?php endif; endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- Contact CTA -->
    <section class="mh-about-section" style="text-align: center;">
        <h2>📬 Get in Touch</h2>
        <p>Have questions, suggestions, or want to contribute?</p>
        <a href="<?php echo esc_url(mh_get_page_urls()['contact']); ?>" class="mh-btn mh-btn-primary" style="margin-top: 16px;">Contact Us</a>
    </section>
</div>

<style>
/* About page sections */
.mh-about-section { margin-bottom: 40px; }
.mh-about-section h2 { font-size: 1.4rem; margin-bottom: 16px; }
.mh-about-section p { color: var(--text-light); line-height: 1.8; margin-bottom: 12px; }

/* API cards grid */
.mh-api-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 20px;
}
.mh-api-card {
    background: var(--bg-card, #161b22);
    border: 1px solid var(--border, #30363d);
    border-radius: 10px;
    padding: 24px;
}
.mh-api-card h3 {
    font-size: 1.05rem;
    margin: 0 0 14px 0;
    color: var(--primary, #58a6ff);
}
.mh-api-card ul {
    list-style: none;
    padding: 0;
    margin: 0;
}
.mh-api-card li {
    padding: 8px 0;
    color: var(--text-light, #8b949e);
    border-bottom: 1px solid var(--border, #30363d);
    font-size: 0.9rem;
    line-height: 1.5;
}
.mh-api-card li:last-child { border-bottom: none; }
.mh-api-card li strong { color: var(--text, #c9d1d9); }

/* What we extract grid */
.mh-extract-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 16px;
    margin-top: 20px;
}
.mh-extract-item {
    display: flex;
    flex-direction: column;
    gap: 4px;
    background: var(--bg-card, #161b22);
    border: 1px solid var(--border, #30363d);
    border-radius: 10px;
    padding: 20px;
}
.mh-extract-icon { font-size: 1.5rem; }
.mh-extract-item strong { color: var(--text, #c9d1d9); font-size: 0.95rem; }
.mh-extract-item span:last-child { color: var(--text-muted, #8b949e); font-size: 0.85rem; line-height: 1.5; }

/* Editor content styling */
.mh-page-content h2 { font-size: 1.25rem; margin-top: 24px; margin-bottom: 16px; }
.mh-page-content h3 { font-size: 1.1rem; margin-top: 20px; margin-bottom: 12px; }
.mh-page-content p { color: var(--text-light); line-height: 1.7; }
.mh-page-content ul, .mh-page-content ol { margin: 16px 0; padding-left: 24px; }
.mh-page-content li { color: var(--text-light); margin-bottom: 8px; }
.mh-page-content a { color: var(--primary); }
.mh-page-content a:hover { color: var(--accent); }
.mh-page-content img { max-width: 100%; height: auto; border-radius: 8px; margin: 16px 0; }
.mh-page-content blockquote { border-left: 4px solid var(--primary); padding-left: 16px; margin: 16px 0; color: var(--text-muted); font-style: italic; }

/* WordPress blocks support */
.mh-page-content .wp-block-columns { display: flex; gap: 24px; flex-wrap: wrap; }
.mh-page-content .wp-block-column { flex: 1; min-width: 250px; }
.mh-page-content .wp-block-button__link { display: inline-block; padding: 10px 20px; background: var(--primary); color: white; border-radius: 8px; text-decoration: none; }
.mh-page-content .wp-block-button__link:hover { background: var(--accent); color: white; }

@media (max-width: 768px) {
    .mh-api-grid, .mh-extract-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<?php get_footer(); ?>
